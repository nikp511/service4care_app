package com.service.care.fragments;

import android.content.Context;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.preference.PreferenceManager;
import android.text.TextUtils;
import android.view.LayoutInflater;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ProgressBar;
import android.widget.RelativeLayout;

import androidx.annotation.NonNull;
import androidx.appcompat.widget.Toolbar;
import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentTransaction;
import androidx.recyclerview.widget.DefaultItemAnimator;
import androidx.recyclerview.widget.GridLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.service.care.R;
import com.service.care.adapter.HomeCategoryAdapter;
import com.service.care.adapter.SubCategoryAdapter;
import com.service.care.application.MyApplication;
import com.service.care.pojo.PojoCategory;
import com.service.care.pojo.PojoSubCategory;
import com.service.care.utils.Utils;
import com.smarteist.autoimageslider.SliderView;

import java.util.ArrayList;
import java.util.List;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

/**
 * Created by Rp on 8/30/2016.
 */
public class SubCategoryFragment extends Fragment {

    private View mParentView;

    private Context mContext;
    RelativeLayout mRelativeMain;
    ProgressBar mProgressBar;

    MyApplication mApplication;
    private SharedPreferences mSharedPreference;

    SliderView imageSlider;
    RecyclerView rvCategory;
    SubCategoryAdapter subCategoryAdapter;
    List<PojoSubCategory.Datum> mArrayCategory = new ArrayList<>();


    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        mParentView = inflater.inflate(R.layout.fragment_sub_category, container, false);
        mApplication = (MyApplication) getActivity().getApplicationContext();
        mContext = getActivity();
        setHasOptionsMenu(true);
        mSharedPreference = PreferenceManager.getDefaultSharedPreferences(getActivity());

        initialise();
        networkCallCategory();

        return mParentView;

    }

    void initialise() {

        Toolbar mToolbar = (Toolbar) getActivity().findViewById(R.id.toolbar);
        mToolbar.setTitle(getArguments().getString("name"));
        mToolbar.setVisibility(View.VISIBLE);

        mRelativeMain = mParentView.findViewById(R.id.relative_main);
        mProgressBar = mParentView.findViewById(R.id.progressbar);

        imageSlider = mParentView.findViewById(R.id.imageSlider);
        rvCategory = mParentView.findViewById(R.id.rvCategory);

        GridLayoutManager layoutManagerContact = new GridLayoutManager(mContext, 1);
        rvCategory.setLayoutManager(layoutManagerContact);
        rvCategory.setItemAnimator(new DefaultItemAnimator());


    }


    private void networkCallCategory() {
        if (mApplication.isInternetConnected()) {

            mProgressBar.setVisibility(View.VISIBLE);

            mApplication.getRetroFitInterface().SubCategory(getArguments().getString("id")).enqueue(mCallbackCategory);


        } else {
            Utils.showSnackBar(getActivity(), getResources().getString(R.string
                    .message_connection));
            mProgressBar.setVisibility(View.GONE);
        }
    }

    /**
     * Callback for ws.wolfsoft.propertyplanetapp.network call
     */
    private Callback<PojoSubCategory> mCallbackCategory = new Callback<PojoSubCategory>() {
        @Override
        public void onResponse(Call<PojoSubCategory> call, Response<PojoSubCategory> response) {
            if (response != null && response.isSuccessful() && response.body() != null) {

                PojoSubCategory pojoParticipants = response.body();

                mArrayCategory.clear();

                if (pojoParticipants.getStatus() == 1) {

                    if (pojoParticipants.getData() != null) {
                        if (pojoParticipants.getData().size() > 0) {
                            mArrayCategory.addAll(pojoParticipants.getData());

                            subCategoryAdapter = new SubCategoryAdapter(mContext, mArrayCategory, categoryClick);
                            rvCategory.setAdapter(subCategoryAdapter);

                        } else {
                            rvCategory.setAdapter(null);
                        }
                    } else {
                        rvCategory.setAdapter(null);
                    }

                } else {
                    rvCategory.setAdapter(null);
                    if (!TextUtils.isEmpty(pojoParticipants.getMessage())) {
                        Utils.showSnackBar(getActivity(), pojoParticipants.getMessage());

                    } else {
                        Utils.showSnackBar(getActivity(), getString(R.string
                                .message_something_wrong));
                    }

                }
            } else {
                Utils.showSnackBar(getActivity(), getString(R.string.message_something_wrong));
                mProgressBar.setVisibility(View.GONE);
            }
            mProgressBar.setVisibility(View.GONE);

        }

        @Override
        public void onFailure(Call<PojoSubCategory> call, Throwable t) {
            try {
                Utils.showSnackBar(getActivity(), getString(R.string
                        .message_something_wrong));
                mProgressBar.setVisibility(View.GONE);
            } catch (Exception e) {

            }
        }
    };

    SubCategoryAdapter.CustomClick categoryClick = new SubCategoryAdapter.CustomClick() {
        @Override
        public void detailClick(String name, String id) {
            Fragment fragment1 = new SubSubCategoryFragment();
            FragmentTransaction ft1 = getFragmentManager().beginTransaction();
            Bundle b = new Bundle();
            b.putString("name", name);
            b.putString("id", id);

            fragment1.setArguments(b);
            ft1.replace(R.id.frame_container, fragment1).addToBackStack("").commit();
        }
    };


}
