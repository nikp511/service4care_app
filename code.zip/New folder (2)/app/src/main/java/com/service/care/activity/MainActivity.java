package com.service.care.activity;

import android.content.DialogInterface;
import android.content.Intent;
import android.content.SharedPreferences;
import android.graphics.Color;
import android.os.Bundle;
import android.preference.PreferenceManager;
import android.view.MenuItem;
import android.view.View;
import android.view.WindowManager;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ProgressBar;
import android.widget.RelativeLayout;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.appcompat.app.ActionBarDrawerToggle;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;
import androidx.core.content.ContextCompat;
import androidx.core.view.GravityCompat;
import androidx.drawerlayout.widget.DrawerLayout;
import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentManager;
import androidx.fragment.app.FragmentTransaction;

import com.google.android.material.navigation.NavigationView;
import com.service.care.R;
import com.service.care.application.MyApplication;
import com.service.care.constants.ConstantCodes;
import com.service.care.fragments.admin.AdminDashboardFragment;
import com.service.care.fragments.admin.AdminLeaveFragment;
import com.service.care.fragments.employess.EmployeeAddComplainFragment;
import com.service.care.fragments.employess.EmployeeAllComplainFragment;
import com.service.care.fragments.employess.EmployeeAllLeaveFragment;
import com.service.care.fragments.employess.EmployeeDashboardFragment;
import com.service.care.fragments.employess.EmployeeInquiryRequestFragment;
import com.service.care.fragments.users.UserAllComplainFragment;
import com.service.care.fragments.admin.AdminAddEmployeeFragment;
import com.service.care.fragments.admin.AdminCashCollectedFragment;
import com.service.care.fragments.admin.AdminEmployeeListFragment;
import com.service.care.fragments.admin.AdminOrderFragment;
import com.service.care.fragments.admin.AdminProfileFragment;
import com.service.care.fragments.employess.EmployeeAllInquiryDetailFragment;
import com.service.care.fragments.employess.EmployeeAssignedInquiryFragment;
import com.service.care.fragments.users.UserAllInquiryFragment;
import com.service.care.fragments.AllOrderFragment;
import com.service.care.fragments.CategoryFragment;
import com.service.care.fragments.users.UserAddComplainFragment;
import com.service.care.fragments.FeedbackFragment;
import com.service.care.fragments.users.UserDashboardFragment;
import com.service.care.fragments.AddInquiryFragment;
import com.service.care.fragments.NewsOfferFragment;
import com.service.care.fragments.employess.EmployeeAddLeaveFragment;
import com.service.care.fragments.employess.EmployeeProfileFragment;
import com.service.care.fragments.users.UserProfileFragment;
import com.service.care.fragments.RatingFragment;
import com.service.care.utils.Utils;


public class MainActivity extends AppCompatActivity implements NavigationView
        .OnNavigationItemSelectedListener {


    private Toolbar toolbar;
    private DrawerLayout drawerLayout;
    NavigationView navigationView;
    private ActionBarDrawerToggle drawerToggle;

    ProgressBar mProgressBar;
    MyApplication mApplication;

    SharedPreferences mSharedPreference;
    RelativeLayout mRelativeMain;

    LinearLayout llBotttomUser, llBotttomEmployee, llBotttomAdmin;

    LinearLayout llUserHome, llUserComplain, llUserCategory, llUserComplainNote;

    LinearLayout llEmployeeAssignedInquiry, llEmployeeInquiry, llEmployeeRequest, llEmployeeHome;

    LinearLayout llAdminHome, llAdminOrder, llAdminEmployee, llAdminCash;
    ImageView bbAdminHome, bbAdminOrder, bbAdminEmployee, bbAdminCash;
    TextView tvbbAdminHome, tvbbAdminOrder, tvbbAdminEmployee, tvbbAdminCash;

    ImageView bbUserHome, bbUserComplain, bbUserCategory, bbUserComplainNote;
    TextView tvbbUserHome, tvbbUserComplain, tvbbUserCategory, tvbbUserComplainNote;

    ImageView bbEmployeeHome, bbEmployeeInquiry, bbEmployeeRequest, bbEmployeeAssignedInquiry;
    TextView tvbbEmployeeHome, tvbbEmployeeInquiry, tvbbEmployeeRequest, tvbbEmployeeAssignedInquiry;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        setToolbar();
        mApplication = (MyApplication) this.getApplicationContext();
        mSharedPreference = PreferenceManager.getDefaultSharedPreferences(this);

        mProgressBar = findViewById(R.id.progressbar_footer);
        mRelativeMain = findViewById(R.id.relative_main);

        drawerLayout = (DrawerLayout) findViewById(R.id.drawerLayout);
        navigationView = findViewById(R.id.nav_view);


        drawerToggle = new ActionBarDrawerToggle(this, drawerLayout, toolbar, R.string.app_name, R.string.app_name);
        drawerToggle.getDrawerArrowDrawable().setColor(Color.WHITE);
        drawerLayout.addDrawerListener(drawerToggle);

        drawerToggle.syncState();

        setDrawer();


        getWindow().setSoftInputMode(WindowManager.LayoutParams.SOFT_INPUT_STATE_ALWAYS_HIDDEN);

        navigationView.setNavigationItemSelectedListener(this);

        View headerView = navigationView.getHeaderView(0);
        TextView tvName = (TextView) headerView.findViewById(R.id.tvName);
        if (mSharedPreference.getString(ConstantCodes.LOGIN_USER_NAME, "").equals("")) {
            tvName.setText("Hello, Guest");
        } else {
            tvName.setText("Hello, " + mSharedPreference.getString(ConstantCodes.LOGIN_USER_NAME, ""));

        }


        llBotttomUser = findViewById(R.id.llBotttomUser);
        llBotttomEmployee = findViewById(R.id.llBotttomEmployee);
        llBotttomAdmin = findViewById(R.id.llBotttomAdmin);

        llUserHome = findViewById(R.id.llUserHome);
        llUserCategory = findViewById(R.id.llUserCategory);
        llUserComplain = findViewById(R.id.llUserComplain);
        llUserComplainNote = findViewById(R.id.llUserComplainNote);

        bbUserHome = findViewById(R.id.bbUserHome);
        bbUserComplain = findViewById(R.id.bbUserComplain);
        bbUserCategory = findViewById(R.id.bbUserCategory);
        bbUserComplainNote = findViewById(R.id.bbUserComplainNote);

        tvbbUserHome = findViewById(R.id.tvbbUserHome);
        tvbbUserComplain = findViewById(R.id.tvbbUserComplain);
        tvbbUserCategory = findViewById(R.id.tvbbUserCategory);
        tvbbUserComplainNote = findViewById(R.id.tvbbUserComplainNote);

        llEmployeeHome = findViewById(R.id.llEmployeeHome);
        llEmployeeInquiry = findViewById(R.id.llEmployeeInquiry);
        llEmployeeRequest = findViewById(R.id.llEmployeeRequest);
        llEmployeeAssignedInquiry = findViewById(R.id.llEmployeeAssignedInquiry);

        bbEmployeeHome = findViewById(R.id.bbEmployeeHome);
        bbEmployeeInquiry = findViewById(R.id.bbEmployeeInquiry);
        bbEmployeeRequest = findViewById(R.id.bbEmployeeRequest);
        bbEmployeeAssignedInquiry = findViewById(R.id.bbEmployeeAssignedInquiry);

        tvbbEmployeeHome = findViewById(R.id.tvbbEmployeeHome);
        tvbbEmployeeInquiry = findViewById(R.id.tvbbEmployeeInquiry);
        tvbbEmployeeRequest = findViewById(R.id.tvbbEmployeeRequest);
        tvbbEmployeeAssignedInquiry = findViewById(R.id.tvbbEmployeeAssignedInquiry);

        llAdminHome = findViewById(R.id.llAdminHome);
        llAdminOrder = findViewById(R.id.llAdminOrder);
        llAdminEmployee = findViewById(R.id.llAdminEmployee);
        llAdminCash = findViewById(R.id.llAdminCash);
        bbAdminHome = findViewById(R.id.bbAdminHome);
        bbAdminOrder = findViewById(R.id.bbAdminOrder);
        bbAdminEmployee = findViewById(R.id.bbAdminEmployee);
        bbAdminCash = findViewById(R.id.bbAdminCash);
        tvbbAdminHome = findViewById(R.id.tvbbAdminHome);
        tvbbAdminOrder = findViewById(R.id.tvbbAdminOrder);
        tvbbAdminEmployee = findViewById(R.id.tvbbAdminEmployee);
        tvbbAdminCash = findViewById(R.id.tvbbAdminCash);

        if (mSharedPreference.getString(ConstantCodes.LOGIN_USERTYPE, "").equals("1")) {
            navigationView.getMenu().clear();
            navigationView.inflateMenu(R.menu.menu_main_admin);
            llBotttomAdmin.setVisibility(View.VISIBLE);
            llBotttomEmployee.setVisibility(View.GONE);
            llBotttomUser.setVisibility(View.GONE);

            tvbbAdminHome.setTextColor(getResources().getColor(R.color.app_white));
            tvbbAdminOrder.setTextColor(getResources().getColor(R.color.light_white));
            tvbbAdminEmployee.setTextColor(getResources().getColor(R.color.light_white));
            tvbbAdminCash.setTextColor(getResources().getColor(R.color.light_white));

            bbAdminHome.setColorFilter(getResources().getColor(R.color.app_white));
            bbAdminOrder.setColorFilter(getResources().getColor(R.color.light_white));
            bbAdminEmployee.setColorFilter(getResources().getColor(R.color.light_white));
            bbAdminCash.setColorFilter(getResources().getColor(R.color.light_white));

        } else if (mSharedPreference.getString(ConstantCodes.LOGIN_USERTYPE, "").equals("2")) {
            navigationView.getMenu().clear();
            navigationView.inflateMenu(R.menu.menu_main_employee);
            llBotttomAdmin.setVisibility(View.GONE);
            llBotttomEmployee.setVisibility(View.VISIBLE);
            llBotttomUser.setVisibility(View.GONE);

            tvbbEmployeeHome.setTextColor(getResources().getColor(R.color.app_white));
            tvbbEmployeeInquiry.setTextColor(getResources().getColor(R.color.light_white));
            tvbbEmployeeAssignedInquiry.setTextColor(getResources().getColor(R.color.light_white));
            tvbbEmployeeRequest.setTextColor(getResources().getColor(R.color.light_white));

            bbEmployeeHome.setColorFilter(getResources().getColor(R.color.app_white));
            bbEmployeeInquiry.setColorFilter(getResources().getColor(R.color.light_white));
            bbEmployeeAssignedInquiry.setColorFilter(getResources().getColor(R.color.light_white));
            bbEmployeeRequest.setColorFilter(getResources().getColor(R.color.light_white));

        } else if (mSharedPreference.getString(ConstantCodes.LOGIN_USERTYPE, "").equals("3")) {
            navigationView.getMenu().clear();
            navigationView.inflateMenu(R.menu.menu_main_user);
            llBotttomAdmin.setVisibility(View.GONE);
            llBotttomEmployee.setVisibility(View.GONE);
            llBotttomUser.setVisibility(View.VISIBLE);

            tvbbUserHome.setTextColor(getResources().getColor(R.color.app_white));
            tvbbUserCategory.setTextColor(getResources().getColor(R.color.light_white));
            tvbbUserComplain.setTextColor(getResources().getColor(R.color.light_white));
            tvbbUserComplainNote.setTextColor(getResources().getColor(R.color.light_white));

            bbUserHome.setColorFilter(getResources().getColor(R.color.app_white));
            bbUserCategory.setColorFilter(getResources().getColor(R.color.light_white));
            bbUserComplain.setColorFilter(getResources().getColor(R.color.light_white));
            bbUserComplainNote.setColorFilter(getResources().getColor(R.color.light_white));

        }

        listners();


        if (mSharedPreference.getString(ConstantCodes.LOGIN_USERTYPE, "").equals("1")) {
            changeFragment(new AdminDashboardFragment(), "");
        } else if (mSharedPreference.getString(ConstantCodes.LOGIN_USERTYPE, "").equals("2")) {
            changeFragment(new EmployeeDashboardFragment(), "");
        } else if (mSharedPreference.getString(ConstantCodes.LOGIN_USERTYPE, "").equals("3")) {
            changeFragment(new UserDashboardFragment(), "");

        }

    }

    void listners() {

        llUserHome.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                tvbbUserHome.setTextColor(getResources().getColor(R.color.app_white));
                tvbbUserCategory.setTextColor(getResources().getColor(R.color.light_white));
                tvbbUserComplain.setTextColor(getResources().getColor(R.color.light_white));
                tvbbUserComplainNote.setTextColor(getResources().getColor(R.color.light_white));

                bbUserHome.setColorFilter(getResources().getColor(R.color.app_white));
                bbUserCategory.setColorFilter(getResources().getColor(R.color.light_white));
                bbUserComplain.setColorFilter(getResources().getColor(R.color.light_white));
                bbUserComplainNote.setColorFilter(getResources().getColor(R.color.light_white));

                Fragment fragment1 = new UserDashboardFragment();
                FragmentTransaction ft1 = getSupportFragmentManager().beginTransaction();
                ft1.replace(R.id.frame_container, fragment1).commit();
            }
        });

        llUserComplain.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                tvbbUserHome.setTextColor(getResources().getColor(R.color.light_white));
                tvbbUserCategory.setTextColor(getResources().getColor(R.color.light_white));
                tvbbUserComplain.setTextColor(getResources().getColor(R.color.app_white));
                tvbbUserComplainNote.setTextColor(getResources().getColor(R.color.light_white));

                bbUserHome.setColorFilter(getResources().getColor(R.color.light_white));
                bbUserCategory.setColorFilter(getResources().getColor(R.color.light_white));
                bbUserComplain.setColorFilter(getResources().getColor(R.color.app_white));
                bbUserComplainNote.setColorFilter(getResources().getColor(R.color.light_white));

                Fragment fragment1 = new UserAllComplainFragment();
                FragmentTransaction ft1 = getSupportFragmentManager().beginTransaction();
                ft1.replace(R.id.frame_container, fragment1).addToBackStack("").commit();

            }
        });

        llUserComplainNote.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                tvbbUserHome.setTextColor(getResources().getColor(R.color.light_white));
                tvbbUserCategory.setTextColor(getResources().getColor(R.color.light_white));
                tvbbUserComplain.setTextColor(getResources().getColor(R.color.light_white));
                tvbbUserComplainNote.setTextColor(getResources().getColor(R.color.app_white));

                bbUserHome.setColorFilter(getResources().getColor(R.color.light_white));
                bbUserCategory.setColorFilter(getResources().getColor(R.color.light_white));
                bbUserComplain.setColorFilter(getResources().getColor(R.color.light_white));
                bbUserComplainNote.setColorFilter(getResources().getColor(R.color.app_white));

                Fragment fragment1 = new UserAddComplainFragment();
                FragmentTransaction ft1 = getSupportFragmentManager().beginTransaction();
                ft1.replace(R.id.frame_container, fragment1).addToBackStack("").commit();
            }
        });

        llUserCategory.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                tvbbUserHome.setTextColor(getResources().getColor(R.color.light_white));
                tvbbUserCategory.setTextColor(getResources().getColor(R.color.app_white));
                tvbbUserComplain.setTextColor(getResources().getColor(R.color.light_white));
                tvbbUserComplainNote.setTextColor(getResources().getColor(R.color.light_white));

                bbUserHome.setColorFilter(getResources().getColor(R.color.light_white));
                bbUserCategory.setColorFilter(getResources().getColor(R.color.app_white));
                bbUserComplain.setColorFilter(getResources().getColor(R.color.light_white));
                bbUserComplainNote.setColorFilter(getResources().getColor(R.color.light_white));

                Fragment fragment1 = new CategoryFragment();
                FragmentTransaction ft1 = getSupportFragmentManager().beginTransaction();
                ft1.replace(R.id.frame_container, fragment1).addToBackStack("").commit();
            }
        });

        llEmployeeHome.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                tvbbEmployeeHome.setTextColor(getResources().getColor(R.color.app_white));
                tvbbEmployeeInquiry.setTextColor(getResources().getColor(R.color.light_white));
                tvbbEmployeeAssignedInquiry.setTextColor(getResources().getColor(R.color.light_white));
                tvbbEmployeeRequest.setTextColor(getResources().getColor(R.color.light_white));

                bbEmployeeHome.setColorFilter(getResources().getColor(R.color.app_white));
                bbEmployeeInquiry.setColorFilter(getResources().getColor(R.color.light_white));
                bbEmployeeAssignedInquiry.setColorFilter(getResources().getColor(R.color.light_white));
                bbEmployeeRequest.setColorFilter(getResources().getColor(R.color.light_white));

                Fragment fragment1 = new EmployeeDashboardFragment();
                FragmentTransaction ft1 = getSupportFragmentManager().beginTransaction();
                ft1.replace(R.id.frame_container, fragment1).commit();
            }
        });

        llEmployeeInquiry.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                tvbbEmployeeHome.setTextColor(getResources().getColor(R.color.light_white));
                tvbbEmployeeRequest.setTextColor(getResources().getColor(R.color.light_white));
                tvbbEmployeeInquiry.setTextColor(getResources().getColor(R.color.app_white));
                tvbbEmployeeAssignedInquiry.setTextColor(getResources().getColor(R.color.light_white));

                bbEmployeeHome.setColorFilter(getResources().getColor(R.color.light_white));
                bbEmployeeRequest.setColorFilter(getResources().getColor(R.color.light_white));
                bbEmployeeInquiry.setColorFilter(getResources().getColor(R.color.app_white));
                bbEmployeeAssignedInquiry.setColorFilter(getResources().getColor(R.color.light_white));

                Fragment fragment1 = new EmployeeAllInquiryDetailFragment();
                FragmentTransaction ft1 = getSupportFragmentManager().beginTransaction();
                ft1.replace(R.id.frame_container, fragment1).addToBackStack("").commit();

            }
        });

        llEmployeeRequest.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                tvbbEmployeeHome.setTextColor(getResources().getColor(R.color.light_white));
                tvbbEmployeeRequest.setTextColor(getResources().getColor(R.color.app_white));
                tvbbEmployeeInquiry.setTextColor(getResources().getColor(R.color.light_white));
                tvbbEmployeeAssignedInquiry.setTextColor(getResources().getColor(R.color.light_white));

                bbEmployeeHome.setColorFilter(getResources().getColor(R.color.light_white));
                bbEmployeeRequest.setColorFilter(getResources().getColor(R.color.app_white));
                bbEmployeeInquiry.setColorFilter(getResources().getColor(R.color.light_white));
                bbEmployeeAssignedInquiry.setColorFilter(getResources().getColor(R.color.light_white));

                Fragment fragment1 = new EmployeeInquiryRequestFragment();
                FragmentTransaction ft1 = getSupportFragmentManager().beginTransaction();
                ft1.replace(R.id.frame_container, fragment1).addToBackStack("").commit();

            }
        });

        llEmployeeAssignedInquiry.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                tvbbEmployeeHome.setTextColor(getResources().getColor(R.color.light_white));
                tvbbEmployeeInquiry.setTextColor(getResources().getColor(R.color.light_white));
                tvbbEmployeeAssignedInquiry.setTextColor(getResources().getColor(R.color.app_white));
                tvbbEmployeeRequest.setTextColor(getResources().getColor(R.color.light_white));

                bbEmployeeHome.setColorFilter(getResources().getColor(R.color.light_white));
                bbEmployeeInquiry.setColorFilter(getResources().getColor(R.color.light_white));
                bbEmployeeAssignedInquiry.setColorFilter(getResources().getColor(R.color.app_white));
                bbEmployeeRequest.setColorFilter(getResources().getColor(R.color.light_white));

                Fragment fragment1 = new EmployeeAssignedInquiryFragment();
                FragmentTransaction ft1 = getSupportFragmentManager().beginTransaction();
                ft1.replace(R.id.frame_container, fragment1).addToBackStack("").commit();

            }
        });

        llAdminHome.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                tvbbAdminHome.setTextColor(getResources().getColor(R.color.app_white));
                tvbbAdminOrder.setTextColor(getResources().getColor(R.color.light_white));
                tvbbAdminEmployee.setTextColor(getResources().getColor(R.color.light_white));
                tvbbAdminCash.setTextColor(getResources().getColor(R.color.light_white));

                bbAdminHome.setColorFilter(getResources().getColor(R.color.app_white));
                bbAdminOrder.setColorFilter(getResources().getColor(R.color.light_white));
                bbAdminEmployee.setColorFilter(getResources().getColor(R.color.light_white));
                bbAdminCash.setColorFilter(getResources().getColor(R.color.light_white));

                Fragment fragment1 = new AdminDashboardFragment();
                FragmentTransaction ft1 = getSupportFragmentManager().beginTransaction();
                ft1.replace(R.id.frame_container, fragment1).commit();

            }
        });


        llAdminOrder.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                tvbbAdminHome.setTextColor(getResources().getColor(R.color.light_white));
                tvbbAdminOrder.setTextColor(getResources().getColor(R.color.app_white));
                tvbbAdminEmployee.setTextColor(getResources().getColor(R.color.light_white));
                tvbbAdminCash.setTextColor(getResources().getColor(R.color.light_white));

                bbAdminHome.setColorFilter(getResources().getColor(R.color.light_white));
                bbAdminOrder.setColorFilter(getResources().getColor(R.color.app_white));
                bbAdminEmployee.setColorFilter(getResources().getColor(R.color.light_white));
                bbAdminCash.setColorFilter(getResources().getColor(R.color.light_white));

                Fragment fragment1 = new AdminOrderFragment();
                FragmentTransaction ft1 = getSupportFragmentManager().beginTransaction();
                ft1.replace(R.id.frame_container, fragment1).addToBackStack("").commit();

            }
        });


        llAdminEmployee.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                tvbbAdminHome.setTextColor(getResources().getColor(R.color.light_white));
                tvbbAdminOrder.setTextColor(getResources().getColor(R.color.light_white));
                tvbbAdminEmployee.setTextColor(getResources().getColor(R.color.app_white));
                tvbbAdminCash.setTextColor(getResources().getColor(R.color.light_white));

                bbAdminHome.setColorFilter(getResources().getColor(R.color.light_white));
                bbAdminOrder.setColorFilter(getResources().getColor(R.color.light_white));
                bbAdminEmployee.setColorFilter(getResources().getColor(R.color.app_white));
                bbAdminCash.setColorFilter(getResources().getColor(R.color.light_white));

                Fragment fragment1 = new AdminEmployeeListFragment();
                FragmentTransaction ft1 = getSupportFragmentManager().beginTransaction();
                ft1.replace(R.id.frame_container, fragment1).addToBackStack("").commit();

            }
        });


        llAdminCash.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                tvbbAdminHome.setTextColor(getResources().getColor(R.color.light_white));
                tvbbAdminOrder.setTextColor(getResources().getColor(R.color.light_white));
                tvbbAdminEmployee.setTextColor(getResources().getColor(R.color.light_white));
                tvbbAdminCash.setTextColor(getResources().getColor(R.color.app_white));

                bbAdminHome.setColorFilter(getResources().getColor(R.color.light_white));
                bbAdminOrder.setColorFilter(getResources().getColor(R.color.light_white));
                bbAdminEmployee.setColorFilter(getResources().getColor(R.color.light_white));
                bbAdminCash.setColorFilter(getResources().getColor(R.color.app_white));

                Fragment fragment1 = new AdminCashCollectedFragment();
                FragmentTransaction ft1 = getSupportFragmentManager().beginTransaction();
                ft1.replace(R.id.frame_container, fragment1).addToBackStack("").commit();

            }
        });

    }


    private void setDrawer() {
        drawerToggle = new ActionBarDrawerToggle(this, drawerLayout, toolbar, R.string
                .navigation_drawer_open, R.string.navigation_drawer_close) {
            public void onDrawerOpened(View drawerView) {
                super.onDrawerOpened(drawerView);
                Utils.hideKeyboard(MainActivity.this);
            }
        };

        updateDrawerToggle();
        drawerToggle.setToolbarNavigationClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Utils.hideKeyboard(MainActivity.this);
                onBackPressed();
            }
        });
        drawerLayout.addDrawerListener(drawerToggle);
    }

    private FragmentManager.OnBackStackChangedListener mBackStackChangedListener =
            new FragmentManager.OnBackStackChangedListener() {
                @Override
                public void onBackStackChanged() {
                    updateDrawerToggle();
                }
            };

    /***
     * Update drawer toggle
     */
    private void updateDrawerToggle() {
        if (drawerToggle == null) {
            return;
        }
        boolean isRoot = getSupportFragmentManager().getBackStackEntryCount() == 0;
        drawerToggle.setDrawerIndicatorEnabled(isRoot);
        if (getSupportActionBar() != null) {
            getSupportActionBar().setDisplayShowHomeEnabled(!isRoot);
            getSupportActionBar().setDisplayHomeAsUpEnabled(!isRoot);
            getSupportActionBar().setHomeButtonEnabled(!isRoot);
        }
        if (isRoot) {
            drawerToggle.syncState();
        }
    }

    @Override
    protected void onResume() {
        super.onResume();
        getSupportFragmentManager().addOnBackStackChangedListener(mBackStackChangedListener);
    }

    @Override
    protected void onPause() {
        super.onPause();
        getSupportFragmentManager().removeOnBackStackChangedListener(mBackStackChangedListener);
    }

    @Override
    public void onBackPressed() {

        if (getSupportFragmentManager().getBackStackEntryCount() > 0) {
            getSupportFragmentManager().popBackStack();
        } else if (!drawerLayout.isDrawerOpen(GravityCompat.START)) {
            drawerLayout.openDrawer(GravityCompat.START);
        } else {
            showExitAlert("e", "Are you sure you want to exit ?");
        }
    }

    void showExitAlert(final String type, String msg) {
        AlertDialog.Builder alertDialog2 = new AlertDialog.Builder(
                MainActivity.this, R.style.CustomDialogTheme);
// Setting Dialog Message
        alertDialog2.setMessage(msg);
// Setting Positive "Yes" Btn
        alertDialog2.setPositiveButton("YES",
                new DialogInterface.OnClickListener() {
                    public void onClick(DialogInterface dialog, int which) {
                        // Write your code here to execute after dialog

                        if (type.equals("e")) {
                            moveTaskToBack(true);
                            android.os.Process.killProcess(android.os.Process.myPid());
                            System.exit(1);
                        } else if (type.equals("l")) {

                            mSharedPreference.edit().putBoolean(ConstantCodes.IS_LOGIN, false).apply();
                            Intent i = new Intent(MainActivity.this, LoginActivity.class);

                            startActivity(i);

                            finish();

                        }

                    }
                });
// Setting Negative "NO" Btn
        alertDialog2.setNegativeButton("NO",
                new DialogInterface.OnClickListener() {
                    public void onClick(DialogInterface dialog, int which) {
                        // Write your code here to execute after dialog
                        dialog.cancel();
                    }
                });
// Showing Alert Dialog
        alertDialog2.show();
    }


    @Override
    public boolean onNavigationItemSelected(@NonNull MenuItem menuItem) {

        String title = "";
        int id = menuItem.getItemId();
        Fragment targetFragment = null;
        title = "Home";

        toolbar.setVisibility(View.VISIBLE);


        //************user******************

        if (id == R.id.user_profile) {
            targetFragment = new UserProfileFragment();
        } else if (id == R.id.user_book_order) {
            targetFragment = new CategoryFragment();
        } else if (id == R.id.user_inquiry) {
            targetFragment = new UserAllInquiryFragment();
        } else if (id == R.id.user_add_inquiry) {
            targetFragment = new AddInquiryFragment();
        } else if (id == R.id.user_complain) {
            targetFragment = new UserAddComplainFragment();
        } else if (id == R.id.user_newsoffer) {
            targetFragment = new NewsOfferFragment();
        } else if (id == R.id.user_rate_us) {
            targetFragment = new RatingFragment();
        } else if (id == R.id.user_feedback) {
            targetFragment = new FeedbackFragment();
        } else if (id == R.id.user_my_order) {
            targetFragment = new AllOrderFragment();
        } else if (id == R.id.user_logout) {
            showLogout("user");
        }

        // ******************employee******************

        else if (id == R.id.employee_profile) {
            targetFragment = new EmployeeProfileFragment();
        } else if (id == R.id.employee_leave) {
            targetFragment = new EmployeeAddLeaveFragment();
        } else if (id == R.id.employee_complain) {
            targetFragment = new EmployeeAddComplainFragment();
        } else if (id == R.id.employee_inquiry) {
            targetFragment = new EmployeeAssignedInquiryFragment();
        } else if (id == R.id.employee_all_leave) {
            targetFragment = new EmployeeAllLeaveFragment();
        } else if (id == R.id.emp_all_complain) {
            targetFragment = new EmployeeAllComplainFragment();
        } else if (id == R.id.employee_logout) {
            showLogout("employee");
        }

        // ******************admin******************

        else if (id == R.id.admin_profile) {
            targetFragment = new AdminProfileFragment();
        } else if (id == R.id.admin_emp_leave) {
            targetFragment = new AdminLeaveFragment();
        } else if (id == R.id.admin_manage_emp) {
            targetFragment = new AdminAddEmployeeFragment();
        } else if (id == R.id.admin_logout) {
            showLogout("admin");
        }

        if (targetFragment != null) {
            setAppTitle(title);
            closeDrawer();
            changeFragment(targetFragment, title);
        }

        return true;

    }

    public void closeDrawer() {
        drawerLayout.closeDrawer(GravityCompat.START);
    }

    public void setAppTitle(String title) {
        toolbar.setTitle(title);
    }


    private void setToolbar() {
        toolbar = (Toolbar) findViewById(R.id.toolbar);
        toolbar.setTitle(getString(R.string.app_name));
        toolbar.setTitleTextColor(ContextCompat.getColor(this, android.R.color.white));
        setSupportActionBar(toolbar);
        if (getSupportActionBar() != null) {
            getSupportActionBar().setDisplayShowTitleEnabled(false);
        }
    }


    public void changeFragment(Fragment targetFragment, String tag) {


        for (int i = 0; i < getSupportFragmentManager().getBackStackEntryCount(); ++i) {
            getSupportFragmentManager().popBackStack();
        }
        getSupportFragmentManager().beginTransaction()
                .replace(R.id.frame_container, targetFragment, tag)
                .commit();
    }


    void showLogout(final String type) {
        AlertDialog.Builder alertDialog2 = new AlertDialog.Builder(
                MainActivity.this, R.style.CustomDialogTheme);
        alertDialog2.setTitle("Logout");
        alertDialog2.setMessage("Are you sure you want to logout?");
        alertDialog2.setPositiveButton("YES",
                new DialogInterface.OnClickListener() {
                    public void onClick(DialogInterface dialog, int which) {


                        mSharedPreference.edit().putBoolean(ConstantCodes.IS_LOGIN, false).apply();
                        mSharedPreference.edit().putString(ConstantCodes.LOGIN_USER_ID, "").apply();
                        mSharedPreference.edit().putString(ConstantCodes.LOGIN_USER_NAME, "").apply();
                        mSharedPreference.edit().putString(ConstantCodes.LOGIN_USER_MOBILE, "").apply();
                        mSharedPreference.edit().putString(ConstantCodes.LOGIN_USER_IMAGE, "").apply();
                        mSharedPreference.edit().putString(ConstantCodes.LOGIN_USERTYPE, "").apply();
                        mSharedPreference.edit().putString(ConstantCodes.LOGIN_USER_ADDRESS, "").apply();
                        mSharedPreference.edit().putString(ConstantCodes.LOGIN_USER_AREA, "").apply();
                        mSharedPreference.edit().putString(ConstantCodes.LOGIN_USER_PINCODE, "").apply();
                        mSharedPreference.edit().putString(ConstantCodes.LOGIN_USER_OFFER_CODE, "").apply();

                        mSharedPreference.edit().putString(ConstantCodes.LOGIN_USER_EMPLOYEE_CODE, "").apply();
                        mSharedPreference.edit().putString(ConstantCodes.LOGIN_USER_EMPLOYEE_CITY, "").apply();
                        mSharedPreference.edit().putString(ConstantCodes.LOGIN_USER_EMPLOYEE_AADHAR_CARD, "").apply();

                        Intent i = new Intent(MainActivity.this, LoginActivity.class);
                        startActivity(i);

                        finish();


                        /*if (type.equals("user")) {

                            mSharedPreference.edit().putBoolean(ConstantCodes.IS_LOGIN, true).apply();
                            mSharedPreference.edit().putString(ConstantCodes.LOGIN_USER_ID, "").apply();
                            mSharedPreference.edit().putString(ConstantCodes.LOGIN_USER_NAME, "").apply();
                            mSharedPreference.edit().putString(ConstantCodes.LOGIN_USER_MOBILE, "").apply();
                            mSharedPreference.edit().putString(ConstantCodes.LOGIN_USER_IMAGE, "").apply();
                            mSharedPreference.edit().putString(ConstantCodes.LOGIN_USERTYPE, "").apply();
                            mSharedPreference.edit().putString(ConstantCodes.LOGIN_USER_ADDRESS, "").apply();
                            mSharedPreference.edit().putString(ConstantCodes.LOGIN_USER_AREA, "").apply();
                            mSharedPreference.edit().putString(ConstantCodes.LOGIN_USER_PINCODE, "").apply();
                            mSharedPreference.edit().putString(ConstantCodes.LOGIN_USER_OFFER_CODE, "").apply();

                            Intent i = new Intent(MainActivity.this, LoginActivity.class);
                            startActivity(i);

                            finish();
                        } else if (type.equals("employee")) {

                            mSharedPreference.edit().putBoolean(ConstantCodes.IS_LOGIN, true).apply();
                            mSharedPreference.edit().putString(ConstantCodes.LOGIN_USER_ID, "").apply();
                            mSharedPreference.edit().putString(ConstantCodes.LOGIN_USER_NAME, "").apply();
                            mSharedPreference.edit().putString(ConstantCodes.LOGIN_USER_MOBILE, "").apply();
                            mSharedPreference.edit().putString(ConstantCodes.LOGIN_USER_IMAGE, "").apply();
                            mSharedPreference.edit().putString(ConstantCodes.LOGIN_USERTYPE, "").apply();
                            mSharedPreference.edit().putString(ConstantCodes.LOGIN_USER_ADDRESS, "").apply();
                            mSharedPreference.edit().putString(ConstantCodes.LOGIN_USER_AREA, "").apply();
                            mSharedPreference.edit().putString(ConstantCodes.LOGIN_USER_PINCODE, "").apply();
                            mSharedPreference.edit().putString(ConstantCodes.LOGIN_USER_OFFER_CODE, "").apply();

                            Intent i = new Intent(MainActivity.this, LoginActivity.class);
                            startActivity(i);

                            finish();
                        } else if (type.equals("admin")) {

                            mSharedPreference.edit().putBoolean(ConstantCodes.IS_LOGIN, true).apply();
                            mSharedPreference.edit().putString(ConstantCodes.LOGIN_USER_ID, "").apply();
                            mSharedPreference.edit().putString(ConstantCodes.LOGIN_USER_NAME, "").apply();
                            mSharedPreference.edit().putString(ConstantCodes.LOGIN_USER_MOBILE, "").apply();
                            mSharedPreference.edit().putString(ConstantCodes.LOGIN_USER_IMAGE, "").apply();
                            mSharedPreference.edit().putString(ConstantCodes.LOGIN_USERTYPE, "").apply();
                            mSharedPreference.edit().putString(ConstantCodes.LOGIN_USER_ADDRESS, "").apply();
                            mSharedPreference.edit().putString(ConstantCodes.LOGIN_USER_AREA, "").apply();
                            mSharedPreference.edit().putString(ConstantCodes.LOGIN_USER_PINCODE, "").apply();
                            mSharedPreference.edit().putString(ConstantCodes.LOGIN_USER_OFFER_CODE, "").apply();

                            Intent i = new Intent(MainActivity.this, LoginActivity.class);
                            startActivity(i);

                            finish();
                        }*/


                    }
                });

        alertDialog2.show();
    }


    @Override
    public void onRequestPermissionsResult(int requestCode, @NonNull String[] permissions, @NonNull int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);

    }
}
