package com.service.care.adapter;

import android.content.Context;
import android.os.Build;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.RequiresApi;
import androidx.recyclerview.widget.RecyclerView;

import com.service.care.R;
import com.service.care.pojo.PojoCategory;
import com.service.care.pojo.PojoNewsOffer;

import java.util.ArrayList;
import java.util.List;


/**
 * Created by Rp on 6/14/2016.
 */
public class NewsOfferAdapter extends RecyclerView.Adapter<NewsOfferAdapter.MyViewHolder> {
    Context context;

    List<PojoNewsOffer.Datum> mArrayNewsOffer = new ArrayList<>();


    public class MyViewHolder extends RecyclerView.ViewHolder {

        TextView tvDescription, tvTitle;

        public MyViewHolder(View view) {
            super(view);
            tvTitle = view.findViewById(R.id.tvTitle);
            tvDescription = view.findViewById(R.id.tvDescription);


        }
    }

    public NewsOfferAdapter(Context context, List<PojoNewsOffer.Datum> mArrayNewsOffer) {
        this.mArrayNewsOffer = mArrayNewsOffer;
        this.context = context;

    }

    @Override
    public MyViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
        View itemView = LayoutInflater.from(parent.getContext())
                .inflate(R.layout.item_news_offer, parent, false);


        return new MyViewHolder(itemView);

    }

    @RequiresApi(api = Build.VERSION_CODES.JELLY_BEAN)
    @Override
    public void onBindViewHolder(final MyViewHolder holder, final int position) {

        final PojoNewsOffer.Datum item = mArrayNewsOffer.get(position);


        holder.tvTitle.setText("" + item.getTitle());
        holder.tvDescription.setText("" + item.getDetail());


    }

    @Override
    public int getItemCount() {
        return mArrayNewsOffer.size();
    }


}


