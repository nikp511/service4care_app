package com.service.care.fragments.users;

import android.content.Context;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.preference.PreferenceManager;
import android.text.TextUtils;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ProgressBar;
import android.widget.RelativeLayout;
import android.widget.TextView;

import androidx.appcompat.widget.Toolbar;
import androidx.fragment.app.Fragment;
import androidx.recyclerview.widget.DefaultItemAnimator;
import androidx.recyclerview.widget.GridLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.service.care.R;
import com.service.care.adapter.AllComplainAdapter;
import com.service.care.application.MyApplication;
import com.service.care.constants.ConstantCodes;
import com.service.care.pojo.PojoAllComplain;
import com.service.care.utils.Utils;

import java.util.ArrayList;
import java.util.List;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

/**
 * Created by Rp on 8/30/2016.
 */
public class UserAllComplainFragment extends Fragment {

    private View mParentView;

    private Context mContext;
    RelativeLayout mRelativeMain;
    ProgressBar mProgressBar;

    MyApplication mApplication;
    private SharedPreferences mSharedPreference;

    TextView tvAll, tvCompleted, tvPending;

    RecyclerView rvComplain;

    AllComplainAdapter allComplainAdapter;

    List<PojoAllComplain.Datum> mArrayAllComaplin = new ArrayList<>();

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        mParentView = inflater.inflate(R.layout.fragment_user_all_complain, container, false);
        mApplication = (MyApplication) getActivity().getApplicationContext();
        mContext = getActivity();
        setHasOptionsMenu(true);
        mSharedPreference = PreferenceManager.getDefaultSharedPreferences(getActivity());

        initialise();
        listners();

        tvAll.performClick();

        return mParentView;

    }


    void initialise() {

        Toolbar mToolbar = (Toolbar) getActivity().findViewById(R.id.toolbar);
        mToolbar.setTitle("My Complain");
        mToolbar.setVisibility(View.VISIBLE);

        mRelativeMain = mParentView.findViewById(R.id.relative_main);
        mProgressBar = mParentView.findViewById(R.id.progressbar);

        tvAll = mParentView.findViewById(R.id.tvAll);
        tvCompleted = mParentView.findViewById(R.id.tvCompleted);
        tvPending = mParentView.findViewById(R.id.tvPending);

        rvComplain = mParentView.findViewById(R.id.rvComplain);
        GridLayoutManager layoutManagerContact = new GridLayoutManager(mContext, 1);
        rvComplain.setLayoutManager(layoutManagerContact);
        rvComplain.setItemAnimator(new DefaultItemAnimator());


    }

    void listners() {

        tvAll.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                tvAll.setTextColor(mContext.getResources().getColor(R.color.app_white));
                tvCompleted.setTextColor(mContext.getResources().getColor(R.color.app_black));
                tvPending.setTextColor(mContext.getResources().getColor(R.color.app_black));

                tvAll.setBackground(mContext.getResources().getDrawable(R.drawable.app_rect));
                tvCompleted.setBackground(mContext.getResources().getDrawable(R.drawable.app_border));
                tvPending.setBackground(mContext.getResources().getDrawable(R.drawable.app_border));

                networkCallComplain(null);

            }
        });

        tvCompleted.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                tvCompleted.setTextColor(mContext.getResources().getColor(R.color.app_white));
                tvAll.setTextColor(mContext.getResources().getColor(R.color.app_black));
                tvPending.setTextColor(mContext.getResources().getColor(R.color.app_black));

                tvCompleted.setBackground(mContext.getResources().getDrawable(R.drawable.app_rect));
                tvAll.setBackground(mContext.getResources().getDrawable(R.drawable.app_border));
                tvPending.setBackground(mContext.getResources().getDrawable(R.drawable.app_border));

                networkCallComplain("c");

            }
        });

        tvPending.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                tvPending.setTextColor(mContext.getResources().getColor(R.color.app_white));
                tvCompleted.setTextColor(mContext.getResources().getColor(R.color.app_black));
                tvAll.setTextColor(mContext.getResources().getColor(R.color.app_black));

                tvPending.setBackground(mContext.getResources().getDrawable(R.drawable.app_rect));
                tvCompleted.setBackground(mContext.getResources().getDrawable(R.drawable.app_border));
                tvAll.setBackground(mContext.getResources().getDrawable(R.drawable.app_border));

                networkCallComplain("p");

            }
        });

    }

    private void networkCallComplain(String status) {
        if (mApplication.isInternetConnected()) {

            mProgressBar.setVisibility(View.VISIBLE);

            mApplication.getRetroFitInterface().UserMyComplaints(mSharedPreference.getString(ConstantCodes.LOGIN_USER_ID, ""),
                    status).enqueue(mCallbackComplain);


        } else {
            Utils.showSnackBar(getActivity(), getResources().getString(R.string
                    .message_connection));
            mProgressBar.setVisibility(View.GONE);
        }
    }


    /**
     * Callback for ws.wolfsoft.propertyplanetapp.network call
     */
    private Callback<PojoAllComplain> mCallbackComplain = new Callback<PojoAllComplain>() {
        @Override
        public void onResponse(Call<PojoAllComplain> call, Response<PojoAllComplain> response) {
            if (response != null && response.isSuccessful() && response.body() != null) {

                PojoAllComplain pojoParticipants = response.body();

                mArrayAllComaplin.clear();

                if (pojoParticipants.getStatus() == 1) {

                    if (pojoParticipants.getData() != null) {
                        if (pojoParticipants.getData().size() > 0) {
                            mArrayAllComaplin.addAll(pojoParticipants.getData());

                            allComplainAdapter = new AllComplainAdapter(mContext, mArrayAllComaplin);
                            rvComplain.setAdapter(allComplainAdapter);

                        } else {
                            rvComplain.setAdapter(null);
                        }
                    } else {
                        rvComplain.setAdapter(null);
                    }

                } else {
                    rvComplain.setAdapter(null);
                    if (!TextUtils.isEmpty(pojoParticipants.getMessage())) {
                        Utils.showSnackBar(getActivity(), pojoParticipants.getMessage());

                    } else {
                        Utils.showSnackBar(getActivity(), getString(R.string
                                .message_something_wrong));
                    }

                }
            } else {
                Utils.showSnackBar(getActivity(), getString(R.string.message_something_wrong));
                mProgressBar.setVisibility(View.GONE);
            }
            mProgressBar.setVisibility(View.GONE);

        }

        @Override
        public void onFailure(Call<PojoAllComplain> call, Throwable t) {
            try {
                Utils.showSnackBar(getActivity(), getString(R.string
                        .message_something_wrong));
                mProgressBar.setVisibility(View.GONE);
            } catch (Exception e) {

            }
        }
    };


}
