package com.service.care.adapter;

import android.content.Context;
import android.os.Build;
import android.text.Editable;
import android.text.TextWatcher;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.RequiresApi;
import androidx.recyclerview.widget.RecyclerView;

import com.service.care.R;
import com.service.care.pojo.PojoAllInquiry;
import com.service.care.pojo.PojoEmpAssignedInquiry;

import java.util.ArrayList;
import java.util.List;


/**
 * Created by Rp on 6/14/2016.
 */
public class AllInquiryDetailAdapter extends RecyclerView.Adapter<AllInquiryDetailAdapter.MyViewHolder> {
    Context context;

    List<PojoEmpAssignedInquiry.Datum> mArrayAllInquiry = new ArrayList<>();
    CustomClick customClick;


    public class MyViewHolder extends RecyclerView.ViewHolder {

        TextView tvName, tvRupess, tvAddress, tvMobile, tvStartTime, tvEndTime, tvSubmit;
        EditText etMoney;
        public MyCustomEditTextListener myCustomEditTextListener;

        public MyViewHolder(View view, MyCustomEditTextListener myCustomEditTextListener) {
            super(view);

            this.myCustomEditTextListener = myCustomEditTextListener;

            tvRupess = view.findViewById(R.id.tvRupess);
            tvName = view.findViewById(R.id.tvName);
            tvAddress = view.findViewById(R.id.tvAddress);
            tvMobile = view.findViewById(R.id.tvMobile);
            tvStartTime = view.findViewById(R.id.tvStartTime);
            tvEndTime = view.findViewById(R.id.tvEndTime);
            etMoney = view.findViewById(R.id.etMoney);
            tvSubmit = view.findViewById(R.id.tvSubmit);

            etMoney.addTextChangedListener(myCustomEditTextListener);


        }
    }

    public AllInquiryDetailAdapter(Context context, List<PojoEmpAssignedInquiry.Datum> mArrayAllInquiry, CustomClick customClick) {
        this.mArrayAllInquiry = mArrayAllInquiry;
        this.context = context;
        this.customClick = customClick;

    }

    @Override
    public MyViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
        View itemView = LayoutInflater.from(parent.getContext())
                .inflate(R.layout.item_employee_inquiry_detail, parent, false);


        return new MyViewHolder(itemView,new MyCustomEditTextListener());

    }

    @RequiresApi(api = Build.VERSION_CODES.JELLY_BEAN)
    @Override
    public void onBindViewHolder(final MyViewHolder holder, final int position) {

        final PojoEmpAssignedInquiry.Datum item = mArrayAllInquiry.get(position);

        holder.myCustomEditTextListener.updatePosition(holder.getAdapterPosition());

        holder.tvName.setText("" + item.getProductName());
        holder.tvRupess.setText("" + item.getPrice());
        holder.tvAddress.setText("" + item.getAddress());
        holder.tvMobile.setText("" + item.getMobile());

        if (item.getAndroidStartTime() != null) {
            if (!item.getAndroidStartTime().equals("")) {
                holder.tvStartTime.setText("" + item.getAndroidStartTime());
            }
        }

        if (item.getAndroidEndTime() != null) {
            if (!item.getAndroidEndTime().equals("")) {
                holder.tvEndTime.setText("" + item.getAndroidEndTime());
            }
        }

        if (item.getAndroidfinalAmount() != null) {
            if (!item.getAndroidfinalAmount().equals("")) {
                holder.etMoney.setText("" + item.getAndroidfinalAmount());
            }
        }

        holder.tvStartTime.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                customClick.submitClick(item, "st", "");
            }
        });

        holder.tvEndTime.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                customClick.submitClick(item, "et", "");
            }
        });



       /* holder.etMoney.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence s, int start, int count, int after) {

            }

            @Override
            public void onTextChanged(CharSequence s, int start, int before, int count) {
                customClick.submitClick(item, "amt", s.toString());
            }

            @Override
            public void afterTextChanged(Editable s) {
            }
        });*/

        holder.tvSubmit.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                customClick.submitClick(item, "submit", "");
            }
        });


    }

    private class MyCustomEditTextListener implements TextWatcher {
        private int position;

        public void updatePosition(int position) {
            this.position = position;
        }

        @Override
        public void beforeTextChanged(CharSequence charSequence, int i, int i2, int i3) {
            // no op
        }

        @Override
        public void onTextChanged(CharSequence charSequence, int i, int i2, int i3) {
            mArrayAllInquiry.get(position).setAndroidfinalAmount(charSequence.toString());
        }

        @Override
        public void afterTextChanged(Editable editable) {
            // no op
        }
    }

    @Override
    public int getItemCount() {
        return mArrayAllInquiry.size();
    }

    public interface CustomClick {

        void submitClick(PojoEmpAssignedInquiry.Datum datum, String what, String extra);

    }

}


