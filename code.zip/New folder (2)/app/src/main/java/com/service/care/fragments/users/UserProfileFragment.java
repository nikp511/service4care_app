package com.service.care.fragments.users;

import android.Manifest;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.pm.PackageManager;
import android.graphics.BitmapFactory;
import android.net.Uri;
import android.os.Bundle;
import android.preference.PreferenceManager;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.View;
import android.view.ViewGroup;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.ProgressBar;
import android.widget.RelativeLayout;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.appcompat.widget.Toolbar;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;
import androidx.fragment.app.Fragment;

import com.bumptech.glide.Glide;
import com.bumptech.glide.load.engine.DiskCacheStrategy;
import com.bumptech.glide.request.RequestOptions;
import com.google.android.material.navigation.NavigationView;
import com.google.gson.JsonObject;
import com.service.care.R;
import com.service.care.application.MyApplication;
import com.service.care.constants.ConstantCodes;
import com.service.care.helpers.UploadServiceHelper;
import com.service.care.utils.Utils;

import net.gotev.uploadservice.MultipartUploadRequest;
import net.gotev.uploadservice.ServerResponse;
import net.gotev.uploadservice.UploadInfo;
import net.gotev.uploadservice.UploadStatusDelegate;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.io.File;
import java.io.FileNotFoundException;
import java.net.MalformedURLException;
import java.security.Permission;
import java.util.ArrayList;
import java.util.List;

import static android.app.Activity.RESULT_OK;

/**
 * Created by Rp on 8/30/2016.
 */
public class UserProfileFragment extends Fragment {

    private View mParentView;

    private Context mContext;
    RelativeLayout mRelativeMain;
    ProgressBar mProgressBar;

    MyApplication mApplication;
    private SharedPreferences mSharedPreference;

    ImageView ivIcon;
    TextView tvName;
    EditText etUsername, etMobile, etAddress, etArea, etPincode, etOfferCode;

    private Uri filePath;

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        mParentView = inflater.inflate(R.layout.fragment_user_profile, container, false);
        mApplication = (MyApplication) getActivity().getApplicationContext();
        mContext = getActivity();
        setHasOptionsMenu(true);
        mSharedPreference = PreferenceManager.getDefaultSharedPreferences(getActivity());

        initialise();

        return mParentView;

    }


    void initialise() {

        Toolbar mToolbar = (Toolbar) getActivity().findViewById(R.id.toolbar);
        mToolbar.setTitle("My Profile");
        mToolbar.setVisibility(View.VISIBLE);

        mRelativeMain = mParentView.findViewById(R.id.relative_main);
        mProgressBar = mParentView.findViewById(R.id.progressbar);

        ivIcon = mParentView.findViewById(R.id.ivIcon);

        if (mSharedPreference.getString(ConstantCodes.LOGIN_USER_IMAGE, "") != null) {
            if (!mSharedPreference.getString(ConstantCodes.LOGIN_USER_IMAGE, "").equals("")) {
                Glide.with(mContext).load(mSharedPreference.getString(ConstantCodes.LOGIN_USER_IMAGE, ""))
                        .apply(RequestOptions.skipMemoryCacheOf(true))
                        .apply(RequestOptions.diskCacheStrategyOf(DiskCacheStrategy.NONE))
                        .into(ivIcon);
            }
        }

        tvName = mParentView.findViewById(R.id.tvName);
        if (mSharedPreference.getString(ConstantCodes.LOGIN_USER_NAME, "").equals("")) {
            tvName.setText("Hello, Guest");
        } else {
            tvName.setText("Hello, " + mSharedPreference.getString(ConstantCodes.LOGIN_USER_NAME, ""));

        }

        etUsername = mParentView.findViewById(R.id.etUsername);
        etMobile = mParentView.findViewById(R.id.etMobile);
        etAddress = mParentView.findViewById(R.id.etAddress);
        etArea = mParentView.findViewById(R.id.etArea);
        etPincode = mParentView.findViewById(R.id.etPincode);
        etOfferCode = mParentView.findViewById(R.id.etOfferCode);

        etUsername.setText("" + mSharedPreference.getString(ConstantCodes.LOGIN_USER_NAME, ""));
        etMobile.setText("" + mSharedPreference.getString(ConstantCodes.LOGIN_USER_MOBILE, ""));
        etAddress.setText("" + mSharedPreference.getString(ConstantCodes.LOGIN_USER_ADDRESS, ""));
        etArea.setText("" + mSharedPreference.getString(ConstantCodes.LOGIN_USER_AREA, ""));
        etPincode.setText("" + mSharedPreference.getString(ConstantCodes.LOGIN_USER_PINCODE, ""));
        etOfferCode.setText("" + mSharedPreference.getString(ConstantCodes.LOGIN_USER_OFFER_CODE, ""));

        ivIcon.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Utils.hideKeyboard(getActivity());

                int permissionCheck = ContextCompat.checkSelfPermission(getActivity(), Manifest.permission.READ_EXTERNAL_STORAGE);
                int permissionCheck1 = ContextCompat.checkSelfPermission(getActivity(), Manifest.permission.WRITE_EXTERNAL_STORAGE);

                if (permissionCheck != PackageManager.PERMISSION_GRANTED || permissionCheck1 != PackageManager.PERMISSION_GRANTED) {
                    requestPermissions(new String[]{Manifest.permission.READ_EXTERNAL_STORAGE, Manifest.permission.WRITE_EXTERNAL_STORAGE}, 100);
                } else {
                    //Do your work
                    openImageChooser(100);
                }

            }
        });

    }

    /* Choose an image from Gallery */
    void openImageChooser(int reqCode) {
        Intent intent = new Intent();
        intent.setType("image/*");
        intent.setAction(Intent.ACTION_PICK);
        startActivityForResult(Intent.createChooser(intent, "Select Picture"), reqCode);
    }

    public void onActivityResult(int requestCode, int resultCode, Intent data) {

        if (requestCode == 100 && resultCode == RESULT_OK && data != null && data.getData() != null) {

            filePath = data.getData();

            ivIcon.setImageURI(filePath);

        }
    }

    void uploadProfileDetails() {


        if (filePath != null) {

            try {
                mProgressBar.setVisibility(View.VISIBLE);
                String path = UploadServiceHelper.getPath(filePath, mContext);

                String result = "";
                result = new MultipartUploadRequest(mContext, "", ConstantCodes.BASE_URL + ConstantCodes.METHOD_UPDATE_PROFILE)
                        .addFileToUpload(path, "image") //Adding file
                        .addParameter("user_id", mSharedPreference.getString(ConstantCodes.LOGIN_USER_ID, ""))
                        .addParameter("name", etUsername.getText().toString() + "")
                        .addParameter("address", etAddress.getText().toString().trim() + "")
                        .addParameter("area", etArea.getText().toString().trim() + "")
                        .addParameter("pincode", etPincode.getText().toString().trim() + "")
                        .addParameter("offerCode", etOfferCode.getText().toString().trim() + "")
                        .addParameter("mobile", etMobile.getText().toString().trim() + "")


                        .setMaxRetries(2)
                        .setDelegate(new UploadStatusDelegate() {
                            @Override
                            public void onProgress(Context context, UploadInfo uploadInfo) {

                            }

                            @Override
                            public void onError(Context context, UploadInfo uploadInfo, ServerResponse serverResponse, Exception e) {

                                mProgressBar.setVisibility(View.GONE);
                                if (e != null) {
                                    Toast.makeText(mContext, "Error: " + e.getMessage(), Toast.LENGTH_SHORT).show();
                                } else {

                                    // Utils.showSnackBar(getActivity(), serverResponse.getBodyAsString());
                                    Toast.makeText(mContext, "Something went wrong", Toast.LENGTH_SHORT).show();

                                }
                            }

                            @Override
                            public void onCompleted(Context context, UploadInfo uploadInfo, ServerResponse serverResponse) {

                                Log.e("server response", "" + serverResponse.getBodyAsString());
                                JSONObject jsonObject = null;
                                try {
                                    jsonObject = new JSONObject(serverResponse.getBodyAsString());
                                    int code = jsonObject.optInt("status");
                                    if (code == 1) {

                                        mProgressBar.setVisibility(View.GONE);
                                        Utils.showSnackBar(getActivity(), jsonObject.optString("message"));
                                        filePath = null;

                                        JSONObject array = jsonObject.getJSONObject("data");

                                        mSharedPreference.edit().putString(ConstantCodes.LOGIN_USER_NAME, array.getString("name")).apply();
                                        mSharedPreference.edit().putString(ConstantCodes.LOGIN_USER_MOBILE, array.getString("mobile")).apply();
                                        mSharedPreference.edit().putString(ConstantCodes.LOGIN_USER_IMAGE, array.getString("image")).apply();
                                        mSharedPreference.edit().putString(ConstantCodes.LOGIN_USER_ADDRESS, array.getString("address")).apply();
                                        mSharedPreference.edit().putString(ConstantCodes.LOGIN_USER_AREA, array.getString("area")).apply();
                                        mSharedPreference.edit().putString(ConstantCodes.LOGIN_USER_PINCODE, array.getString("pincode")).apply();
                                        mSharedPreference.edit().putString(ConstantCodes.LOGIN_USER_OFFER_CODE, array.getString("offerCode")).apply();

                                        if (mSharedPreference.getString(ConstantCodes.LOGIN_USER_IMAGE, "") != null) {
                                            if (!mSharedPreference.getString(ConstantCodes.LOGIN_USER_IMAGE, "").equals("")) {
                                                Glide.with(mContext).load(mSharedPreference.getString(ConstantCodes.LOGIN_USER_IMAGE, ""))
                                                        .apply(RequestOptions.skipMemoryCacheOf(true))
                                                        .apply(RequestOptions.diskCacheStrategyOf(DiskCacheStrategy.NONE))
                                                        .into(ivIcon);
                                            }
                                        }

                                        if (mSharedPreference.getString(ConstantCodes.LOGIN_USER_NAME, "").equals("")) {
                                            tvName.setText("Hello, Guest");
                                        } else {
                                            tvName.setText("Hello, " + mSharedPreference.getString(ConstantCodes.LOGIN_USER_NAME, ""));

                                        }

                                        etUsername.setText("" + mSharedPreference.getString(ConstantCodes.LOGIN_USER_NAME, ""));
                                        etMobile.setText("" + mSharedPreference.getString(ConstantCodes.LOGIN_USER_MOBILE, ""));
                                        etAddress.setText("" + mSharedPreference.getString(ConstantCodes.LOGIN_USER_ADDRESS, ""));
                                        etArea.setText("" + mSharedPreference.getString(ConstantCodes.LOGIN_USER_AREA, ""));
                                        etPincode.setText("" + mSharedPreference.getString(ConstantCodes.LOGIN_USER_PINCODE, ""));
                                        etOfferCode.setText("" + mSharedPreference.getString(ConstantCodes.LOGIN_USER_OFFER_CODE, ""));

                                        // code for updating left panel name
                                        NavigationView navigationView;
                                        navigationView = getActivity().findViewById(R.id.nav_view);
                                        View headerView = navigationView.getHeaderView(0);
                                        TextView tvLeftHeaderName = (TextView) headerView.findViewById(R.id.tvName);
                                        if (mSharedPreference.getString(ConstantCodes.LOGIN_USER_NAME, "").equals("")) {
                                            tvLeftHeaderName.setText("Hello, Guest");
                                        } else {
                                            tvLeftHeaderName.setText("Hello, " + mSharedPreference.getString(ConstantCodes.LOGIN_USER_NAME, ""));

                                        }

                                    } else if (code == 0) {
                                        mProgressBar.setVisibility(View.GONE);
                                        Utils.showSnackBar(getActivity(), "Please fill all details to update profile");
                                    }


                                } catch (JSONException e) {
                                    mProgressBar.setVisibility(View.GONE);
                                    e.printStackTrace();
                                }


                            }

                            @Override
                            public void onCancelled(Context context, UploadInfo uploadInfo) {
                                Log.e("photo cancel", "error");
                            }
                        })
                        .startUpload();

            } catch (FileNotFoundException e) {
                Toast.makeText(mContext, "file" + e.getMessage(), Toast.LENGTH_SHORT).show();
                e.printStackTrace();
            } catch (MalformedURLException e) {
                Toast.makeText(mContext, "malformed" + e.getMessage(), Toast.LENGTH_SHORT).show();
                e.printStackTrace();
            } catch (Exception e) {
                Toast.makeText(mContext, "error" + e.getMessage(), Toast.LENGTH_SHORT).show();
            }


        } else {

            try {
                mProgressBar.setVisibility(View.VISIBLE);

                String result = "";
                result = new MultipartUploadRequest(mContext, "", ConstantCodes.BASE_URL + ConstantCodes.METHOD_UPDATE_PROFILE)
                        .addParameter("user_id", mSharedPreference.getString(ConstantCodes.LOGIN_USER_ID, ""))
                        .addParameter("name", etUsername.getText().toString() + "")
                        .addParameter("address", etAddress.getText().toString().trim() + "")
                        .addParameter("area", etArea.getText().toString().trim() + "")
                        .addParameter("pincode", etPincode.getText().toString().trim() + "")
                        .addParameter("offerCode", etOfferCode.getText().toString().trim() + "")
                        .addParameter("mobile", etMobile.getText().toString().trim() + "")

                        .setMaxRetries(2)
                        .setDelegate(new UploadStatusDelegate() {
                            @Override
                            public void onProgress(Context context, UploadInfo uploadInfo) {

                            }

                            @Override
                            public void onError(Context context, UploadInfo uploadInfo, ServerResponse serverResponse, Exception e) {

                                mProgressBar.setVisibility(View.GONE);
                                if (e != null) {
                                    Toast.makeText(mContext, "Error: " + e.getMessage(), Toast.LENGTH_SHORT).show();
                                } else {

                                    // Utils.showSnackBar(getActivity(), serverResponse.getBodyAsString());
                                    Toast.makeText(mContext, "Something went wrong", Toast.LENGTH_SHORT).show();

                                }
                            }

                            @Override
                            public void onCompleted(Context context, UploadInfo uploadInfo, ServerResponse serverResponse) {

                                Log.e("server response", "" + serverResponse.getBodyAsString());
                                JSONObject jsonObject = null;
                                try {
                                    jsonObject = new JSONObject(serverResponse.getBodyAsString());
                                    int code = jsonObject.optInt("status");
                                    if (code == 1) {

                                        mProgressBar.setVisibility(View.GONE);
                                        Utils.showSnackBar(getActivity(), jsonObject.optString("message"));
                                        filePath = null;

                                        JSONObject array = jsonObject.getJSONObject("data");

                                        mSharedPreference.edit().putString(ConstantCodes.LOGIN_USER_NAME, array.getString("name")).apply();
                                        mSharedPreference.edit().putString(ConstantCodes.LOGIN_USER_MOBILE, array.getString("mobile")).apply();
                                        mSharedPreference.edit().putString(ConstantCodes.LOGIN_USER_IMAGE, array.getString("image")).apply();
                                        mSharedPreference.edit().putString(ConstantCodes.LOGIN_USER_ADDRESS, array.getString("address")).apply();
                                        mSharedPreference.edit().putString(ConstantCodes.LOGIN_USER_AREA, array.getString("area")).apply();
                                        mSharedPreference.edit().putString(ConstantCodes.LOGIN_USER_PINCODE, array.getString("pincode")).apply();
                                        mSharedPreference.edit().putString(ConstantCodes.LOGIN_USER_OFFER_CODE, array.getString("offerCode")).apply();

                                        if (mSharedPreference.getString(ConstantCodes.LOGIN_USER_IMAGE, "") != null) {
                                            if (!mSharedPreference.getString(ConstantCodes.LOGIN_USER_IMAGE, "").equals("")) {
                                                Glide.with(mContext).load(mSharedPreference.getString(ConstantCodes.LOGIN_USER_IMAGE, ""))
                                                        .apply(RequestOptions.skipMemoryCacheOf(true))
                                                        .apply(RequestOptions.diskCacheStrategyOf(DiskCacheStrategy.NONE))
                                                        .into(ivIcon);
                                            }
                                        }

                                        if (mSharedPreference.getString(ConstantCodes.LOGIN_USER_NAME, "").equals("")) {
                                            tvName.setText("Hello, Guest");
                                        } else {
                                            tvName.setText("Hello, " + mSharedPreference.getString(ConstantCodes.LOGIN_USER_NAME, ""));

                                        }

                                        etUsername.setText("" + mSharedPreference.getString(ConstantCodes.LOGIN_USER_NAME, ""));
                                        etMobile.setText("" + mSharedPreference.getString(ConstantCodes.LOGIN_USER_MOBILE, ""));
                                        etAddress.setText("" + mSharedPreference.getString(ConstantCodes.LOGIN_USER_ADDRESS, ""));
                                        etArea.setText("" + mSharedPreference.getString(ConstantCodes.LOGIN_USER_AREA, ""));
                                        etPincode.setText("" + mSharedPreference.getString(ConstantCodes.LOGIN_USER_PINCODE, ""));
                                        etOfferCode.setText("" + mSharedPreference.getString(ConstantCodes.LOGIN_USER_OFFER_CODE, ""));

                                        // code for updating left panel name
                                        NavigationView navigationView;
                                        navigationView = getActivity().findViewById(R.id.nav_view);
                                        View headerView = navigationView.getHeaderView(0);
                                        TextView tvLeftHeaderName = (TextView) headerView.findViewById(R.id.tvName);
                                        if (mSharedPreference.getString(ConstantCodes.LOGIN_USER_NAME, "").equals("")) {
                                            tvLeftHeaderName.setText("Hello, Guest");
                                        } else {
                                            tvLeftHeaderName.setText("Hello, " + mSharedPreference.getString(ConstantCodes.LOGIN_USER_NAME, ""));

                                        }

                                    } else {
                                        mProgressBar.setVisibility(View.GONE);
                                        Utils.showSnackBar(getActivity(), "Something went wrong, Please try again later");
                                    }


                                } catch (JSONException e) {
                                    mProgressBar.setVisibility(View.GONE);
                                    e.printStackTrace();
                                }


                            }

                            @Override
                            public void onCancelled(Context context, UploadInfo uploadInfo) {
                                Log.e("photo cancel", "error");
                            }
                        })
                        .startUpload();

            } catch (MalformedURLException e) {
                Toast.makeText(mContext, "malformed" + e.getMessage(), Toast.LENGTH_SHORT).show();
                e.printStackTrace();
            } catch (Exception e) {
                Toast.makeText(mContext, "error" + e.getMessage(), Toast.LENGTH_SHORT).show();
            }

        }


    }

    @Override
    public void onCreateOptionsMenu(@NonNull Menu menu, @NonNull MenuInflater inflater) {
        super.onCreateOptionsMenu(menu, inflater);

        inflater.inflate(R.menu.option_menu_profile_save, menu);

    }

    @Override
    public boolean onOptionsItemSelected(@NonNull MenuItem item) {

        if (item.getItemId() == R.id.save) {

            Utils.hideKeyboard(getActivity());

            if (!etUsername.getText().toString().equals("")) {
                if (!etMobile.getText().toString().equals("")) {
                    if (!etAddress.getText().toString().equals("")) {
                        if (!etArea.getText().toString().equals("")) {
                            if (!etPincode.getText().toString().equals("")) {
                                uploadProfileDetails();
                            } else {
                                Utils.showSnackBar(getActivity(), "Enter Pincode");
                            }
                        } else {
                            Utils.showSnackBar(getActivity(), "Enter Area");
                        }
                    } else {
                        Utils.showSnackBar(getActivity(), "Enter Address");
                    }
                } else {
                    Utils.showSnackBar(getActivity(), "Enter Mobile Number");
                }
            } else {
                Utils.showSnackBar(getActivity(), "Enter User Name");
            }


        }

        return super.onOptionsItemSelected(item);
    }

    @Override
    public void onRequestPermissionsResult(int requestCode, @NonNull String[] permissions, @NonNull int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);

        if (requestCode == 100) {

            if (grantResults.length > 0 && grantResults[0] == PackageManager.PERMISSION_GRANTED) {
                if (grantResults.length > 0 && grantResults[1] == PackageManager.PERMISSION_GRANTED) {
                    openImageChooser(100);
                } else {
                    Toast.makeText(mContext, "You need to grant permission to select photo", Toast.LENGTH_SHORT).show();
                }
            } else {
                Toast.makeText(mContext, "You need to grant permission to select photo", Toast.LENGTH_SHORT).show();
            }

        }
    }
}
