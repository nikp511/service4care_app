package com.service.care.fragments;

import android.content.Context;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.preference.PreferenceManager;
import android.text.TextUtils;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.LinearLayout;
import android.widget.ProgressBar;
import android.widget.RelativeLayout;
import android.widget.TextView;

import androidx.appcompat.widget.Toolbar;
import androidx.fragment.app.Fragment;

import com.service.care.R;
import com.service.care.application.MyApplication;
import com.service.care.constants.ConstantCodes;
import com.service.care.pojo.PojoCommon;
import com.service.care.utils.Utils;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

/**
 * Created by Rp on 8/30/2016.
 */
public class FeedbackFragment extends Fragment {

    private View mParentView;

    private Context mContext;
    RelativeLayout mRelativeMain;
    ProgressBar mProgressBar;

    MyApplication mApplication;
    private SharedPreferences mSharedPreference;

    TextView tvSubmit;

    LinearLayout ll1, ll2, ll3;

    String rate = "";

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        mParentView = inflater.inflate(R.layout.fragment_feedback, container, false);
        mApplication = (MyApplication) getActivity().getApplicationContext();
        mContext = getActivity();
        setHasOptionsMenu(true);
        mSharedPreference = PreferenceManager.getDefaultSharedPreferences(getActivity());

        initialise();

        return mParentView;

    }


    void initialise() {

        Toolbar mToolbar = (Toolbar) getActivity().findViewById(R.id.toolbar);
        mToolbar.setTitle("Feedback");
        mToolbar.setVisibility(View.VISIBLE);

        mRelativeMain = mParentView.findViewById(R.id.relative_main);
        mProgressBar = mParentView.findViewById(R.id.progressbar);

        tvSubmit = mParentView.findViewById(R.id.tvSubmit);
        ll1 = mParentView.findViewById(R.id.ll1);
        ll2 = mParentView.findViewById(R.id.ll2);
        ll3 = mParentView.findViewById(R.id.ll3);

        ll1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                ll1.setBackgroundColor(mContext.getResources().getColor(R.color.green));
                ll2.setBackgroundColor(mContext.getResources().getColor(R.color.colorPrimary));
                ll3.setBackgroundColor(mContext.getResources().getColor(R.color.colorPrimary));

                rate = "1";
            }
        });

        ll2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                ll1.setBackgroundColor(mContext.getResources().getColor(R.color.colorPrimary));
                ll2.setBackgroundColor(mContext.getResources().getColor(R.color.green));
                ll3.setBackgroundColor(mContext.getResources().getColor(R.color.colorPrimary));
                rate = "2";
            }
        });


        ll3.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                ll1.setBackgroundColor(mContext.getResources().getColor(R.color.colorPrimary));
                ll2.setBackgroundColor(mContext.getResources().getColor(R.color.colorPrimary));
                ll3.setBackgroundColor(mContext.getResources().getColor(R.color.green));

                rate = "3";
            }
        });

        tvSubmit.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                if (rate.equals("")) {
                    Utils.showSnackBar(getActivity(), "Please select rating to submit");
                } else {
                    networkCallFeedback(rate);
                }
            }
        });
    }


    private void networkCallFeedback(String rate) {
        if (mApplication.isInternetConnected()) {

            mProgressBar.setVisibility(View.VISIBLE);

            mApplication.getRetroFitInterface().UserFeedback(mSharedPreference.getString(ConstantCodes.LOGIN_USER_ID, ""),
                    rate).enqueue(mCallbackAddComplain);


        } else {
            Utils.showSnackBar(getActivity(), getResources().getString(R.string
                    .message_connection));
            mProgressBar.setVisibility(View.GONE);
        }
    }

    /**
     * Callback for ws.wolfsoft.propertyplanetapp.network call
     */
    private Callback<PojoCommon> mCallbackAddComplain = new Callback<PojoCommon>() {
        @Override
        public void onResponse(Call<PojoCommon> call, Response<PojoCommon> response) {

            try {
                if (response != null && response.isSuccessful() && response.body() != null) {

                    PojoCommon pojoParticipants = response.body();

                    if (pojoParticipants.getStatus() == 1) {

                        Utils.showSnackBar(getActivity(), "" + pojoParticipants.getMessage());

                    } else {
                        if (!TextUtils.isEmpty(pojoParticipants.getMessage())) {
                            Utils.showSnackBar(getActivity(), pojoParticipants.getMessage());

                        } else {
                            Utils.showSnackBar(getActivity(), getString(R.string
                                    .message_something_wrong));
                        }

                    }
                } else {
                    Utils.showSnackBar(getActivity(), getString(R.string.message_something_wrong));
                    mProgressBar.setVisibility(View.GONE);
                }
                mProgressBar.setVisibility(View.GONE);
            } catch (Exception e) {

            }


        }

        @Override
        public void onFailure(Call<PojoCommon> call, Throwable t) {
            try {
                Utils.showSnackBar(getActivity(), getString(R.string
                        .message_something_wrong));
                mProgressBar.setVisibility(View.GONE);
            } catch (Exception e) {

            }
        }
    };


}
