package com.service.care.adapter;

import android.content.Context;
import android.os.Build;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.RequiresApi;
import androidx.recyclerview.widget.RecyclerView;

import com.service.care.R;
import com.service.care.pojo.PojoAllInquiry;
import com.service.care.pojo.PojoAllOrder;

import java.util.ArrayList;
import java.util.List;


/**
 * Created by Rp on 6/14/2016.
 */
public class AllOrderAdapter extends RecyclerView.Adapter<AllOrderAdapter.MyViewHolder> {
    Context context;

    List<PojoAllOrder.Datum> mArrayAllOrder = new ArrayList<>();


    public class MyViewHolder extends RecyclerView.ViewHolder {

        TextView tvName, tvStatus, tvDate;

        public MyViewHolder(View view) {
            super(view);
            tvStatus = view.findViewById(R.id.tvStatus);
            tvDate = view.findViewById(R.id.tvDate);
            tvName = view.findViewById(R.id.tvName);


        }
    }

    public AllOrderAdapter(Context context, List<PojoAllOrder.Datum> mArrayAllOrder) {
        this.mArrayAllOrder = mArrayAllOrder;
        this.context = context;

    }

    @Override
    public MyViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
        View itemView = LayoutInflater.from(parent.getContext())
                .inflate(R.layout.item_all_order, parent, false);


        return new MyViewHolder(itemView);

    }

    @RequiresApi(api = Build.VERSION_CODES.JELLY_BEAN)
    @Override
    public void onBindViewHolder(final MyViewHolder holder, final int position) {

        final PojoAllOrder.Datum item = mArrayAllOrder.get(position);


        holder.tvName.setText("" + item.getProduct_name());

        holder.tvDate.setText("" + item.getBookDate());

        holder.tvStatus.setText("" + item.getStatus());

        if (item.getStatus().equals("Pending")) {
            holder.tvStatus.setBackground(context.getResources().getDrawable(R.drawable.red_rect));
        } else if (item.getStatus().equals("Completed")) {
            holder.tvStatus.setBackground(context.getResources().getDrawable(R.drawable.green_rect));
        }


    }

    @Override
    public int getItemCount() {
        return mArrayAllOrder.size();
    }


}


