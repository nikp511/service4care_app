package com.service.care.fragments.users;

import android.app.DatePickerDialog;
import android.content.Context;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.preference.PreferenceManager;
import android.text.TextUtils;
import android.view.LayoutInflater;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.DatePicker;
import android.widget.EditText;
import android.widget.ProgressBar;
import android.widget.RelativeLayout;
import android.widget.Spinner;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.appcompat.widget.Toolbar;
import androidx.fragment.app.Fragment;

import com.service.care.R;
import com.service.care.activity.LoginActivity;
import com.service.care.adapter.HomeCategoryAdapter;
import com.service.care.application.MyApplication;
import com.service.care.constants.ConstantCodes;
import com.service.care.pojo.PojoCategory;
import com.service.care.pojo.PojoCommon;
import com.service.care.utils.Utils;

import java.util.ArrayList;
import java.util.Calendar;
import java.util.List;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

/**
 * Created by Rp on 8/30/2016.
 */
public class UserAddComplainFragment extends Fragment {

    private View mParentView;

    private Context mContext;
    RelativeLayout mRelativeMain;
    ProgressBar mProgressBar;

    MyApplication mApplication;
    private SharedPreferences mSharedPreference;

    Spinner spcategory;
    EditText etDate, etName, etDescrition;

    ArrayAdapter<String> arrayAdapter;
    List<PojoCategory.Datum> mArrayCategory = new ArrayList<>();

    TextView tvSubmit;

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        mParentView = inflater.inflate(R.layout.fragment_complain, container, false);
        mApplication = (MyApplication) getActivity().getApplicationContext();
        mContext = getActivity();
        setHasOptionsMenu(true);
        mSharedPreference = PreferenceManager.getDefaultSharedPreferences(getActivity());

        initialise();
        listners();

        networkCallCategory();

        return mParentView;

    }


    void initialise() {

        Toolbar mToolbar = (Toolbar) getActivity().findViewById(R.id.toolbar);
        mToolbar.setTitle("Complain");
        mToolbar.setVisibility(View.VISIBLE);

        mRelativeMain = mParentView.findViewById(R.id.relative_main);
        mProgressBar = mParentView.findViewById(R.id.progressbar);

        spcategory = mParentView.findViewById(R.id.spcategory);

        etDate = mParentView.findViewById(R.id.etDate);
        etName = mParentView.findViewById(R.id.etName);
        etDescrition = mParentView.findViewById(R.id.etDescrition);

        tvSubmit = mParentView.findViewById(R.id.tvSubmit);

    }


    void listners() {

        tvSubmit.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (validation()) {
                    networkCallAddComplain();
                }
            }
        });

        etDate.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                Utils.hideKeyboard(getActivity());

                int mYear, mMonth, mDay, mHour, mMinute;
                final Calendar c = Calendar.getInstance();
                mYear = c.get(Calendar.YEAR);
                mMonth = c.get(Calendar.MONTH);
                mDay = c.get(Calendar.DAY_OF_MONTH);

                DatePickerDialog datePickerDialog = new DatePickerDialog(mContext,
                        new DatePickerDialog.OnDateSetListener() {

                            @Override
                            public void onDateSet(DatePicker view, int year,
                                                  int monthOfYear, int dayOfMonth) {


                                etDate.setText(year + "-" + (monthOfYear + 1) + "-" + dayOfMonth);

                            }
                        }, mYear, mMonth, mDay);

                datePickerDialog.show();


            }
        });



    }

    private void networkCallCategory() {
        if (mApplication.isInternetConnected()) {

            mProgressBar.setVisibility(View.VISIBLE);

            mApplication.getRetroFitInterface().Category().enqueue(mCallbackCategory);


        } else {
            Utils.showSnackBar(getActivity(), getResources().getString(R.string
                    .message_connection));
            mProgressBar.setVisibility(View.GONE);
        }
    }

    /**
     * Callback for ws.wolfsoft.propertyplanetapp.network call
     */
    private Callback<PojoCategory> mCallbackCategory = new Callback<PojoCategory>() {
        @Override
        public void onResponse(Call<PojoCategory> call, Response<PojoCategory> response) {
            if (response != null && response.isSuccessful() && response.body() != null) {

                PojoCategory pojoParticipants = response.body();

                mArrayCategory.clear();

                if (pojoParticipants.getStatus() == 1) {

                    if (pojoParticipants.getData() != null) {
                        if (pojoParticipants.getData().size() > 0) {
                            mArrayCategory.addAll(pojoParticipants.getData());

                            String[] category = new String[mArrayCategory.size() + 1];
                            category[0] = "Select Category";
                            for (int i = 0; i < mArrayCategory.size(); i++) {
                                category[i + 1] = "" + mArrayCategory.get(i).getName();
                            }
                            arrayAdapter = new ArrayAdapter<String>(mContext, R.layout.spinner_item, R.id.spinner_text, category);
                            spcategory.setAdapter(arrayAdapter);

                        }
                    }

                } else {
                    if (!TextUtils.isEmpty(pojoParticipants.getMessage())) {
                        Utils.showSnackBar(getActivity(), pojoParticipants.getMessage());

                    } else {
                        Utils.showSnackBar(getActivity(), getString(R.string
                                .message_something_wrong));
                    }

                }
            } else {
                Utils.showSnackBar(getActivity(), getString(R.string.message_something_wrong));
                mProgressBar.setVisibility(View.GONE);
            }
            mProgressBar.setVisibility(View.GONE);

        }

        @Override
        public void onFailure(Call<PojoCategory> call, Throwable t) {
            try {
                Utils.showSnackBar(getActivity(), getString(R.string
                        .message_something_wrong));
                mProgressBar.setVisibility(View.GONE);
            } catch (Exception e) {

            }
        }
    };


    private void networkCallAddComplain() {
        if (mApplication.isInternetConnected()) {

            mProgressBar.setVisibility(View.VISIBLE);

            mApplication.getRetroFitInterface().UserAddComplaints(mSharedPreference.getString(ConstantCodes.LOGIN_USER_ID, ""),
                    etName.getText().toString(), etDate.getText().toString(), mArrayCategory.get(spcategory.getSelectedItemPosition() - 1).getId() + "",
                    etDescrition.getText().toString()).enqueue(mCallbackAddComplain);


        } else {
            Utils.showSnackBar(getActivity(), getResources().getString(R.string
                    .message_connection));
            mProgressBar.setVisibility(View.GONE);
        }
    }

    /**
     * Callback for ws.wolfsoft.propertyplanetapp.network call
     */
    private Callback<PojoCommon> mCallbackAddComplain = new Callback<PojoCommon>() {
        @Override
        public void onResponse(Call<PojoCommon> call, Response<PojoCommon> response) {

            try {
                if (response != null && response.isSuccessful() && response.body() != null) {

                    PojoCommon pojoParticipants = response.body();

                    if (pojoParticipants.getStatus() == 1) {

                        Utils.showSnackBar(getActivity(), "" + pojoParticipants.getMessage());

                        etName.setText("");
                        etDate.setText("");
                        etDescrition.setText("");
                        spcategory.setSelection(0);

                    } else {
                        if (!TextUtils.isEmpty(pojoParticipants.getMessage())) {
                            Utils.showSnackBar(getActivity(), pojoParticipants.getMessage());

                        } else {
                            Utils.showSnackBar(getActivity(), getString(R.string
                                    .message_something_wrong));
                        }

                    }
                } else {
                    Utils.showSnackBar(getActivity(), getString(R.string.message_something_wrong));
                    mProgressBar.setVisibility(View.GONE);
                }
                mProgressBar.setVisibility(View.GONE);
            } catch (Exception e) {

            }


        }

        @Override
        public void onFailure(Call<PojoCommon> call, Throwable t) {
            try {
                Utils.showSnackBar(getActivity(), getString(R.string
                        .message_something_wrong));
                mProgressBar.setVisibility(View.GONE);
            } catch (Exception e) {

            }
        }
    };

    boolean validation() {

        boolean name = validateName();
        boolean date = false;
        boolean desc = false;
        boolean cat = false;

        if (name) {
            date = validateDate();
            if (date) {
                cat = validateCategory();
                if (cat) {
                    desc = validateDescription();
                }
            }
        }

        return name && date && cat && desc;
    }

    boolean validateName() {
        if (TextUtils.isEmpty(etName.getText().toString())) {
            Utils.showSnackBar(getActivity(), "Enter Name");
            return false;
        } else {
            return true;
        }
    }

    boolean validateDate() {
        if (TextUtils.isEmpty(etDate.getText().toString())) {
            Utils.showSnackBar(getActivity(), "Select Date");
            return false;
        } else {
            return true;
        }
    }

    boolean validateDescription() {
        if (TextUtils.isEmpty(etDescrition.getText().toString())) {
            Utils.showSnackBar(getActivity(), "Enter Description");
            return false;
        } else {
            return true;
        }
    }

    boolean validateCategory() {
        if (spcategory.getSelectedItemPosition() == 0) {
            Utils.showSnackBar(getActivity(), "Select Category");
            return false;
        } else {
            return true;
        }
    }

}
