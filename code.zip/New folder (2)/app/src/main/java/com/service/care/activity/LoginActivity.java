package com.service.care.activity;

import android.content.Intent;
import android.content.IntentFilter;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.os.Handler;
import android.preference.PreferenceManager;
import android.text.Editable;
import android.text.TextUtils;
import android.text.TextWatcher;
import android.util.Log;
import android.view.View;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.ProgressBar;
import android.widget.RelativeLayout;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import com.google.android.gms.auth.api.phone.SmsRetriever;
import com.google.android.gms.auth.api.phone.SmsRetrieverClient;
import com.google.android.gms.tasks.OnFailureListener;
import com.google.android.gms.tasks.OnSuccessListener;
import com.google.android.gms.tasks.Task;
import com.service.care.R;
import com.service.care.application.MyApplication;
import com.service.care.constants.ConstantCodes;
import com.service.care.helpers.AppSignatureHashHelper;
import com.service.care.helpers.SMSReceiver;
import com.service.care.pojo.PojoLogin;
import com.service.care.pojo.PojoLoginOTP;
import com.service.care.utils.Utils;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

public class LoginActivity extends AppCompatActivity implements
        SMSReceiver.OTPReceiveListener {

    RelativeLayout mRelativeMain;
    private ProgressBar mProgressBar;
    private SharedPreferences mSharedPreferences;

    MyApplication mApplication;

    TextView tvSubmit, tvSubmit2;
    EditText etOtp1, etOtp2, etOtp3, etOtp4, etMobile;
    LinearLayout llPage1, llPage2;

    String mobileApiOtp = "";

    private SMSReceiver smsReceiver;

    Runnable mRunnable;
    Handler mHandler = new Handler();

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login);
        mApplication = (MyApplication) this.getApplicationContext();
        mSharedPreferences = PreferenceManager.getDefaultSharedPreferences(this);

        initailize();
        listners();

        AppSignatureHashHelper appSignatureHashHelper = new AppSignatureHashHelper(this);
        Log.e("HashKey for sms: ", "" + appSignatureHashHelper.getAppSignatures().get(0));

    }

    void initailize() {

        mProgressBar = findViewById(R.id.progressbar);
        mRelativeMain = findViewById(R.id.relative_main);

        llPage1 = findViewById(R.id.llPage1);
        llPage2 = findViewById(R.id.llPage2);

        etOtp1 = findViewById(R.id.etOtp1);
        etOtp2 = findViewById(R.id.etOtp2);
        etOtp3 = findViewById(R.id.etOtp3);
        etOtp4 = findViewById(R.id.etOtp4);

        etMobile = findViewById(R.id.etMobile);

        tvSubmit = findViewById(R.id.tvSubmit);
        tvSubmit2 = findViewById(R.id.tvSubmit2);
    }

    void listners() {

        etOtp1.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence s, int start, int count, int after) {

            }

            @Override
            public void onTextChanged(CharSequence s, int start, int before, int count) {

            }

            @Override
            public void afterTextChanged(Editable s) {
                etOtp2.requestFocus();
            }
        });


        etOtp2.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence s, int start, int count, int after) {

            }

            @Override
            public void onTextChanged(CharSequence s, int start, int before, int count) {

            }

            @Override
            public void afterTextChanged(Editable s) {
                etOtp3.requestFocus();
            }
        });


        etOtp3.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence s, int start, int count, int after) {

            }

            @Override
            public void onTextChanged(CharSequence s, int start, int before, int count) {

            }

            @Override
            public void afterTextChanged(Editable s) {
                etOtp4.requestFocus();
            }
        });

        etOtp4.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence s, int start, int count, int after) {

            }

            @Override
            public void onTextChanged(CharSequence s, int start, int before, int count) {

            }

            @Override
            public void afterTextChanged(Editable s) {
                Utils.hideKeyboard(LoginActivity.this);
            }
        });


        tvSubmit.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (validateMobile()) {
                    mobileApiOtp = "";
                    startSMSListener();
                    networkCallAddUserMobileOTP(etMobile.getText().toString() + "");
                }
            }
        });

        tvSubmit2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                Utils.hideKeyboard(LoginActivity.this);
                if (validateOtp()) {
                    String opt = etOtp1.getText().toString().trim() + etOtp2.getText().toString().trim() +
                            etOtp3.getText().toString().trim() + etOtp4.getText().toString().trim();

                    if (opt.equals(mobileApiOtp)) {

                        networkCallVerifyOtp(opt, etMobile.getText().toString() + "");
                    } else {
                        Utils.showSnackBar(LoginActivity.this, "Enter Valid OTP");
                    }
                }
            }
        });

    }

    private void networkCallAddUserMobileOTP(String mobile) {
        if (mApplication.isInternetConnected()) {

            mProgressBar.setVisibility(View.VISIBLE);

            mApplication.getRetroFitInterface().getLoginOTP(mobile).enqueue(mCallbackAddUserMobileOTP);


        } else {
            Utils.showSnackBar(LoginActivity.this, getResources().getString(R.string
                    .message_connection));
            mProgressBar.setVisibility(View.GONE);
        }
    }

    /**
     * Callback for ws.wolfsoft.propertyplanetapp.network call
     */
    private Callback<PojoLoginOTP> mCallbackAddUserMobileOTP = new Callback<PojoLoginOTP>() {
        @Override
        public void onResponse(Call<PojoLoginOTP> call, Response<PojoLoginOTP> response) {
            if (response != null && response.isSuccessful() && response.body() != null) {


                PojoLoginOTP pojoParticipants = response.body();
                if (pojoParticipants.getStatus() == 1) {

                    llPage1.setVisibility(View.GONE);
                    llPage2.setVisibility(View.VISIBLE);

                    mobileApiOtp = pojoParticipants.getOtp() + "";
                    mSharedPreferences.edit().putString(ConstantCodes.LOGIN_USERTYPE, pojoParticipants.getType() + "").apply();
/*

                    // code for testing
                    if (mobileApiOtp != null) {
                        if (!mobileApiOtp.equals("")) {
                            if (mobileApiOtp.length() == 4) {
                                etOtp1.setText("" + mobileApiOtp.substring(0, 1));
                                etOtp2.setText("" + mobileApiOtp.substring(1, 2));
                                etOtp3.setText("" + mobileApiOtp.substring(2, 3));
                                etOtp4.setText("" + mobileApiOtp.substring(3));
                            }
                        }
                    }
*/

                } else {
                    if (!TextUtils.isEmpty(pojoParticipants.getMessage())) {
                        Utils.showSnackBar(LoginActivity.this, pojoParticipants.getMessage());

                    } else {
                        Utils.showSnackBar(LoginActivity.this, getString(R.string
                                .message_something_wrong));
                    }

                }
            } else {
                Utils.showSnackBar(LoginActivity.this, getString(R.string.message_something_wrong));
                mProgressBar.setVisibility(View.GONE);
            }
            mProgressBar.setVisibility(View.GONE);

        }

        @Override
        public void onFailure(Call<PojoLoginOTP> call, Throwable t) {
            try {
                Utils.showSnackBar(LoginActivity.this, getString(R.string
                        .message_something_wrong));
                mProgressBar.setVisibility(View.GONE);
            } catch (Exception e) {

            }
        }
    };


    boolean validateMobile() {
        if (TextUtils.isEmpty(etMobile.getText().toString())) {
            Utils.showSnackBar(LoginActivity.this, "Enter Registered Number");
            return false;
        } else {
            return true;
        }
    }


    boolean validateOtp() {
        if (TextUtils.isEmpty(etOtp1.getText().toString().trim())) {

            Utils.showSnackBar(LoginActivity.this, "Enter OTP");
            return false;
        } else if (TextUtils.isEmpty(etOtp2.getText().toString().trim())) {


            Utils.showSnackBar(LoginActivity.this, "Enter OTP");
            return false;


        } else if (TextUtils.isEmpty(etOtp3.getText().toString().trim())) {
            Utils.showSnackBar(LoginActivity.this, "Enter OTP");
            return false;

        } else if (TextUtils.isEmpty(etOtp4.getText().toString().trim())) {
            Utils.showSnackBar(LoginActivity.this, "Enter OTP");
            return false;

        } else {
            return true;
        }
    }

    private void startSMSListener() {
        try {
            smsReceiver = new SMSReceiver();
            smsReceiver.setOTPListener(this);

            IntentFilter intentFilter = new IntentFilter();
            intentFilter.addAction(SmsRetriever.SMS_RETRIEVED_ACTION);
            this.registerReceiver(smsReceiver, intentFilter);

            SmsRetrieverClient client = SmsRetriever.getClient(this);

            Task<Void> task = client.startSmsRetriever();
            task.addOnSuccessListener(new OnSuccessListener<Void>() {
                @Override
                public void onSuccess(Void aVoid) {
                    // API successfully started
                }
            });

            task.addOnFailureListener(new OnFailureListener() {
                @Override
                public void onFailure(@NonNull Exception e) {
                    // Fail to start API
                }
            });
        } catch (Exception e) {
            e.printStackTrace();
        }
    }


    @Override
    public void onOTPReceived(String otp) {

        Log.e("otp received", otp);

        String abcd = otp.replaceAll("[^0-9]", "");
        Log.e("abcddd", "code" + abcd);

        if (abcd.length() > 4) {
            abcd = abcd.substring(0, 4);
        }

        if (abcd.length() == 4) {
            etOtp1.setText(abcd.substring(0, 1));
            etOtp2.setText(abcd.substring(1, 2));
            etOtp3.setText(abcd.substring(2, 3));
            etOtp4.setText(abcd.substring(3));

            tvSubmit2.performClick();

            mProgressBar.setVisibility(View.VISIBLE);


        } else {
            mProgressBar.setVisibility(View.GONE);

        }

        //  etOTP.setText("" + abcd);
        //tvSubmit2.performClick();


        if (smsReceiver != null) {
            unregisterReceiver(smsReceiver);
            smsReceiver = null;
        }
    }

    @Override
    public void onOTPTimeOut() {
        showToast("OTP Time out");
    }

    @Override
    public void onOTPReceivedError(String error) {
        showToast(error);
    }


    @Override
    protected void onDestroy() {
        super.onDestroy();
        if (smsReceiver != null) {
            unregisterReceiver(smsReceiver);
        }
    }


    private void showToast(String msg) {
        Toast.makeText(this, msg, Toast.LENGTH_LONG).show();
    }

    private void networkCallVerifyOtp(String otp, String mobile) {
        if (mApplication.isInternetConnected()) {
            mProgressBar.setVisibility(View.VISIBLE);

            if (mSharedPreferences.getString(ConstantCodes.LOGIN_USERTYPE, "").equals("3")) { //user
                mApplication.getRetroFitInterface().verifyUserLoginOTP(mobile, otp).enqueue(mCallbackNew);
            } else if (mSharedPreferences.getString(ConstantCodes.LOGIN_USERTYPE, "").equals("2")) { //employee
                mApplication.getRetroFitInterface().verifyEmpLoginOTP(mobile, otp).enqueue(mCallbackNew);
            } else if (mSharedPreferences.getString(ConstantCodes.LOGIN_USERTYPE, "").equals("1")) { //employee
                mApplication.getRetroFitInterface().verifyAdminLoginOTP(mobile, otp).enqueue(mCallbackNew);
            }


        } else {
            Utils.showSnackBar(LoginActivity.this, getResources().getString(R.string
                    .message_connection));
            mProgressBar.setVisibility(View.GONE);
        }
    }


    private Callback<PojoLogin> mCallbackNew = new Callback<PojoLogin>() {

        @Override
        public void onResponse(Call<PojoLogin> call, Response<PojoLogin>
                response) {

            try {
                if (response != null && response.isSuccessful() && response.body() != null) {

                    PojoLogin pojoParticipants = response.body();
                    Log.e("successsss11", "sucesssss");

                    if (pojoParticipants.getStatus() == 1) {

                        if (mSharedPreferences.getString(ConstantCodes.LOGIN_USERTYPE, "").equals("3")) { // user
                            mSharedPreferences.edit().putBoolean(ConstantCodes.IS_LOGIN, true).apply();
                            mSharedPreferences.edit().putString(ConstantCodes.LOGIN_USER_ID, pojoParticipants.getData().getId()).apply();
                            mSharedPreferences.edit().putString(ConstantCodes.LOGIN_USER_NAME, pojoParticipants.getData().getName()).apply();
                            mSharedPreferences.edit().putString(ConstantCodes.LOGIN_USER_MOBILE, pojoParticipants.getData().getMobile()).apply();
                            mSharedPreferences.edit().putString(ConstantCodes.LOGIN_USER_IMAGE, pojoParticipants.getData().getImage()).apply();
                            mSharedPreferences.edit().putString(ConstantCodes.LOGIN_USER_ADDRESS, pojoParticipants.getData().getAddress()).apply();
                            mSharedPreferences.edit().putString(ConstantCodes.LOGIN_USER_AREA, pojoParticipants.getData().getArea()).apply();
                            mSharedPreferences.edit().putString(ConstantCodes.LOGIN_USER_PINCODE, pojoParticipants.getData().getPincode()).apply();
                            mSharedPreferences.edit().putString(ConstantCodes.LOGIN_USER_OFFER_CODE, pojoParticipants.getData().getOfferCode()).apply();

                            Intent i = new Intent(LoginActivity.this, MainActivity.class);
                            startActivity(i);

                            finish();

                            mProgressBar.setVisibility(View.GONE);
                        } else if (mSharedPreferences.getString(ConstantCodes.LOGIN_USERTYPE, "").equals("2")) { //employee

                            mSharedPreferences.edit().putBoolean(ConstantCodes.IS_LOGIN, true).apply();
                            mSharedPreferences.edit().putString(ConstantCodes.LOGIN_USER_ID, pojoParticipants.getDataEmp().getId()).apply();
                            mSharedPreferences.edit().putString(ConstantCodes.LOGIN_USER_NAME, pojoParticipants.getDataEmp().getName()).apply();
                            mSharedPreferences.edit().putString(ConstantCodes.LOGIN_USER_MOBILE, pojoParticipants.getDataEmp().getMobile()).apply();
                            mSharedPreferences.edit().putString(ConstantCodes.LOGIN_USER_IMAGE, pojoParticipants.getDataEmp().getImage()).apply();
                            mSharedPreferences.edit().putString(ConstantCodes.LOGIN_USER_ADDRESS, pojoParticipants.getDataEmp().getAddress()).apply();
                            mSharedPreferences.edit().putString(ConstantCodes.LOGIN_USER_AREA, pojoParticipants.getDataEmp().getArea()).apply();
                            mSharedPreferences.edit().putString(ConstantCodes.LOGIN_USER_PINCODE, pojoParticipants.getDataEmp().getPincode()).apply();
                            mSharedPreferences.edit().putString(ConstantCodes.LOGIN_USER_EMPLOYEE_CODE, pojoParticipants.getDataEmp().getEmpNo()).apply();
                            mSharedPreferences.edit().putString(ConstantCodes.LOGIN_USER_EMPLOYEE_CITY, pojoParticipants.getDataEmp().getCity()).apply();
                            mSharedPreferences.edit().putString(ConstantCodes.LOGIN_USER_EMPLOYEE_AADHAR_CARD, pojoParticipants.getDataEmp().getGovtId()).apply();

                            Intent i = new Intent(LoginActivity.this, MainActivity.class);
                            startActivity(i);

                            finish();

                            mProgressBar.setVisibility(View.GONE);

                        } else if (mSharedPreferences.getString(ConstantCodes.LOGIN_USERTYPE, "").equals("1")) { //admin

                            mSharedPreferences.edit().putBoolean(ConstantCodes.IS_LOGIN, true).apply();
                            mSharedPreferences.edit().putString(ConstantCodes.LOGIN_USER_ID, pojoParticipants.getDataAdmin().getId()).apply();
                            mSharedPreferences.edit().putString(ConstantCodes.LOGIN_USER_NAME, pojoParticipants.getDataAdmin().getUsername()).apply();
                            mSharedPreferences.edit().putString(ConstantCodes.LOGIN_USER_MOBILE, pojoParticipants.getDataAdmin().getMobile()).apply();

                            Intent i = new Intent(LoginActivity.this, MainActivity.class);
                            startActivity(i);

                            finish();

                            mProgressBar.setVisibility(View.GONE);

                        }


                    } else {

                        mSharedPreferences.edit().putString(ConstantCodes.LOGIN_USERTYPE, "").apply();

                        mProgressBar.setVisibility(View.GONE);
                        Utils.showSnackBar(LoginActivity.this, pojoParticipants.getMessage() + "");
                    }
                } else {
                    mProgressBar.setVisibility(View.GONE);
                }
            } catch (Exception e) {

            }


        }

        @Override
        public void onFailure(Call<PojoLogin> call, Throwable t) {
            try {
                Utils.showSnackBar(LoginActivity.this, getString(R.string
                        .message_something_wrong));
                mProgressBar.setVisibility(View.GONE);
            } catch (Exception e) {

            }

        }
    };


}
