package com.service.care.fragments.admin;

import android.content.Context;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.preference.PreferenceManager;
import android.text.TextUtils;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.EditText;
import android.widget.ProgressBar;
import android.widget.RelativeLayout;
import android.widget.Spinner;
import android.widget.TextView;

import androidx.appcompat.widget.Toolbar;
import androidx.fragment.app.Fragment;

import com.service.care.R;
import com.service.care.activity.LoginActivity;
import com.service.care.application.MyApplication;
import com.service.care.constants.ConstantCodes;
import com.service.care.pojo.PojoCommon;
import com.service.care.utils.Utils;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

/**
 * Created by Rp on 8/30/2016.
 */
public class AdminAddEmployeeFragment extends Fragment {

    private View mParentView;

    private Context mContext;
    RelativeLayout mRelativeMain;
    ProgressBar mProgressBar;

    MyApplication mApplication;
    private SharedPreferences mSharedPreference;

    TextView tvSubmit;
    EditText etName, etCode, etMobile, etAddress, etPincode, etArea, etAdharCard, etCity;

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        mParentView = inflater.inflate(R.layout.fragment_add_employee, container, false);
        mApplication = (MyApplication) getActivity().getApplicationContext();
        mContext = getActivity();
        setHasOptionsMenu(true);
        mSharedPreference = PreferenceManager.getDefaultSharedPreferences(getActivity());

        initialise();
        listners();

        return mParentView;

    }


    void initialise() {

        Toolbar mToolbar = (Toolbar) getActivity().findViewById(R.id.toolbar);
        mToolbar.setTitle("Add Employee");
        mToolbar.setVisibility(View.VISIBLE);

        mRelativeMain = mParentView.findViewById(R.id.relative_main);
        mProgressBar = mParentView.findViewById(R.id.progressbar);

        etName = mParentView.findViewById(R.id.etName);
        etCode = mParentView.findViewById(R.id.etCode);
        etMobile = mParentView.findViewById(R.id.etMobile);
        etAddress = mParentView.findViewById(R.id.etAddress);
        etPincode = mParentView.findViewById(R.id.etPincode);
        etArea = mParentView.findViewById(R.id.etArea);
        etAdharCard = mParentView.findViewById(R.id.etAdharCard);
        etCity = mParentView.findViewById(R.id.etCity);

        tvSubmit = mParentView.findViewById(R.id.tvSubmit);

    }


    void listners() {

        tvSubmit.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                Utils.hideKeyboard(getActivity());
                if (validation()) {
                    networkCallAddEmployee();
                }
            }
        });

    }


    private void networkCallAddEmployee() {

        try {
            if (mApplication.isInternetConnected()) {

                mProgressBar.setVisibility(View.VISIBLE);

                mApplication.getRetroFitInterface().AddEmployee(etName.getText().toString() + "",
                        etCode.getText().toString() + "",
                        etMobile.getText().toString() + "",
                        etAdharCard.getText().toString() + "",
                        etArea.getText().toString() + "",
                        etPincode.getText().toString() + "",
                        etCity.getText().toString() + "",
                        etAddress.getText().toString() + "").enqueue(mCallbackAddEmployee);

            } else {
                Utils.showSnackBar(getActivity(), getResources().getString(R.string
                        .message_connection));
                mProgressBar.setVisibility(View.GONE);
            }
        }catch (Exception e){

        }


    }

    /**
     * Callback for ws.wolfsoft.propertyplanetapp.network call
     */
    private Callback<PojoCommon> mCallbackAddEmployee = new Callback<PojoCommon>() {
        @Override
        public void onResponse(Call<PojoCommon> call, Response<PojoCommon> response) {

            try {
                if (response != null && response.isSuccessful() && response.body() != null) {

                    PojoCommon pojoParticipants = response.body();

                    if (pojoParticipants.getStatus() == 1) {

                        Utils.showSnackBar(getActivity(), "" + pojoParticipants.getMessage());

                        etName.setText("");
                        etCode.setText("");
                        etMobile.setText("");
                        etAddress.setText("");
                        etPincode.setText("");
                        etArea.setText("");
                        etAdharCard.setText("");
                        etCity.setText("");


                    } else {
                        if (!TextUtils.isEmpty(pojoParticipants.getMessage())) {
                            Utils.showSnackBar(getActivity(), pojoParticipants.getMessage());

                        } else {
                            Utils.showSnackBar(getActivity(), getString(R.string
                                    .message_something_wrong));
                        }
                    }
                } else {
                    Utils.showSnackBar(getActivity(), getString(R.string.message_something_wrong));
                    mProgressBar.setVisibility(View.GONE);
                }
                mProgressBar.setVisibility(View.GONE);
            }catch (Exception e){

            }


        }

        @Override
        public void onFailure(Call<PojoCommon> call, Throwable t) {
            try {
                Utils.showSnackBar(getActivity(), getString(R.string
                        .message_something_wrong));
                mProgressBar.setVisibility(View.GONE);
            } catch (Exception e) {

            }
        }
    };


    boolean validation() {

        boolean name = validateName();
        boolean code = false;
        boolean mobile = false;
        boolean address = false;
        boolean pincode = false;
        boolean area = false;
        boolean adhar = false;
        boolean city = false;

        if (name) {
            code = validateCode();
            if (code) {
                mobile = validateMobile();
                if (mobile) {
                    address = validateAddress();
                    if (address) {
                        pincode = validatePincode();
                        if (pincode) {
                            area = validateArea();
                            if (area) {
                                adhar = validateAdharCard();
                                if (adhar) {
                                    city = validateCity();
                                }
                            }
                        }
                    }
                }
            }
        }

        return name &&
                code &&
                mobile &&
                address &&
                pincode &&
                area &&
                adhar &&
                city;


    }

    boolean validateName() {

        if (TextUtils.isEmpty(etName.getText().toString())) {
            Utils.showSnackBar(getActivity(), "Enter Employee Name");
            return false;
        } else {
            return true;
        }

    }

    boolean validateCode() {
        if (TextUtils.isEmpty(etCode.getText().toString())) {
            Utils.showSnackBar(getActivity(), "Enter Employee Code");
            return false;
        } else {
            return true;
        }
    }

    boolean validateMobile() {
        if (TextUtils.isEmpty(etMobile.getText().toString())) {
            Utils.showSnackBar(getActivity(), "Enter Employee Mobile");
            return false;
        } else {
            return true;
        }
    }

    boolean validateAddress() {
        if (TextUtils.isEmpty(etAddress.getText().toString())) {
            Utils.showSnackBar(getActivity(), "Enter Employee Address");
            return false;
        } else {
            return true;
        }
    }

    boolean validatePincode() {
        if (TextUtils.isEmpty(etPincode.getText().toString())) {
            Utils.showSnackBar(getActivity(), "Enter Employee Pincode");
            return false;
        } else {
            return true;
        }
    }

    boolean validateArea() {
        if (TextUtils.isEmpty(etArea.getText().toString())) {
            Utils.showSnackBar(getActivity(), "Enter Employee Area");
            return false;
        } else {
            return true;
        }
    }

    boolean validateAdharCard() {
        if (TextUtils.isEmpty(etAdharCard.getText().toString())) {
            Utils.showSnackBar(getActivity(), "Enter Employee Aadhar Card");
            return false;
        } else {
            return true;
        }
    }

    boolean validateCity() {
        if (TextUtils.isEmpty(etCity.getText().toString())) {
            Utils.showSnackBar(getActivity(), "Enter Employee City");
            return false;
        } else {
            return true;
        }
    }

}
