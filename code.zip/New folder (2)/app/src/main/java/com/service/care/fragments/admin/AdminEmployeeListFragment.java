package com.service.care.fragments.admin;

import android.content.Context;
import android.content.DialogInterface;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.preference.PreferenceManager;
import android.text.TextUtils;
import android.view.Gravity;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AutoCompleteTextView;
import android.widget.LinearLayout;
import android.widget.ProgressBar;
import android.widget.RelativeLayout;
import android.widget.TableLayout;
import android.widget.TableRow;
import android.widget.TextView;

import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.widget.SearchView;
import androidx.appcompat.widget.Toolbar;
import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentTransaction;

import com.service.care.R;
import com.service.care.adapter.NewsOfferAdapter;
import com.service.care.application.MyApplication;
import com.service.care.fragments.SubCategoryFragment;
import com.service.care.pojo.PojoCommon;
import com.service.care.pojo.PojoEmployeeList;
import com.service.care.pojo.PojoNewsOffer;
import com.service.care.utils.Utils;

import java.util.ArrayList;
import java.util.List;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

/**
 * Created by Rp on 8/30/2016.
 */
public class AdminEmployeeListFragment extends Fragment {

    private View mParentView;

    private Context mContext;
    RelativeLayout mRelativeMain;
    ProgressBar mProgressBar;

    MyApplication mApplication;
    private SharedPreferences mSharedPreference;

    List<PojoEmployeeList.Datum> mArrayEmployee = new ArrayList<>();

    TableLayout tblEmp;

    SearchView search_bar;

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        mParentView = inflater.inflate(R.layout.fragment_admin_employee_list, container, false);
        mApplication = (MyApplication) getActivity().getApplicationContext();
        mContext = getActivity();
        setHasOptionsMenu(true);
        mSharedPreference = PreferenceManager.getDefaultSharedPreferences(getActivity());

        initialise();

        networkCallEmployee("");

        return mParentView;

    }


    void initialise() {

        Toolbar mToolbar = (Toolbar) getActivity().findViewById(R.id.toolbar);
        mToolbar.setTitle("Employee List");
        mToolbar.setVisibility(View.VISIBLE);

        mRelativeMain = mParentView.findViewById(R.id.relative_main);
        mProgressBar = mParentView.findViewById(R.id.progressbar);

        search_bar = mParentView.findViewById(R.id.search_bar);

        LinearLayout linearLayout1 = (LinearLayout) search_bar.getChildAt(0);
        LinearLayout linearLayout2 = (LinearLayout) linearLayout1.getChildAt(2);
        LinearLayout linearLayout3 = (LinearLayout) linearLayout2.getChildAt(1);
        AutoCompleteTextView autoComplete = (AutoCompleteTextView) linearLayout3.getChildAt(0);
        autoComplete.setTextSize(14);

        search_bar.setOnQueryTextListener(new SearchView.OnQueryTextListener() {
            @Override
            public boolean onQueryTextSubmit(String query) {

                networkCallEmployee(query);

                return true;
            }

            @Override
            public boolean onQueryTextChange(String newText) {

                networkCallEmployee(newText);
                return true;
            }
        });

        tblEmp = (TableLayout) mParentView.findViewById(R.id.prices);
        tblEmp.setStretchAllColumns(true);
        tblEmp.bringToFront();


    }


    private void networkCallEmployee(String searchTerm) {
        if (mApplication.isInternetConnected()) {

            mProgressBar.setVisibility(View.VISIBLE);

            mApplication.getRetroFitInterface().EmployeeList(searchTerm).enqueue(mCallbackComplain);


        } else {
            Utils.showSnackBar(getActivity(), getResources().getString(R.string
                    .message_connection));
            mProgressBar.setVisibility(View.GONE);
        }
    }


    /**
     * Callback for ws.wolfsoft.propertyplanetapp.network call
     */
    private Callback<PojoEmployeeList> mCallbackComplain = new Callback<PojoEmployeeList>() {
        @Override
        public void onResponse(Call<PojoEmployeeList> call, Response<PojoEmployeeList> response) {
            if (response != null && response.isSuccessful() && response.body() != null) {

                PojoEmployeeList pojoParticipants = response.body();

                mArrayEmployee.clear();

                if (pojoParticipants.getStatus() == 1) {

                    if (pojoParticipants.getData() != null) {
                        if (pojoParticipants.getData().size() > 0) {
                            mArrayEmployee.addAll(pojoParticipants.getData());
                            getTableData();
                        } else {
                            try {
                                tblEmp.removeAllViews();

                            } catch (Exception e) {

                            }
                        }
                    } else {
                        try {
                            tblEmp.removeAllViews();

                        } catch (Exception e) {

                        }
                    }

                } else {
                    try {
                        tblEmp.removeAllViews();

                    } catch (Exception e) {

                    }
                    if (!TextUtils.isEmpty(pojoParticipants.getMessage())) {
                        Utils.showSnackBar(getActivity(), pojoParticipants.getMessage());

                    } else {
                        Utils.showSnackBar(getActivity(), getString(R.string
                                .message_something_wrong));
                    }

                }
            } else {
                Utils.showSnackBar(getActivity(), getString(R.string.message_something_wrong));
                mProgressBar.setVisibility(View.GONE);
            }
            mProgressBar.setVisibility(View.GONE);

        }

        @Override
        public void onFailure(Call<PojoEmployeeList> call, Throwable t) {
            try {
                try {
                    tblEmp.removeAllViews();

                } catch (Exception e) {

                }
                Utils.showSnackBar(getActivity(), getString(R.string
                        .message_something_wrong));
                mProgressBar.setVisibility(View.GONE);
            } catch (Exception e) {

            }
        }
    };

    void getTableData() {

        tblEmp.removeAllViews();

        for (int i = 0; i < mArrayEmployee.size() + 1; i++) {
            TableRow tr = new TableRow(mContext);

            if (i == 0) {

                TextView c1 = new TextView(mContext);
                c1.setText("Emp. Code");
                c1.setBackground(mContext.getResources().getDrawable(R.drawable.simple_gray_rect));
                c1.setTextColor(mContext.getResources().getColor(R.color.app_white));
                c1.setGravity(Gravity.CENTER);
                TextView c2 = new TextView(mContext);
                c2.setText("Emp. Name");
                c2.setBackground(mContext.getResources().getDrawable(R.drawable.simple_gray_rect));
                c2.setTextColor(mContext.getResources().getColor(R.color.app_white));
                c2.setGravity(Gravity.CENTER);
                TextView c3 = new TextView(mContext);
                c3.setText("Mobile No.");
                c3.setBackground(mContext.getResources().getDrawable(R.drawable.simple_gray_rect));
                c3.setTextColor(mContext.getResources().getColor(R.color.app_white));
                c3.setGravity(Gravity.CENTER);
                TextView c4 = new TextView(mContext);
                c4.setText("Area");
                c4.setBackground(mContext.getResources().getDrawable(R.drawable.simple_gray_rect));
                c4.setTextColor(mContext.getResources().getColor(R.color.app_white));
                c4.setGravity(Gravity.CENTER);
                TextView c5 = new TextView(mContext);
                c5.setText("Aadhar No.");
                c5.setBackground(mContext.getResources().getDrawable(R.drawable.simple_gray_rect));
                c5.setTextColor(mContext.getResources().getColor(R.color.app_white));
                c5.setGravity(Gravity.CENTER);
                TextView c6 = new TextView(mContext);
                c6.setText("Action");
                c6.setBackground(mContext.getResources().getDrawable(R.drawable.simple_gray_rect));
                c6.setTextColor(mContext.getResources().getColor(R.color.app_white));
                c6.setGravity(Gravity.CENTER);
                TextView c7 = new TextView(mContext);
                c7.setText("Status");
                c7.setBackground(mContext.getResources().getDrawable(R.drawable.simple_gray_rect));
                c7.setTextColor(mContext.getResources().getColor(R.color.app_white));
                c7.setGravity(Gravity.CENTER);

                c1.setPadding(20, 2, 20, 2);
                c2.setPadding(20, 2, 20, 2);
                c3.setPadding(20, 2, 20, 2);
                c4.setPadding(20, 2, 20, 2);
                c5.setPadding(20, 2, 20, 2);
                c6.setPadding(20, 2, 20, 2);
                c7.setPadding(20, 2, 20, 2);


                tr.addView(c1);
                tr.addView(c2);
                tr.addView(c3);
                tr.addView(c4);
                tr.addView(c5);
                tr.addView(c6);
                tr.addView(c7);

                tblEmp.addView(tr);

            } else {

                TextView c1 = new TextView(mContext);
                c1.setText("" + mArrayEmployee.get(i - 1).getEmpNo());
                c1.setBackground(mContext.getResources().getDrawable(R.drawable.simple_border));
                TextView c2 = new TextView(mContext);
                c2.setText("" + mArrayEmployee.get(i - 1).getName());
                c2.setBackground(mContext.getResources().getDrawable(R.drawable.simple_border));
                TextView c3 = new TextView(mContext);
                c3.setText("" + mArrayEmployee.get(i - 1).getMobile());
                c3.setBackground(mContext.getResources().getDrawable(R.drawable.simple_border));
                TextView c4 = new TextView(mContext);
                c4.setText("" + mArrayEmployee.get(i - 1).getArea());
                c4.setBackground(mContext.getResources().getDrawable(R.drawable.simple_border));
                TextView c5 = new TextView(mContext);
                c5.setText("" + mArrayEmployee.get(i - 1).getGovtId());
                c5.setBackground(mContext.getResources().getDrawable(R.drawable.simple_border));
                TextView c6 = new TextView(mContext);
                c6.setText("Edit");
                c6.setTag(i);
                c6.setId(i);
                c6.setOnClickListener(tvClickEdit);
                c6.setBackground(mContext.getResources().getDrawable(R.drawable.simple_border));
                c6.setTextColor(mContext.getResources().getColor(R.color.colorPrimary));
                TextView c7 = new TextView(mContext);
                c7.setTag(i);
                c7.setId(i);
                c7.setBackground(mContext.getResources().getDrawable(R.drawable.simple_border));
                if (mArrayEmployee.get(i - 1).getStatus().equals("1")) {
                    c7.setText("Active");
                } else if (mArrayEmployee.get(i - 1).getStatus().equals("0")) {
                    c7.setText("Inactive");
                }
                c7.setOnClickListener(tvClickDelete);
                c7.setBackground(mContext.getResources().getDrawable(R.drawable.simple_border));
                c7.setTextColor(mContext.getResources().getColor(R.color.colorPrimary));

                c1.setPadding(2, 2, 2, 2);
                c2.setPadding(2, 2, 2, 2);
                c3.setPadding(2, 2, 2, 2);
                c4.setPadding(2, 2, 2, 2);
                c5.setPadding(2, 2, 2, 2);
                c6.setPadding(2, 2, 2, 2);
                c7.setPadding(2, 2, 2, 2);

                c1.setGravity(Gravity.CENTER);
                c2.setGravity(Gravity.CENTER);
                c3.setGravity(Gravity.CENTER);
                c4.setGravity(Gravity.CENTER);
                c5.setGravity(Gravity.CENTER);
                c6.setGravity(Gravity.CENTER);
                c7.setGravity(Gravity.CENTER);

                tr.addView(c1);
                tr.addView(c2);
                tr.addView(c3);
                tr.addView(c4);
                tr.addView(c5);
                tr.addView(c6);
                tr.addView(c7);

                tblEmp.addView(tr);
            }
        }

    }

    TextView.OnClickListener tvClickEdit = new View.OnClickListener() {
        @Override
        public void onClick(View v) {

            try {

                TextView tv = v.findViewById(v.getId());
                if (tv.getTag() != null) {

                    Fragment fragment1 = new AdminEditEmployeeProfileFragment();
                    FragmentTransaction ft1 = getFragmentManager().beginTransaction();

                    PojoEmployeeList.Datum datum = mArrayEmployee.get((Integer) v.getTag() - 1);

                    Bundle b = new Bundle();
                    b.putSerializable("data", datum);
                    fragment1.setArguments(b);

                    ft1.replace(R.id.frame_container, fragment1).addToBackStack("").commit();

                }

            } catch (Exception e) {

            }


        }
    };


    TextView.OnClickListener tvClickDelete = new View.OnClickListener() {
        @Override
        public void onClick(View v) {

            try {

                TextView tv = v.findViewById(v.getId());
                if (tv.getTag() != null) {
                    if (Integer.parseInt(tv.getTag().toString()) > 0) {
                        if (mArrayEmployee.get(Integer.parseInt(tv.getTag().toString()) - 1).getStatus().equals("1")) {

                            showActive(mArrayEmployee.get(Integer.parseInt(tv.getTag().toString()) - 1).getId(),
                                    "Are you sure you want to make Mr." + mArrayEmployee.get(Integer.parseInt(tv.getTag().toString()) - 1).getName() + " Inactive? ");

                        } else if (mArrayEmployee.get(Integer.parseInt(tv.getTag().toString()) - 1).getStatus().equals("0")) {

                            showActive(mArrayEmployee.get(Integer.parseInt(tv.getTag().toString()) - 1).getId(),
                                    "Are you sure you want to make Mr." + mArrayEmployee.get(Integer.parseInt(tv.getTag().toString()) - 1).getName() + " Active? ");
                        }
                    }
                }

            } catch (Exception e) {

            }


        }
    };

    void showActive(final String empId, String msg) {
        AlertDialog.Builder alertDialog2 = new AlertDialog.Builder(
                mContext, R.style.CustomDialogTheme);

        alertDialog2.setMessage(msg);

        alertDialog2.setPositiveButton("YES",
                new DialogInterface.OnClickListener() {
                    public void onClick(DialogInterface dialog, int which) {

                        networkCallLeaveActive(empId);
                    }
                });


        alertDialog2.show();
    }


    private void networkCallLeaveActive(String empId) {
        if (mApplication.isInternetConnected()) {

            mProgressBar.setVisibility(View.VISIBLE);

            mApplication.getRetroFitInterface().AdminEmployeeActive(empId).enqueue(mCallbackApprove);


        } else {
            Utils.showSnackBar(getActivity(), getResources().getString(R.string
                    .message_connection));
            mProgressBar.setVisibility(View.GONE);
        }
    }


    /**
     * Callback for ws.wolfsoft.propertyplanetapp.network call
     */
    private Callback<PojoCommon> mCallbackApprove = new Callback<PojoCommon>() {
        @Override
        public void onResponse(Call<PojoCommon> call, Response<PojoCommon> response) {

            try {

                if (response != null && response.isSuccessful() && response.body() != null) {

                    PojoCommon pojoParticipants = response.body();


                    if (pojoParticipants.getStatus() == 1) {

                        Utils.showSnackBar(getActivity(), pojoParticipants.getMessage());
                        networkCallEmployee("");


                    } else {
                        if (!TextUtils.isEmpty(pojoParticipants.getMessage())) {
                            Utils.showSnackBar(getActivity(), pojoParticipants.getMessage());

                        } else {
                            Utils.showSnackBar(getActivity(), getString(R.string
                                    .message_something_wrong));
                        }

                    }
                } else {
                    Utils.showSnackBar(getActivity(), getString(R.string.message_something_wrong));
                    mProgressBar.setVisibility(View.GONE);
                }
                mProgressBar.setVisibility(View.GONE);


            } catch (Exception e) {

            }


        }

        @Override
        public void onFailure(Call<PojoCommon> call, Throwable t) {
            try {
                Utils.showSnackBar(getActivity(), getString(R.string
                        .message_something_wrong));
                mProgressBar.setVisibility(View.GONE);
            } catch (Exception e) {

            }
        }
    };


}
