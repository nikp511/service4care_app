package com.service.care.fragments;

import android.app.DatePickerDialog;
import android.app.TimePickerDialog;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.preference.PreferenceManager;
import android.text.TextUtils;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.DatePicker;
import android.widget.EditText;
import android.widget.ProgressBar;
import android.widget.RelativeLayout;
import android.widget.TextView;
import android.widget.TimePicker;
import android.widget.Toast;

import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.widget.Toolbar;
import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentTransaction;
import androidx.recyclerview.widget.DefaultItemAnimator;
import androidx.recyclerview.widget.GridLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.service.care.R;
import com.service.care.activity.LoginActivity;
import com.service.care.activity.MainActivity;
import com.service.care.adapter.HomeCategoryAdapter;
import com.service.care.adapter.SubCategoryAdapter;
import com.service.care.adapter.SubSubCategoryAdapter;
import com.service.care.application.MyApplication;
import com.service.care.constants.ConstantCodes;
import com.service.care.pojo.PojoCategory;
import com.service.care.pojo.PojoCommon;
import com.service.care.pojo.PojoProduct;
import com.service.care.pojo.PojoSubCategory;
import com.service.care.utils.Utils;
import com.smarteist.autoimageslider.SliderView;

import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.List;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

/**
 * Created by Rp on 8/30/2016.
 */
public class SubSubCategoryFragment extends Fragment {

    private View mParentView;

    private Context mContext;
    RelativeLayout mRelativeMain;
    ProgressBar mProgressBar;

    MyApplication mApplication;
    private SharedPreferences mSharedPreference;

    SliderView imageSlider;
    RecyclerView rvCategory;
    SubSubCategoryAdapter subSubCategoryAdapter;
    List<PojoProduct.Datum> mArrayCategory = new ArrayList<>();


    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        mParentView = inflater.inflate(R.layout.fragment_sub_sub_category, container, false);
        mApplication = (MyApplication) getActivity().getApplicationContext();
        mContext = getActivity();
        setHasOptionsMenu(true);
        mSharedPreference = PreferenceManager.getDefaultSharedPreferences(getActivity());

        initialise();
        networkCallCategory();

        return mParentView;

    }


    void initialise() {

        Toolbar mToolbar = (Toolbar) getActivity().findViewById(R.id.toolbar);
        mToolbar.setTitle(getArguments().getString("name"));
        mToolbar.setVisibility(View.VISIBLE);

        mRelativeMain = mParentView.findViewById(R.id.relative_main);
        mProgressBar = mParentView.findViewById(R.id.progressbar);

        imageSlider = mParentView.findViewById(R.id.imageSlider);
        rvCategory = mParentView.findViewById(R.id.rvCategory);

        GridLayoutManager layoutManagerContact = new GridLayoutManager(mContext, 1);
        rvCategory.setLayoutManager(layoutManagerContact);
        rvCategory.setItemAnimator(new DefaultItemAnimator());


    }

    private void networkCallCategory() {
        if (mApplication.isInternetConnected()) {

            mProgressBar.setVisibility(View.VISIBLE);

            mApplication.getRetroFitInterface().Product(getArguments().getString("id")).enqueue(mCallbackCategory);


        } else {
            Utils.showSnackBar(getActivity(), getResources().getString(R.string
                    .message_connection));
            mProgressBar.setVisibility(View.GONE);
        }
    }

    /**
     * Callback for ws.wolfsoft.propertyplanetapp.network call
     */
    private Callback<PojoProduct> mCallbackCategory = new Callback<PojoProduct>() {
        @Override
        public void onResponse(Call<PojoProduct> call, Response<PojoProduct> response) {
            if (response != null && response.isSuccessful() && response.body() != null) {

                PojoProduct pojoParticipants = response.body();

                mArrayCategory.clear();

                if (pojoParticipants.getStatus() == 1) {

                    if (pojoParticipants.getData() != null) {
                        if (pojoParticipants.getData().size() > 0) {
                            mArrayCategory.addAll(pojoParticipants.getData());

                            subSubCategoryAdapter = new SubSubCategoryAdapter(mContext, mArrayCategory, categoryClick);
                            rvCategory.setAdapter(subSubCategoryAdapter);

                        } else {
                            rvCategory.setAdapter(null);
                        }
                    } else {
                        rvCategory.setAdapter(null);
                    }

                } else {
                    rvCategory.setAdapter(null);
                    if (!TextUtils.isEmpty(pojoParticipants.getMessage())) {
                        Utils.showSnackBar(getActivity(), pojoParticipants.getMessage());

                    } else {
                        Utils.showSnackBar(getActivity(), getString(R.string
                                .message_something_wrong));
                    }

                }
            } else {
                Utils.showSnackBar(getActivity(), getString(R.string.message_something_wrong));
                mProgressBar.setVisibility(View.GONE);
            }
            mProgressBar.setVisibility(View.GONE);

        }

        @Override
        public void onFailure(Call<PojoProduct> call, Throwable t) {
            try {
                Utils.showSnackBar(getActivity(), getString(R.string
                        .message_something_wrong));
                mProgressBar.setVisibility(View.GONE);
            } catch (Exception e) {

            }
        }
    };

    SubSubCategoryAdapter.CustomClick categoryClick = new SubSubCategoryAdapter.CustomClick() {
        @Override
        public void detailClick(PojoProduct.Datum datum) {
            Fragment fragment1 = new CategoryDetailFragment();
            FragmentTransaction ft1 = getFragmentManager().beginTransaction();

            Bundle b = new Bundle();
            b.putSerializable("data", datum);
            fragment1.setArguments(b);
            ft1.replace(R.id.frame_container, fragment1).addToBackStack("").commit();
        }

        @Override
        public void bookService(PojoProduct.Datum datum, String remark) {

           /* if (mSharedPreference.getString(ConstantCodes.LOGIN_USERTYPE, "").equals("3")) {

                showBookPopup(datum.getId() + "", datum.getMyAndroidQtyCalulator());
            } else {
                Utils.showSnackBar(getActivity(), "Sorry Employee/Admin cannot book service");
            }*/

            Fragment fragment1 = new CategoryDetailFragment();
            FragmentTransaction ft1 = getFragmentManager().beginTransaction();

            Bundle b = new Bundle();
            b.putSerializable("data", datum);
            b.putString("isRemark", remark);
            fragment1.setArguments(b);
            ft1.replace(R.id.frame_container, fragment1).addToBackStack("").commit();

        }

        @Override
        public void calulate(PojoProduct.Datum datum, String isMinusPlus, TextView tv) {

            if (isMinusPlus.equals("p")) {
                if (datum.getMyAndroidQtyCalulator() == null) {
                    datum.setMyAndroidQtyCalulator("1");
                }

                int newQty = Integer.parseInt(datum.getMyAndroidQtyCalulator()) + 1;
                datum.setMyAndroidQtyCalulator(newQty + "");

                //  subSubCategoryAdapter.notifyDataSetChanged();

                tv.setText("" + newQty);

            } else if (isMinusPlus.equals("m")) {

                if (datum.getMyAndroidQtyCalulator() == null) {
                    datum.setMyAndroidQtyCalulator("1");
                }

                if (Integer.parseInt(datum.getMyAndroidQtyCalulator()) > 1) {
                    int newQty = Integer.parseInt(datum.getMyAndroidQtyCalulator()) - 1;
                    datum.setMyAndroidQtyCalulator(newQty + "");

                    //  subSubCategoryAdapter.notifyDataSetChanged();

                    tv.setText("" + newQty);
                }
            }

        }
    };

    private void networkCallBookService(String date, String productId, String qty) {
        if (mApplication.isInternetConnected()) {

            mProgressBar.setVisibility(View.VISIBLE);

            mApplication.getRetroFitInterface().BookService(mSharedPreference.getString(ConstantCodes.LOGIN_USER_ID, ""),
                    productId,
                    date,
                    qty,
                    "").enqueue(mCallbackAddComplain);


        } else {
            Utils.showSnackBar(getActivity(), getResources().getString(R.string
                    .message_connection));
            mProgressBar.setVisibility(View.GONE);
        }
    }

    /**
     * Callback for ws.wolfsoft.propertyplanetapp.network call
     */
    private Callback<PojoCommon> mCallbackAddComplain = new Callback<PojoCommon>() {
        @Override
        public void onResponse(Call<PojoCommon> call, Response<PojoCommon> response) {
            if (response != null && response.isSuccessful() && response.body() != null) {

                PojoCommon pojoParticipants = response.body();

                if (pojoParticipants.getStatus() == 1) {

                    Utils.showSnackBar(getActivity(), "" + pojoParticipants.getMessage());

                } else {
                    if (!TextUtils.isEmpty(pojoParticipants.getMessage())) {
                        Utils.showSnackBar(getActivity(), pojoParticipants.getMessage());

                    } else {
                        Utils.showSnackBar(getActivity(), getString(R.string
                                .message_something_wrong));
                    }

                }
            } else {
                Utils.showSnackBar(getActivity(), getString(R.string.message_something_wrong));
                mProgressBar.setVisibility(View.GONE);
            }
            mProgressBar.setVisibility(View.GONE);

        }

        @Override
        public void onFailure(Call<PojoCommon> call, Throwable t) {
            try {
                Utils.showSnackBar(getActivity(), getString(R.string
                        .message_something_wrong));
                mProgressBar.setVisibility(View.GONE);
            } catch (Exception e) {

            }
        }
    };

    void showBookPopup(final String productId, final String qty) {

        final AlertDialog alertDialog = new AlertDialog.Builder(mContext, R.style.CustomDialogTheme).create();

        alertDialog.setTitle("Select Date for Booking Service");
        //alertDialog.setCancelable(false);

        LayoutInflater layoutInflater;
        layoutInflater = LayoutInflater.from(mContext);

        View view = layoutInflater.inflate(R.layout.popup_date_book_service, null, false);

        final EditText etDate = view.findViewById(R.id.etBookDate);
        final EditText etBookTime = view.findViewById(R.id.etBookTime);
        etBookTime.setText("");
        etDate.setText("");

        final TextView tvBook = view.findViewById(R.id.tvBook);

        tvBook.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                if (!etDate.getText().toString().equals("")) {
                    if (!etBookTime.getText().toString().equals("")) {
                        alertDialog.dismiss();
                        networkCallBookService(etDate.getText().toString() + " " + etBookTime.getText().toString(), productId, qty);
                    } else {
                        Toast.makeText(mContext, "Please Select Time", Toast.LENGTH_SHORT).show();
                    }

                } else {
                    Toast.makeText(mContext, "Please Select Date", Toast.LENGTH_SHORT).show();
                }
            }
        });

        etDate.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                int mYear, mMonth, mDay, mHour, mMinute;
                final Calendar c = Calendar.getInstance();
                mYear = c.get(Calendar.YEAR);
                mMonth = c.get(Calendar.MONTH);
                mDay = c.get(Calendar.DAY_OF_MONTH);

                DatePickerDialog datePickerDialog = new DatePickerDialog(mContext,
                        new DatePickerDialog.OnDateSetListener() {

                            @Override
                            public void onDateSet(DatePicker view, int year,
                                                  int monthOfYear, int dayOfMonth) {


                                etDate.setText(year + "-" + (monthOfYear + 1) + "-" + dayOfMonth);

                            }
                        }, mYear, mMonth, mDay);

                datePickerDialog.show();

            }
        });

        etBookTime.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                int mHour, mMinute;

                final Calendar c = Calendar.getInstance();
                mHour = c.get(Calendar.HOUR_OF_DAY);
                mMinute = c.get(Calendar.MINUTE);

                // Launch Time Picker Dialog
                TimePickerDialog timePickerDialog = new TimePickerDialog(mContext,
                        new TimePickerDialog.OnTimeSetListener() {

                            @Override
                            public void onTimeSet(TimePicker view, int hourOfDay,
                                                  int minute) {

                                etBookTime.setText(hourOfDay + ":" + minute + ":00");
                            }
                        }, mHour, mMinute, false);
                timePickerDialog.show();

            }
        });


        alertDialog.setView(view);

        alertDialog.show();


    }

}
