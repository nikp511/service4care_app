package com.service.care.adapter;

import android.content.Context;
import android.os.Build;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;

import androidx.annotation.RequiresApi;
import androidx.recyclerview.widget.RecyclerView;

import com.bumptech.glide.Glide;
import com.bumptech.glide.load.engine.DiskCacheStrategy;
import com.bumptech.glide.request.RequestOptions;
import com.service.care.R;
import com.service.care.pojo.PojoCategory;

import java.util.ArrayList;
import java.util.List;


/**
 * Created by Rp on 6/14/2016.
 */
public class HomeCategoryAdapter extends RecyclerView.Adapter<HomeCategoryAdapter.MyViewHolder> {
    Context context;

    List<PojoCategory.Datum> mArrayCategory = new ArrayList<>();

    CustomClick customClick;

    public class MyViewHolder extends RecyclerView.ViewHolder {

        TextView tvName;
        ImageView ivImage;

        public MyViewHolder(View view) {
            super(view);
            ivImage = view.findViewById(R.id.ivImage);
            tvName = view.findViewById(R.id.tvName);


        }
    }

    public HomeCategoryAdapter(Context context, List<PojoCategory.Datum> mArrayCategory, CustomClick customClick) {
        this.mArrayCategory = mArrayCategory;
        this.context = context;
        this.customClick = customClick;

    }

    @Override
    public MyViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
        View itemView = LayoutInflater.from(parent.getContext())
                .inflate(R.layout.item_category, parent, false);


        return new MyViewHolder(itemView);

    }

    @RequiresApi(api = Build.VERSION_CODES.JELLY_BEAN)
    @Override
    public void onBindViewHolder(final MyViewHolder holder, final int position) {

        final PojoCategory.Datum item = mArrayCategory.get(position);

        if (item.getImage() != null) {
            if (!item.getImage().equals("")) {
                Glide.with(context).load(item.getImage())
                        .apply(RequestOptions.skipMemoryCacheOf(true))
                        .apply(RequestOptions.diskCacheStrategyOf(DiskCacheStrategy.NONE))
                        .into(holder.ivImage);
            }
        }

        holder.tvName.setText("" + item.getName());

        holder.itemView.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                customClick.detailClick(item.getName(), item.getId());
            }
        });

    }

    @Override
    public int getItemCount() {
        return mArrayCategory.size();
    }

    public interface CustomClick {

        void detailClick(String name, String id);

    }

}


