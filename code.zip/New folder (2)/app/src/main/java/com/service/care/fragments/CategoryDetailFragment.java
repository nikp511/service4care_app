package com.service.care.fragments;

import android.app.DatePickerDialog;
import android.app.TimePickerDialog;
import android.content.Context;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.preference.PreferenceManager;
import android.text.TextUtils;
import android.util.Log;
import android.view.Gravity;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.DatePicker;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ProgressBar;
import android.widget.RelativeLayout;
import android.widget.TableLayout;
import android.widget.TableRow;
import android.widget.TextView;
import android.widget.TimePicker;
import android.widget.Toast;

import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.widget.Toolbar;
import androidx.cardview.widget.CardView;
import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentTransaction;
import androidx.recyclerview.widget.DefaultItemAnimator;
import androidx.recyclerview.widget.GridLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.bumptech.glide.Glide;
import com.bumptech.glide.load.engine.DiskCacheStrategy;
import com.bumptech.glide.request.RequestOptions;
import com.service.care.R;
import com.service.care.adapter.HomeCategoryAdapter;
import com.service.care.application.MyApplication;
import com.service.care.constants.ConstantCodes;
import com.service.care.pojo.PojoCategory;
import com.service.care.pojo.PojoCommon;
import com.service.care.pojo.PojoProduct;
import com.service.care.utils.Utils;
import com.smarteist.autoimageslider.SliderView;

import java.util.ArrayList;
import java.util.Calendar;
import java.util.List;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

/**
 * Created by Rp on 8/30/2016.
 */
public class CategoryDetailFragment extends Fragment {

    private View mParentView;

    private Context mContext;
    RelativeLayout mRelativeMain;
    ProgressBar mProgressBar;

    MyApplication mApplication;
    private SharedPreferences mSharedPreference;

    TextView tvName, tvBook, tvQty;
    ImageView ivImage;

    CardView tvMinus, tvAdd;

    PojoProduct.Datum datum;

    TableLayout tblExtraData;

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        mParentView = inflater.inflate(R.layout.fragment_category_detail, container, false);
        mApplication = (MyApplication) getActivity().getApplicationContext();
        mContext = getActivity();
        setHasOptionsMenu(true);
        mSharedPreference = PreferenceManager.getDefaultSharedPreferences(getActivity());

        datum = (PojoProduct.Datum) getArguments().getSerializable("data");

        initialise();
        listners();

        return mParentView;

    }


    void initialise() {

        Toolbar mToolbar = (Toolbar) getActivity().findViewById(R.id.toolbar);
        mToolbar.setTitle(datum.getName());
        mToolbar.setVisibility(View.VISIBLE);

        mRelativeMain = mParentView.findViewById(R.id.relative_main);
        mProgressBar = mParentView.findViewById(R.id.progressbar);

        tvName = mParentView.findViewById(R.id.tvName);
        tvBook = mParentView.findViewById(R.id.tvBook);
        ivImage = mParentView.findViewById(R.id.ivImage);
        tblExtraData = (TableLayout) mParentView.findViewById(R.id.tblExtraData);

        tvMinus = mParentView.findViewById(R.id.cvMinus);
        tvAdd = mParentView.findViewById(R.id.cvPlus);
        tvQty = mParentView.findViewById(R.id.tvQty);

        if (datum.getImage() != null) {
            if (!datum.getImage().equals("")) {
                Glide.with(mContext).load(datum.getImage())
                        .apply(RequestOptions.skipMemoryCacheOf(true))
                        .apply(RequestOptions.diskCacheStrategyOf(DiskCacheStrategy.NONE))
                        .into(ivImage);
            }
        }

        getExtraData(datum.getExtraService());

    }

    void listners() {

        tvAdd.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                int newQty = Integer.parseInt(tvQty.getText().toString()) + 1;
                tvQty.setText("" + newQty);

            }
        });

        tvMinus.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (Integer.parseInt(tvQty.getText().toString()) > 1) {
                    int newQty = Integer.parseInt(tvQty.getText().toString()) - 1;
                    tvQty.setText("" + newQty);
                }

            }
        });

        tvBook.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                if (mSharedPreference.getString(ConstantCodes.LOGIN_USERTYPE, "").equals("3")) {

                    showBookPopup(datum.getId() + "", tvQty.getText().toString() + "");
                } else {
                    Utils.showSnackBar(getActivity(), "Sorry Employee/Admin cannot book service");
                }

            }
        });

    }

    void getExtraData(List<PojoProduct.ExtraService> extraData) {

        tblExtraData.setStretchAllColumns(true);
        tblExtraData.bringToFront();
        tblExtraData.removeAllViews();

        for (int i = 0; i < extraData.size() + 1; i++) {
            TableRow tr = new TableRow(mContext);

            if (i == 0) {

                TextView c1 = new TextView(mContext);
                TableRow.LayoutParams params = new TableRow.LayoutParams(0, TableRow.LayoutParams.WRAP_CONTENT, 3f);
                c1.setLayoutParams(params);
                c1.setText("Service");
                c1.setBackground(mContext.getResources().getDrawable(R.drawable.simple_gray_rect));
                c1.setTextColor(mContext.getResources().getColor(R.color.app_white));
                c1.setGravity(Gravity.CENTER);
                TextView c2 = new TextView(mContext);
                TableRow.LayoutParams params1 = new TableRow.LayoutParams(0, TableRow.LayoutParams.WRAP_CONTENT, 1f);
                c2.setLayoutParams(params1);
                c2.setText("Price");
                c2.setBackground(mContext.getResources().getDrawable(R.drawable.simple_gray_rect));
                c2.setTextColor(mContext.getResources().getColor(R.color.app_white));
                c2.setGravity(Gravity.CENTER);

                tr.addView(c1);
                tr.addView(c2);

                tblExtraData.addView(tr);

            } else {

                TextView c1 = new TextView(mContext);
                TableRow.LayoutParams params = new TableRow.LayoutParams(0, TableRow.LayoutParams.WRAP_CONTENT, 3f);
                c1.setLayoutParams(params);
                c1.setText(extraData.get(i - 1).getName() + "");
                c1.setGravity(Gravity.CENTER);
                c1.setBackground(mContext.getResources().getDrawable(R.drawable.simple_border_2));
                TextView c2 = new TextView(mContext);
                TableRow.LayoutParams params1 = new TableRow.LayoutParams(0, TableRow.LayoutParams.WRAP_CONTENT, 1f);
                c2.setLayoutParams(params1);
                c2.setGravity(Gravity.CENTER);
                c2.setText("\u20B9 " + extraData.get(i - 1).getPrice());
              //  c2.setBackground(mContext.getResources().getDrawable(R.drawable.simple_border));

                tr.addView(c1);
                tr.addView(c2);

                tr.setBackground(mContext.getResources().getDrawable(R.drawable.simple_border));

                tblExtraData.addView(tr);
            }
        }

    }


    void showBookPopup(final String productId, final String qty) {

        final AlertDialog alertDialog = new AlertDialog.Builder(mContext, R.style.CustomDialogTheme).create();

        alertDialog.setTitle("Select Date for Booking Service");
        //alertDialog.setCancelable(false);

        LayoutInflater layoutInflater;
        layoutInflater = LayoutInflater.from(mContext);

        View view = layoutInflater.inflate(R.layout.popup_date_book_service, null, false);

        final EditText etDate = view.findViewById(R.id.etBookDate);
        final EditText etBookTime = view.findViewById(R.id.etBookTime);
        etBookTime.setText("");
        etDate.setText("");

        final TextView tvBook = view.findViewById(R.id.tvBook);

        tvBook.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {


                if (!etDate.getText().toString().equals("")) {
                    if (!etBookTime.getText().toString().equals("")) {
                        alertDialog.dismiss();
                        networkCallBookService(etDate.getText().toString() + " " + etBookTime.getText().toString(), productId, qty);
                    } else {
                        Toast.makeText(mContext, "Please Select Time", Toast.LENGTH_SHORT).show();
                    }

                } else {
                    Toast.makeText(mContext, "Please Select Date", Toast.LENGTH_SHORT).show();
                }


            }
        });

        etDate.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                int mYear, mMonth, mDay, mHour, mMinute;
                final Calendar c = Calendar.getInstance();
                mYear = c.get(Calendar.YEAR);
                mMonth = c.get(Calendar.MONTH);
                mDay = c.get(Calendar.DAY_OF_MONTH);

                DatePickerDialog datePickerDialog = new DatePickerDialog(mContext,
                        new DatePickerDialog.OnDateSetListener() {

                            @Override
                            public void onDateSet(DatePicker view, int year,
                                                  int monthOfYear, int dayOfMonth) {


                                etDate.setText(year + "-" + (monthOfYear + 1) + "-" + dayOfMonth);

                            }
                        }, mYear, mMonth, mDay);

                datePickerDialog.show();

            }
        });

        etBookTime.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                int mHour, mMinute;

                final Calendar c = Calendar.getInstance();
                mHour = c.get(Calendar.HOUR_OF_DAY);
                mMinute = c.get(Calendar.MINUTE);

                // Launch Time Picker Dialog
                TimePickerDialog timePickerDialog = new TimePickerDialog(mContext,
                        new TimePickerDialog.OnTimeSetListener() {

                            @Override
                            public void onTimeSet(TimePicker view, int hourOfDay,
                                                  int minute) {

                                etBookTime.setText(hourOfDay + ":" + minute + ":00");
                            }
                        }, mHour, mMinute, false);
                timePickerDialog.show();

            }
        });


        alertDialog.setView(view);

        alertDialog.show();


    }

    private void networkCallBookService(String date, String productId, String qty) {
        if (mApplication.isInternetConnected()) {

            mProgressBar.setVisibility(View.VISIBLE);

            String remark = "";
            if (getArguments() != null) {
                if (getArguments().getString("isRemark") != null) {
                    if (!getArguments().getString("isRemark").equals("")) {
                        remark = getArguments().getString("isRemark");
                    }
                }
            }

            mApplication.getRetroFitInterface().BookService(mSharedPreference.getString(ConstantCodes.LOGIN_USER_ID, ""),
                    productId,
                    date,
                    qty,
                    remark).enqueue(mCallbackAddComplain);

        } else {
            Utils.showSnackBar(getActivity(), getResources().getString(R.string
                    .message_connection));
            mProgressBar.setVisibility(View.GONE);
        }
    }

    /**
     * Callback for ws.wolfsoft.propertyplanetapp.network call
     */
    private Callback<PojoCommon> mCallbackAddComplain = new Callback<PojoCommon>() {
        @Override
        public void onResponse(Call<PojoCommon> call, Response<PojoCommon> response) {
            if (response != null && response.isSuccessful() && response.body() != null) {

                PojoCommon pojoParticipants = response.body();

                if (pojoParticipants.getStatus() == 1) {

                    Utils.showSnackBar(getActivity(), "" + pojoParticipants.getMessage());

                } else {
                    if (!TextUtils.isEmpty(pojoParticipants.getMessage())) {
                        Utils.showSnackBar(getActivity(), pojoParticipants.getMessage());

                    } else {
                        Utils.showSnackBar(getActivity(), getString(R.string
                                .message_something_wrong));
                    }

                }
            } else {
                Utils.showSnackBar(getActivity(), getString(R.string.message_something_wrong));
                mProgressBar.setVisibility(View.GONE);
            }
            mProgressBar.setVisibility(View.GONE);

        }

        @Override
        public void onFailure(Call<PojoCommon> call, Throwable t) {
            try {
                Utils.showSnackBar(getActivity(), getString(R.string
                        .message_something_wrong));
                mProgressBar.setVisibility(View.GONE);
            } catch (Exception e) {

            }
        }
    };


}
