package com.service.care.fragments.employess;

import android.content.Context;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.preference.PreferenceManager;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ProgressBar;
import android.widget.RelativeLayout;
import android.widget.TextView;

import androidx.appcompat.widget.Toolbar;
import androidx.fragment.app.Fragment;
import androidx.recyclerview.widget.DefaultItemAnimator;
import androidx.recyclerview.widget.GridLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.service.care.R;
import com.service.care.adapter.AllInquiryAdapter;
import com.service.care.application.MyApplication;
import com.service.care.pojo.PojoAllInquiry;

import java.util.ArrayList;
import java.util.List;

/**
 * Created by Rp on 8/30/2016.
 */
public class EmployeeAllInquiryFragment extends Fragment {

    private View mParentView;

    private Context mContext;
    RelativeLayout mRelativeMain;
    ProgressBar mProgressBar;

    MyApplication mApplication;
    private SharedPreferences mSharedPreference;

    TextView tvAll, tvCompleted, tvPending,tvToday;

    RecyclerView rvInquiry;

    AllInquiryAdapter allInquiryAdapter;

    List<PojoAllInquiry.Datum> mArrayAllInquiry = new ArrayList<>();

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        mParentView = inflater.inflate(R.layout.fragment_employee_all_inquiry, container, false);
        mApplication = (MyApplication) getActivity().getApplicationContext();
        mContext = getActivity();
        setHasOptionsMenu(true);
        mSharedPreference = PreferenceManager.getDefaultSharedPreferences(getActivity());

        initialise();
        listners();

        tvAll.performClick();

        return mParentView;

    }


    void initialise() {

        Toolbar mToolbar = (Toolbar) getActivity().findViewById(R.id.toolbar);
        mToolbar.setTitle("My Inquiry");
        mToolbar.setVisibility(View.VISIBLE);

        mRelativeMain = mParentView.findViewById(R.id.relative_main);
        mProgressBar = mParentView.findViewById(R.id.progressbar);

        tvAll = mParentView.findViewById(R.id.tvAll);
        tvCompleted = mParentView.findViewById(R.id.tvCompleted);
        tvPending = mParentView.findViewById(R.id.tvPending);
        tvToday = mParentView.findViewById(R.id.tvToday);

        rvInquiry = mParentView.findViewById(R.id.rvInquiry);
        GridLayoutManager layoutManagerContact = new GridLayoutManager(mContext, 1);
        rvInquiry.setLayoutManager(layoutManagerContact);
        rvInquiry.setItemAnimator(new DefaultItemAnimator());

        allInquiryAdapter = new AllInquiryAdapter(mContext, mArrayAllInquiry);
        rvInquiry.setAdapter(allInquiryAdapter);

    }

    void listners() {

        tvAll.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                tvAll.setTextColor(mContext.getResources().getColor(R.color.app_white));
                tvCompleted.setTextColor(mContext.getResources().getColor(R.color.app_black));
                tvPending.setTextColor(mContext.getResources().getColor(R.color.app_black));
                tvToday.setTextColor(mContext.getResources().getColor(R.color.app_black));

                tvAll.setBackground(mContext.getResources().getDrawable(R.drawable.app_rect));
                tvCompleted.setBackground(mContext.getResources().getDrawable(R.drawable.app_border));
                tvPending.setBackground(mContext.getResources().getDrawable(R.drawable.app_border));
                tvToday.setBackground(mContext.getResources().getDrawable(R.drawable.app_border));

            }
        });

        tvCompleted.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                tvCompleted.setTextColor(mContext.getResources().getColor(R.color.app_white));
                tvAll.setTextColor(mContext.getResources().getColor(R.color.app_black));
                tvPending.setTextColor(mContext.getResources().getColor(R.color.app_black));
                tvToday.setTextColor(mContext.getResources().getColor(R.color.app_black));

                tvCompleted.setBackground(mContext.getResources().getDrawable(R.drawable.app_rect));
                tvAll.setBackground(mContext.getResources().getDrawable(R.drawable.app_border));
                tvPending.setBackground(mContext.getResources().getDrawable(R.drawable.app_border));
                tvToday.setBackground(mContext.getResources().getDrawable(R.drawable.app_border));

            }
        });

        tvPending.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                tvPending.setTextColor(mContext.getResources().getColor(R.color.app_white));
                tvCompleted.setTextColor(mContext.getResources().getColor(R.color.app_black));
                tvAll.setTextColor(mContext.getResources().getColor(R.color.app_black));
                tvToday.setTextColor(mContext.getResources().getColor(R.color.app_black));

                tvPending.setBackground(mContext.getResources().getDrawable(R.drawable.app_rect));
                tvCompleted.setBackground(mContext.getResources().getDrawable(R.drawable.app_border));
                tvAll.setBackground(mContext.getResources().getDrawable(R.drawable.app_border));
                tvToday.setBackground(mContext.getResources().getDrawable(R.drawable.app_border));

            }
        });


        tvToday.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                tvPending.setTextColor(mContext.getResources().getColor(R.color.app_black));
                tvCompleted.setTextColor(mContext.getResources().getColor(R.color.app_black));
                tvAll.setTextColor(mContext.getResources().getColor(R.color.app_black));
                tvToday.setTextColor(mContext.getResources().getColor(R.color.app_white));

                tvPending.setBackground(mContext.getResources().getDrawable(R.drawable.app_border));
                tvCompleted.setBackground(mContext.getResources().getDrawable(R.drawable.app_border));
                tvAll.setBackground(mContext.getResources().getDrawable(R.drawable.app_border));
                tvToday.setBackground(mContext.getResources().getDrawable(R.drawable.app_rect));

            }
        });

    }

}
