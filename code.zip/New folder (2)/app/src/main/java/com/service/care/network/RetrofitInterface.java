package com.service.care.network;


import com.service.care.constants.ConstantCodes;
import com.service.care.pojo.PojoAdminCollectedCash;
import com.service.care.pojo.PojoAllComplain;
import com.service.care.pojo.PojoAllInquiry;
import com.service.care.pojo.PojoAllLeaves;
import com.service.care.pojo.PojoAllOrder;
import com.service.care.pojo.PojoAllOrderAdmin;
import com.service.care.pojo.PojoCategory;
import com.service.care.pojo.PojoCommon;
import com.service.care.pojo.PojoDashboardCounters;
import com.service.care.pojo.PojoEmpAssignedInquiry;
import com.service.care.pojo.PojoEmployeeList;
import com.service.care.pojo.PojoHomeBanner;
import com.service.care.pojo.PojoLoginOTP;
import com.service.care.pojo.PojoLogin;
import com.service.care.pojo.PojoNewsOffer;
import com.service.care.pojo.PojoProduct;
import com.service.care.pojo.PojoProfile;
import com.service.care.pojo.PojoSubCategory;
import com.service.care.pojo.PojoTestimonial;

import retrofit2.Call;
import retrofit2.http.Field;
import retrofit2.http.FormUrlEncoded;
import retrofit2.http.GET;
import retrofit2.http.POST;

/**
 * Retrofit interface network calls
 */

public interface RetrofitInterface {

    @FormUrlEncoded
    @POST(ConstantCodes.METHOD_GET_LOGIN_OTP)
    Call<PojoLoginOTP> getLoginOTP(@Field("mobile") String mobile);

    @FormUrlEncoded
    @POST(ConstantCodes.METHOD_VERIFY_USER_LOGIN_OTP)
    Call<PojoLogin> verifyUserLoginOTP(@Field("mobile") String mobile, @Field("otp") String otp);

    @FormUrlEncoded
    @POST(ConstantCodes.METHOD_VERIFY_EMP_LOGIN_OTP)
    Call<PojoLogin> verifyEmpLoginOTP(@Field("mobile") String mobile, @Field("otp") String otp);

    @FormUrlEncoded
    @POST(ConstantCodes.METHOD_VERIFY_ADMIN_LOGIN_OTP)
    Call<PojoLogin> verifyAdminLoginOTP(@Field("mobile") String mobile, @Field("otp") String otp);

    @POST(ConstantCodes.METHOD_CATEGORY)
    Call<PojoCategory> Category();

    @FormUrlEncoded
    @POST(ConstantCodes.METHOD_SUB_CATEGORY)
    Call<PojoSubCategory> SubCategory(@Field("category_id") String category_id);

    @FormUrlEncoded
    @POST(ConstantCodes.METHOD_PRODUCT)
    Call<PojoProduct> Product(@Field("subCategoryId") String subCategoryId);

    @POST(ConstantCodes.METHOD_TESTIMONIAL)
    Call<PojoTestimonial> Testimonial();

    @FormUrlEncoded
    @POST(ConstantCodes.METHOD_USER_MY_COMPLAINTS)
    Call<PojoAllComplain> UserMyComplaints(@Field("userId") String userId, @Field("status") String status);

    @FormUrlEncoded
    @POST(ConstantCodes.METHOD_ADD_COMPLAINTS)
    Call<PojoCommon> UserAddComplaints(@Field("userId") String userId, @Field("name") String name,
                                       @Field("date") String date, @Field("category_id") String category_id,
                                       @Field("detail") String detail);

    @FormUrlEncoded
    @POST(ConstantCodes.METHOD_MY_INQUIRY)
    Call<PojoAllInquiry> MyInquiry(@Field("userId") String userId, @Field("status") String status);

    @FormUrlEncoded
    @POST(ConstantCodes.METHOD_MY_ORDER)
    Call<PojoAllOrder> MyOrder(@Field("userId") String userId, @Field("status") String status);

    @FormUrlEncoded
    @POST(ConstantCodes.METHOD_ADD_INQUIRY)
    Call<PojoCommon> AddInquiry(@Field("userId") String userId, @Field("userName") String userName,
                                @Field("address") String address, @Field("email") String email,
                                @Field("mobile") String mobile);

    @GET(ConstantCodes.METHOD_NEWS_OFFER)
    Call<PojoNewsOffer> NewsOffer();

    @FormUrlEncoded
    @POST(ConstantCodes.METHOD_EMPLOYEE_LIST)
    Call<PojoEmployeeList> EmployeeList(@Field("term") String term);

    @FormUrlEncoded
    @POST(ConstantCodes.METHOD_BOOK_SERVICE)
    Call<PojoCommon> BookService(@Field("userId") String userId, @Field("productId") String productId,
                                 @Field("bookDate") String bookDate, @Field("quantity") String quantity,
                                 @Field("detail") String detail);

    @FormUrlEncoded
    @POST(ConstantCodes.METHOD_ADD_EMPLOYEE)
    Call<PojoCommon> AddEmployee(@Field("name") String name, @Field("emp_no") String emp_no,
                                 @Field("mobile") String mobile, @Field("govtId") String govtId,
                                 @Field("area") String area, @Field("pincode") String pincode,
                                 @Field("city") String city, @Field("address") String address);

    @FormUrlEncoded
    @POST(ConstantCodes.METHOD_ADMIN_ALL_ORDER)
    Call<PojoAllOrderAdmin> AdminOrder(@Field("status") String status);

    @FormUrlEncoded
    @POST(ConstantCodes.METHOD_ADMIN_ASSIGN_ORDER)
    Call<PojoCommon> AdminAssignOrder(@Field("bookServiceId") String bookServiceId,
                                      @Field("employeeId") String employeeId);

    @FormUrlEncoded
    @POST(ConstantCodes.METHOD_ADMIN_COLLECTED_CASH)
    Call<PojoAdminCollectedCash> AdminCollectedCash(@Field("term") String term);

    @FormUrlEncoded
    @POST(ConstantCodes.METHOD_ADMIN_PROFILE)
    Call<PojoProfile> AdminProfile(@Field("username") String userName,
                                   @Field("mobile") String mobile,
                                   @Field("admin_id") String userId);

    @POST(ConstantCodes.METHOD_ADMIN_LEAVES)
    Call<PojoAllLeaves> AdminAllLeave();

    @FormUrlEncoded
    @POST(ConstantCodes.METHOD_ADMIN_LEAVES_APPROVE)
    Call<PojoCommon> AdminApproveLeave(@Field("leaveId") String leaveId);

    @FormUrlEncoded
    @POST(ConstantCodes.METHOD_ADMIN_EMP_INACTIVE)
    Call<PojoCommon> AdminEmployeeActive(@Field("employeeId") String employeeId);

    @FormUrlEncoded
    @POST(ConstantCodes.METHOD_EMP_ASSIGNED_INQUIRY)
    Call<PojoEmpAssignedInquiry> EmployeeAssignedInquiry(@Field("employeeId") String employeeId, @Field("flag") String flag,
                                                         @Field("status") String status, @Field("term") String term);

    @FormUrlEncoded
    @POST(ConstantCodes.METHOD_EMP_ADD_LEAVE)
    Call<PojoCommon> EmpAddLeave(@Field("employeeId") String employeeId,
                                 @Field("leaveStartDate") String leaveStartDate,
                                 @Field("leaveEndDate") String leaveEndDate,
                                 @Field("reason") String reason);

    @FormUrlEncoded
    @POST(ConstantCodes.METHOD_EMP_ADD_COMPLAIN)
    Call<PojoCommon> EmployeeAddComplain(@Field("employeeId") String employeeId, @Field("name") String name,
                                         @Field("date") String date, @Field("category_id") String category_id,
                                         @Field("detail") String detail);

    @FormUrlEncoded
    @POST(ConstantCodes.METHOD_EMP_MY_COMPLAINTS)
    Call<PojoAllComplain> EmployeeMyComplaints(@Field("employeeId") String employeeId);

    @FormUrlEncoded
    @POST(ConstantCodes.METHOD_EMP_MY_LEAVES)
    Call<PojoAllLeaves> EmployeeMyLeaves(@Field("employeeId") String employeeId);

    @FormUrlEncoded
    @POST(ConstantCodes.METHOD_EMP_COMPLETE_INQUIRY)
    Call<PojoCommon> EmpCompleteInquiry(@Field("employeeId") String employeeId,
                                        @Field("startTime") String startTime,
                                        @Field("endTime") String endTime,
                                        @Field("bookServiceId") String bookServiceId,
                                        @Field("finalAmmount") String finalAmmount);

    @FormUrlEncoded
    @POST(ConstantCodes.METHOD_EMP_DASHBOARD)
    Call<PojoDashboardCounters> GetEmpDashboardCounter(@Field("employeeId") String employeeId);

    @POST(ConstantCodes.METHOD_ADMIN_DASHBOARD)
    Call<PojoDashboardCounters> GetAdminDashboardCounter();

    @GET(ConstantCodes.METHOD_HOME_BANNER)
    Call<PojoHomeBanner> HomeBanner();

    @FormUrlEncoded
    @POST(ConstantCodes.METHOD_FEEDBACK)
    Call<PojoCommon> UserFeedback(@Field("userId") String userId,
                                  @Field("rate") String rate);

    @FormUrlEncoded
    @POST(ConstantCodes.METHOD_RATE_US)
    Call<PojoCommon> UserRateUs(@Field("name") String name,
                                @Field("mobile") String mobile,
                                @Field("star") String star);

    @FormUrlEncoded
    @POST(ConstantCodes.METHOD_EMP_INQUIRY_APPROVAL)
    Call<PojoCommon> EmpInquiryRequest(@Field("employeeId") String employeeId,
                                       @Field("bookServiceId") String bookServiceId,
                                       @Field("action") String leaveEndDate);

}