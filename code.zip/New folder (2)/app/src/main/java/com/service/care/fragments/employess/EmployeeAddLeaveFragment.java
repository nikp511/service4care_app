package com.service.care.fragments.employess;

import android.app.DatePickerDialog;
import android.content.Context;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.preference.PreferenceManager;
import android.text.TextUtils;
import android.view.LayoutInflater;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.DatePicker;
import android.widget.EditText;
import android.widget.ProgressBar;
import android.widget.RelativeLayout;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.appcompat.widget.Toolbar;
import androidx.fragment.app.Fragment;

import com.service.care.R;
import com.service.care.application.MyApplication;
import com.service.care.constants.ConstantCodes;
import com.service.care.pojo.PojoCommon;
import com.service.care.utils.Utils;

import java.util.Calendar;

import okhttp3.internal.Util;
import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

/**
 * Created by Rp on 8/30/2016.
 */
public class EmployeeAddLeaveFragment extends Fragment {

    private View mParentView;

    private Context mContext;
    RelativeLayout mRelativeMain;
    ProgressBar mProgressBar;

    MyApplication mApplication;
    private SharedPreferences mSharedPreference;

    EditText etStartDate, etEndDate, etReason;
    TextView tvSubmit;

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        mParentView = inflater.inflate(R.layout.fragment_employee_leave, container, false);
        mApplication = (MyApplication) getActivity().getApplicationContext();
        mContext = getActivity();
        setHasOptionsMenu(true);
        mSharedPreference = PreferenceManager.getDefaultSharedPreferences(getActivity());

        initialise();
        listners();

        return mParentView;

    }


    void initialise() {

        Toolbar mToolbar = (Toolbar) getActivity().findViewById(R.id.toolbar);
        mToolbar.setTitle("Create Leave");
        mToolbar.setVisibility(View.VISIBLE);

        mRelativeMain = mParentView.findViewById(R.id.relative_main);
        mProgressBar = mParentView.findViewById(R.id.progressbar);

        etReason = mParentView.findViewById(R.id.etReason);
        etStartDate = mParentView.findViewById(R.id.tvStartDate);
        etEndDate = mParentView.findViewById(R.id.tvEndDate);

        tvSubmit = mParentView.findViewById(R.id.tvSubmit);

    }

    void listners() {

        try {
            tvSubmit.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    if (!etReason.getText().toString().equals("")) {
                        if (!etStartDate.getText().toString().equals("")) {
                            if (!etEndDate.getText().toString().equals("")) {
                                networkCallAddEmployeeLeave();
                            } else {
                                Utils.showSnackBar(getActivity(), "Enter Leave Reason");
                            }
                        } else {
                            Utils.showSnackBar(getActivity(), "Select Start Date");
                        }
                    } else {
                        Utils.showSnackBar(getActivity(), "Select End Date");
                    }
                }
            });

            etStartDate.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {

                    int mYear, mMonth, mDay, mHour, mMinute;
                    final Calendar c = Calendar.getInstance();
                    mYear = c.get(Calendar.YEAR);
                    mMonth = c.get(Calendar.MONTH);
                    mDay = c.get(Calendar.DAY_OF_MONTH);

                    DatePickerDialog datePickerDialog = new DatePickerDialog(mContext,
                            new DatePickerDialog.OnDateSetListener() {

                                @Override
                                public void onDateSet(DatePicker view, int year,
                                                      int monthOfYear, int dayOfMonth) {


                                    etStartDate.setText(year + "-" + (monthOfYear + 1) + "-" + dayOfMonth);

                                }
                            }, mYear, mMonth, mDay);

                    datePickerDialog.show();

                }
            });

            etEndDate.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {

                    int mYear, mMonth, mDay, mHour, mMinute;
                    final Calendar c = Calendar.getInstance();
                    mYear = c.get(Calendar.YEAR);
                    mMonth = c.get(Calendar.MONTH);
                    mDay = c.get(Calendar.DAY_OF_MONTH);

                    DatePickerDialog datePickerDialog = new DatePickerDialog(mContext,
                            new DatePickerDialog.OnDateSetListener() {

                                @Override
                                public void onDateSet(DatePicker view, int year,
                                                      int monthOfYear, int dayOfMonth) {

                                    etEndDate.setText(year + "-" + (monthOfYear + 1) + "-" + dayOfMonth);

                                }
                            }, mYear, mMonth, mDay);

                    datePickerDialog.show();

                }
            });


        } catch (Exception e) {

        }


    }

    private void networkCallAddEmployeeLeave() {

        try {
            if (mApplication.isInternetConnected()) {

                mProgressBar.setVisibility(View.VISIBLE);

                mApplication.getRetroFitInterface().EmpAddLeave(mSharedPreference.getString(ConstantCodes.LOGIN_USER_ID, ""),
                        etStartDate.getText().toString() + "",
                        etEndDate.getText().toString() + "",
                        etReason.getText().toString() + "").enqueue(mCallbackAddEmployee);

            } else {
                Utils.showSnackBar(getActivity(), getResources().getString(R.string
                        .message_connection));
                mProgressBar.setVisibility(View.GONE);
            }
        } catch (Exception e) {

        }

    }

    /**
     * Callback for ws.wolfsoft.propertyplanetapp.network call
     */
    private Callback<PojoCommon> mCallbackAddEmployee = new Callback<PojoCommon>() {
        @Override
        public void onResponse(Call<PojoCommon> call, Response<PojoCommon> response) {

            try {
                if (response != null && response.isSuccessful() && response.body() != null) {

                    PojoCommon pojoParticipants = response.body();

                    if (pojoParticipants.getStatus() == 1) {

                        Utils.showSnackBar(getActivity(), "" + pojoParticipants.getMessage());

                        etEndDate.setText("");
                        etStartDate.setText("");
                        etReason.setText("");


                    } else {
                        if (!TextUtils.isEmpty(pojoParticipants.getMessage())) {
                            Utils.showSnackBar(getActivity(), pojoParticipants.getMessage());

                        } else {
                            Utils.showSnackBar(getActivity(), getString(R.string
                                    .message_something_wrong));
                        }
                    }
                } else {
                    Utils.showSnackBar(getActivity(), getString(R.string.message_something_wrong));
                    mProgressBar.setVisibility(View.GONE);
                }
                mProgressBar.setVisibility(View.GONE);
            } catch (Exception e) {

            }


        }

        @Override
        public void onFailure(Call<PojoCommon> call, Throwable t) {
            try {
                Utils.showSnackBar(getActivity(), getString(R.string
                        .message_something_wrong));
                mProgressBar.setVisibility(View.GONE);
            } catch (Exception e) {

            }
        }
    };


}
