package com.service.care.fragments.users;

import android.content.Context;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.preference.PreferenceManager;
import android.text.TextUtils;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ProgressBar;
import android.widget.RelativeLayout;

import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;
import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentTransaction;
import androidx.recyclerview.widget.DefaultItemAnimator;
import androidx.recyclerview.widget.GridLayoutManager;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.service.care.R;
import com.service.care.adapter.HomeCategoryAdapter;
import com.service.care.adapter.HomeTestimonialAdapter;
import com.service.care.adapter.MySliderAdapter;
import com.service.care.application.MyApplication;
import com.service.care.fragments.SubCategoryFragment;
import com.service.care.pojo.PojoCategory;
import com.service.care.pojo.PojoHomeBanner;
import com.service.care.pojo.PojoTestimonial;
import com.service.care.utils.Utils;
import com.smarteist.autoimageslider.SliderView;

import java.util.ArrayList;
import java.util.List;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

/**
 * Created by Rp on 8/30/2016.
 */
public class UserDashboardFragment extends Fragment {

    private View mParentView;

    private Context mContext;
    RelativeLayout mRelativeMain;
    ProgressBar mProgressBar;

    MyApplication mApplication;
    private SharedPreferences mSharedPreference;

    SliderView imageSlider;
    RecyclerView rvCategory, rvTestimonial;
    HomeCategoryAdapter homeCategoryAdapter;
    HomeTestimonialAdapter homeTestimonialAdapter;
    List<PojoCategory.Datum> mArrayCategory = new ArrayList<>();
    List<PojoTestimonial.Datum> mArrayTestimonial = new ArrayList<>();


    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        mParentView = inflater.inflate(R.layout.fragment_dashboard_user, container, false);
        mApplication = (MyApplication) getActivity().getApplicationContext();
        mContext = getActivity();
        setHasOptionsMenu(true);
        mSharedPreference = PreferenceManager.getDefaultSharedPreferences(getActivity());

        initialise();

        networkCallCategory();
        networkCallTestimonial();
        networkCallBanner();

        return mParentView;

    }


    void initialise() {

        Toolbar mToolbar = (Toolbar) getActivity().findViewById(R.id.toolbar);
        mToolbar.setTitle("Dashboard");
        mToolbar.setVisibility(View.VISIBLE);

        mRelativeMain = mParentView.findViewById(R.id.relative_main);
        mProgressBar = mParentView.findViewById(R.id.progressbar);

        imageSlider = mParentView.findViewById(R.id.imageSlider);
        rvCategory = mParentView.findViewById(R.id.rvCategory);
        rvTestimonial = mParentView.findViewById(R.id.rvTestimonial);

        GridLayoutManager layoutManagerContact = new GridLayoutManager(mContext, 3);
        rvCategory.setLayoutManager(layoutManagerContact);
        rvCategory.setItemAnimator(new DefaultItemAnimator());


        LinearLayoutManager layoutManagerTest = new LinearLayoutManager(mContext, RecyclerView.HORIZONTAL, false);
        rvTestimonial.setLayoutManager(layoutManagerTest);
        rvTestimonial.setItemAnimator(new DefaultItemAnimator());


    }


    private void networkCallCategory() {
        if (mApplication.isInternetConnected()) {

            mProgressBar.setVisibility(View.VISIBLE);

            mApplication.getRetroFitInterface().Category().enqueue(mCallbackCategory);


        } else {
            Utils.showSnackBar(getActivity(), getResources().getString(R.string
                    .message_connection));
            mProgressBar.setVisibility(View.GONE);
        }
    }


    /**
     * Callback for ws.wolfsoft.propertyplanetapp.network call
     */
    private Callback<PojoCategory> mCallbackCategory = new Callback<PojoCategory>() {
        @Override
        public void onResponse(Call<PojoCategory> call, Response<PojoCategory> response) {
            if (response != null && response.isSuccessful() && response.body() != null) {

                PojoCategory pojoParticipants = response.body();

                mArrayCategory.clear();

                if (pojoParticipants.getStatus() == 1) {

                    if (pojoParticipants.getData() != null) {
                        if (pojoParticipants.getData().size() > 0) {
                            mArrayCategory.addAll(pojoParticipants.getData());

                            homeCategoryAdapter = new HomeCategoryAdapter(mContext, mArrayCategory, categoryClick);
                            rvCategory.setAdapter(homeCategoryAdapter);

                        } else {
                            rvCategory.setAdapter(null);
                        }
                    } else {
                        rvCategory.setAdapter(null);
                    }

                } else {
                    rvCategory.setAdapter(null);
                    if (!TextUtils.isEmpty(pojoParticipants.getMessage())) {
                        Utils.showSnackBar(getActivity(), pojoParticipants.getMessage());

                    } else {
                        Utils.showSnackBar(getActivity(), getString(R.string
                                .message_something_wrong));
                    }

                }
            } else {
                Utils.showSnackBar(getActivity(), getString(R.string.message_something_wrong));
                mProgressBar.setVisibility(View.GONE);
            }
            mProgressBar.setVisibility(View.GONE);

        }

        @Override
        public void onFailure(Call<PojoCategory> call, Throwable t) {
            try {
                Utils.showSnackBar(getActivity(), getString(R.string
                        .message_something_wrong));
                mProgressBar.setVisibility(View.GONE);
            } catch (Exception e) {

            }
        }
    };


    HomeCategoryAdapter.CustomClick categoryClick = new HomeCategoryAdapter.CustomClick() {
        @Override
        public void detailClick(String name, String id) {

            Fragment fragment1 = new SubCategoryFragment();
            FragmentTransaction ft1 = getFragmentManager().beginTransaction();

            Bundle b = new Bundle();
            b.putString("name", name);
            b.putString("id", id);

            fragment1.setArguments(b);
            ft1.replace(R.id.frame_container, fragment1).addToBackStack("").commit();

        }
    };


    private void networkCallTestimonial() {
        if (mApplication.isInternetConnected()) {

            mProgressBar.setVisibility(View.VISIBLE);

            mApplication.getRetroFitInterface().Testimonial().enqueue(mCallbackTestimonial);


        } else {
            Utils.showSnackBar(getActivity(), getResources().getString(R.string
                    .message_connection));
            mProgressBar.setVisibility(View.GONE);
        }
    }


    /**
     * Callback for ws.wolfsoft.propertyplanetapp.network call
     */
    private Callback<PojoTestimonial> mCallbackTestimonial = new Callback<PojoTestimonial>() {
        @Override
        public void onResponse(Call<PojoTestimonial> call, Response<PojoTestimonial> response) {
            if (response != null && response.isSuccessful() && response.body() != null) {

                PojoTestimonial pojoParticipants = response.body();

                mArrayTestimonial.clear();

                if (pojoParticipants.getStatus() == 1) {

                    if (pojoParticipants.getData() != null) {
                        if (pojoParticipants.getData().size() > 0) {
                            mArrayTestimonial.addAll(pojoParticipants.getData());

                            homeTestimonialAdapter = new HomeTestimonialAdapter(mContext, mArrayTestimonial);
                            rvTestimonial.setAdapter(homeTestimonialAdapter);

                        } else {
                            rvTestimonial.setAdapter(null);
                        }
                    } else {
                        rvTestimonial.setAdapter(null);
                    }

                } else {
                    rvTestimonial.setAdapter(null);
                    if (!TextUtils.isEmpty(pojoParticipants.getMessage())) {
                        Utils.showSnackBar(getActivity(), pojoParticipants.getMessage());

                    } else {
                        Utils.showSnackBar(getActivity(), getString(R.string
                                .message_something_wrong));
                    }

                }
            } else {
                Utils.showSnackBar(getActivity(), getString(R.string.message_something_wrong));
                mProgressBar.setVisibility(View.GONE);
            }
            mProgressBar.setVisibility(View.GONE);

        }

        @Override
        public void onFailure(Call<PojoTestimonial> call, Throwable t) {
            try {
                Utils.showSnackBar(getActivity(), getString(R.string
                        .message_something_wrong));
                mProgressBar.setVisibility(View.GONE);
            } catch (Exception e) {

            }
        }
    };


    private void networkCallBanner() {
        if (mApplication.isInternetConnected()) {

            mProgressBar.setVisibility(View.VISIBLE);

            mApplication.getRetroFitInterface().HomeBanner().enqueue(mCallbackBanner);


        } else {
            Utils.showSnackBar(getActivity(), getResources().getString(R.string
                    .message_connection));
            mProgressBar.setVisibility(View.GONE);
        }
    }


    /**
     * Callback for ws.wolfsoft.propertyplanetapp.network call
     */
    private Callback<PojoHomeBanner> mCallbackBanner = new Callback<PojoHomeBanner>() {
        @Override
        public void onResponse(Call<PojoHomeBanner> call, Response<PojoHomeBanner> response) {
            if (response != null && response.isSuccessful() && response.body() != null) {

                PojoHomeBanner pojoParticipants = response.body();


                if (pojoParticipants.getStatus() == 1) {

                    if (pojoParticipants.getData() != null) {
                        if (pojoParticipants.getData().size() > 0) {
                            MySliderAdapter sliderAdapter = new MySliderAdapter(mContext, pojoParticipants.getData());
                            imageSlider.setSliderAdapter(sliderAdapter);
                        }
                    }

                } else {
                    rvCategory.setAdapter(null);
                    if (!TextUtils.isEmpty(pojoParticipants.getMessage())) {
                        Utils.showSnackBar(getActivity(), pojoParticipants.getMessage());

                    } else {
                        Utils.showSnackBar(getActivity(), getString(R.string
                                .message_something_wrong));
                    }

                }
            } else {
                Utils.showSnackBar(getActivity(), getString(R.string.message_something_wrong));
                mProgressBar.setVisibility(View.GONE);
            }
            mProgressBar.setVisibility(View.GONE);

        }

        @Override
        public void onFailure(Call<PojoHomeBanner> call, Throwable t) {
            try {
                Utils.showSnackBar(getActivity(), getString(R.string
                        .message_something_wrong));
                mProgressBar.setVisibility(View.GONE);
            } catch (Exception e) {

            }
        }
    };


}
