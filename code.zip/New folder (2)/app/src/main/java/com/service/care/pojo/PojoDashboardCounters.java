package com.service.care.pojo;

import com.google.gson.annotations.Expose;
import com.google.gson.annotations.SerializedName;

public class PojoDashboardCounters {

    @SerializedName("data")
    @Expose
    private Data data;
    @SerializedName("dataemp")
    @Expose
    private Dataemp dataemp;
    @SerializedName("status")
    @Expose
    private Integer status;
    @SerializedName("message")
    @Expose
    private String message;

    public Dataemp getDataemp() {
        return dataemp;
    }

    public void setDataemp(Dataemp dataemp) {
        this.dataemp = dataemp;
    }

    public Data getData() {
        return data;
    }

    public void setData(Data data) {
        this.data = data;
    }

    public Integer getStatus() {
        return status;
    }

    public void setStatus(Integer status) {
        this.status = status;
    }

    public String getMessage() {
        return message;
    }

    public void setMessage(String message) {
        this.message = message;
    }


    public class Data {

        @SerializedName("TotalInquiry")
        @Expose
        private Integer totalInquiry;
        @SerializedName("TodaysInquiry")
        @Expose
        private Integer todaysInquiry;
        @SerializedName("TotalEmployees")
        @Expose
        private Integer totalEmployees;
        @SerializedName("TotalIncome")
        @Expose
        private Integer totalIncome;

        public Integer getTotalInquiry() {
            return totalInquiry;
        }

        public void setTotalInquiry(Integer totalInquiry) {
            this.totalInquiry = totalInquiry;
        }

        public Integer getTodaysInquiry() {
            return todaysInquiry;
        }

        public void setTodaysInquiry(Integer todaysInquiry) {
            this.todaysInquiry = todaysInquiry;
        }

        public Integer getTotalEmployees() {
            return totalEmployees;
        }

        public void setTotalEmployees(Integer totalEmployees) {
            this.totalEmployees = totalEmployees;
        }

        public Integer getTotalIncome() {
            return totalIncome;
        }

        public void setTotalIncome(Integer totalIncome) {
            this.totalIncome = totalIncome;
        }

    }

    public class Dataemp {

        @SerializedName("TotalInquiry")
        @Expose
        private Integer totalInquiry;
        @SerializedName("TodaysInquiry")
        @Expose
        private Integer todaysInquiry;
        @SerializedName("TotalLeaves")
        @Expose
        private Integer totalLeaves;
        @SerializedName("TotalIncome")
        @Expose
        private Integer totalIncome;

        public Integer getTotalInquiry() {
            return totalInquiry;
        }

        public void setTotalInquiry(Integer totalInquiry) {
            this.totalInquiry = totalInquiry;
        }

        public Integer getTodaysInquiry() {
            return todaysInquiry;
        }

        public void setTodaysInquiry(Integer todaysInquiry) {
            this.todaysInquiry = todaysInquiry;
        }

        public Integer getTotalLeaves() {
            return totalLeaves;
        }

        public void setTotalLeaves(Integer totalLeaves) {
            this.totalLeaves = totalLeaves;
        }

        public Integer getTotalIncome() {
            return totalIncome;
        }

        public void setTotalIncome(Integer totalIncome) {
            this.totalIncome = totalIncome;
        }

    }


}
