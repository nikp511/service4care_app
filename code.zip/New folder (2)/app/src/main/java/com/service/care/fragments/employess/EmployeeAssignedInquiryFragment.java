package com.service.care.fragments.employess;

import android.content.Context;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.preference.PreferenceManager;
import android.text.TextUtils;
import android.view.Gravity;
import android.view.LayoutInflater;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AutoCompleteTextView;
import android.widget.LinearLayout;
import android.widget.ProgressBar;
import android.widget.RelativeLayout;
import android.widget.TableLayout;
import android.widget.TableRow;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.appcompat.widget.SearchView;
import androidx.appcompat.widget.Toolbar;
import androidx.fragment.app.Fragment;

import com.service.care.R;
import com.service.care.application.MyApplication;
import com.service.care.constants.ConstantCodes;
import com.service.care.pojo.PojoEmpAssignedInquiry;
import com.service.care.pojo.PojoEmployeeList;
import com.service.care.utils.Utils;

import java.util.ArrayList;
import java.util.List;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

/**
 * Created by Rp on 8/30/2016.
 */
public class EmployeeAssignedInquiryFragment extends Fragment {

    private View mParentView;

    private Context mContext;
    RelativeLayout mRelativeMain;
    ProgressBar mProgressBar;

    List<PojoEmpAssignedInquiry.Datum> mArrayInquiry = new ArrayList<>();

    MyApplication mApplication;
    private SharedPreferences mSharedPreference;

    TableLayout tblInq;

    TextView tvTotal;
    SearchView search_bar;

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        mParentView = inflater.inflate(R.layout.fragment_employee_assigned_inquiry, container, false);
        mApplication = (MyApplication) getActivity().getApplicationContext();
        mContext = getActivity();
        setHasOptionsMenu(true);
        mSharedPreference = PreferenceManager.getDefaultSharedPreferences(getActivity());

        initialise();

        networkCallInquiry("");

        return mParentView;

    }


    void initialise() {

        Toolbar mToolbar = (Toolbar) getActivity().findViewById(R.id.toolbar);
        mToolbar.setTitle("Assigned Inquiry");
        mToolbar.setVisibility(View.VISIBLE);

        mRelativeMain = mParentView.findViewById(R.id.relative_main);
        mProgressBar = mParentView.findViewById(R.id.progressbar);

        search_bar = mParentView.findViewById(R.id.search_bar);

        LinearLayout linearLayout1 = (LinearLayout) search_bar.getChildAt(0);
        LinearLayout linearLayout2 = (LinearLayout) linearLayout1.getChildAt(2);
        LinearLayout linearLayout3 = (LinearLayout) linearLayout2.getChildAt(1);
        AutoCompleteTextView autoComplete = (AutoCompleteTextView) linearLayout3.getChildAt(0);
        autoComplete.setTextSize(14);

        search_bar.setOnQueryTextListener(new SearchView.OnQueryTextListener() {
            @Override
            public boolean onQueryTextSubmit(String query) {

                networkCallInquiry(query);

                return true;
            }

            @Override
            public boolean onQueryTextChange(String newText) {

                networkCallInquiry(newText);
                return true;
            }
        });

        tblInq = (TableLayout) mParentView.findViewById(R.id.tblInq);
        tblInq.setStretchAllColumns(true);
        tblInq.bringToFront();

        tvTotal = mParentView.findViewById(R.id.tvTotal);

    }


    private void networkCallInquiry(String term) {
        if (mApplication.isInternetConnected()) {

            mProgressBar.setVisibility(View.VISIBLE);

            mApplication.getRetroFitInterface().EmployeeAssignedInquiry(mSharedPreference.getString(ConstantCodes.LOGIN_USER_ID, ""), "1",null, term).enqueue(mCallbackComplain);


        } else {
            Utils.showSnackBar(getActivity(), getResources().getString(R.string
                    .message_connection));
            mProgressBar.setVisibility(View.GONE);
        }
    }


    /**
     * Callback for ws.wolfsoft.propertyplanetapp.network call
     */
    private Callback<PojoEmpAssignedInquiry> mCallbackComplain = new Callback<PojoEmpAssignedInquiry>() {
        @Override
        public void onResponse(Call<PojoEmpAssignedInquiry> call, Response<PojoEmpAssignedInquiry> response) {
            if (response != null && response.isSuccessful() && response.body() != null) {

                PojoEmpAssignedInquiry pojoParticipants = response.body();

                mArrayInquiry.clear();

                if (pojoParticipants.getStatus() == 1) {

                    if (pojoParticipants.getData() != null) {
                        if (pojoParticipants.getData().size() > 0) {
                            mArrayInquiry.addAll(pojoParticipants.getData());
                            getTableData();
                        } else {
                            try {
                                tblInq.removeAllViews();

                            } catch (Exception e) {

                            }
                        }
                    } else {
                        try {
                            tblInq.removeAllViews();

                        } catch (Exception e) {

                        }
                    }

                } else {
                    try {
                        tblInq.removeAllViews();

                    } catch (Exception e) {

                    }
                    if (!TextUtils.isEmpty(pojoParticipants.getMessage())) {
                        Utils.showSnackBar(getActivity(), pojoParticipants.getMessage());

                    } else {
                        Utils.showSnackBar(getActivity(), getString(R.string
                                .message_something_wrong));
                    }

                }
            } else {
                Utils.showSnackBar(getActivity(), getString(R.string.message_something_wrong));
                mProgressBar.setVisibility(View.GONE);
            }
            mProgressBar.setVisibility(View.GONE);

        }

        @Override
        public void onFailure(Call<PojoEmpAssignedInquiry> call, Throwable t) {
            try {
                try {
                    tblInq.removeAllViews();

                } catch (Exception e) {

                }
                Utils.showSnackBar(getActivity(), getString(R.string
                        .message_something_wrong));
                mProgressBar.setVisibility(View.GONE);
            } catch (Exception e) {

            }
        }
    };

    void getTableData() {

        int totalAmount = 0;
        tblInq.removeAllViews();

        try {
            for (int i = 0; i < mArrayInquiry.size() + 1; i++) {
                TableRow tr = new TableRow(mContext);

                if (i == 0) {

                    TextView c1 = new TextView(mContext);
                    c1.setText("Date");
                    c1.setBackground(mContext.getResources().getDrawable(R.drawable.simple_gray_rect));
                    c1.setTextColor(mContext.getResources().getColor(R.color.app_white));
                    c1.setGravity(Gravity.CENTER);
                    TextView c2 = new TextView(mContext);
                    c2.setText("Customer Name");
                    c2.setBackground(mContext.getResources().getDrawable(R.drawable.simple_gray_rect));
                    c2.setTextColor(mContext.getResources().getColor(R.color.app_white));
                    c2.setGravity(Gravity.CENTER);
                    TextView c3 = new TextView(mContext);
                    c3.setText("Mobile");
                    c3.setBackground(mContext.getResources().getDrawable(R.drawable.simple_gray_rect));
                    c3.setTextColor(mContext.getResources().getColor(R.color.app_white));
                    c3.setGravity(Gravity.CENTER);
                    TextView c4 = new TextView(mContext);
                    c4.setText("Area");
                    c4.setBackground(mContext.getResources().getDrawable(R.drawable.simple_gray_rect));
                    c4.setTextColor(mContext.getResources().getColor(R.color.app_white));
                    c4.setGravity(Gravity.CENTER);
                    TextView c5 = new TextView(mContext);
                    c5.setText("Status");
                    c5.setBackground(mContext.getResources().getDrawable(R.drawable.simple_gray_rect));
                    c5.setTextColor(mContext.getResources().getColor(R.color.app_white));
                    c5.setGravity(Gravity.CENTER);
                    TextView c6 = new TextView(mContext);
                    c6.setText("Price");
                    c6.setBackground(mContext.getResources().getDrawable(R.drawable.simple_gray_rect));
                    c6.setTextColor(mContext.getResources().getColor(R.color.app_white));
                    c6.setGravity(Gravity.CENTER);

                    c1.setPadding(20, 2, 20, 2);
                    c2.setPadding(20, 2, 20, 2);
                    c3.setPadding(20, 2, 20, 2);
                    c4.setPadding(20, 2, 20, 2);
                    c5.setPadding(20, 2, 20, 2);
                    c6.setPadding(20, 2, 20, 2);

                    tr.addView(c1);
                    tr.addView(c2);
                    tr.addView(c3);
                    tr.addView(c4);
                    tr.addView(c5);
                    tr.addView(c6);


                    tblInq.addView(tr);

                } else {

                    TextView c1 = new TextView(mContext);
                    c1.setText("" + mArrayInquiry.get(i - 1).getBookDate());
                    c1.setGravity(Gravity.CENTER);
                    c1.setBackground(mContext.getResources().getDrawable(R.drawable.simple_border));
                    TextView c2 = new TextView(mContext);
                    c2.setText("" + mArrayInquiry.get(i - 1).getName());
                    c2.setGravity(Gravity.CENTER);
                    c2.setBackground(mContext.getResources().getDrawable(R.drawable.simple_border));
                    TextView c3 = new TextView(mContext);
                    c3.setText("" + mArrayInquiry.get(i - 1).getMobile());
                    c3.setBackground(mContext.getResources().getDrawable(R.drawable.simple_border));
                    c3.setGravity(Gravity.CENTER);
                    TextView c4 = new TextView(mContext);
                    c4.setText("" + mArrayInquiry.get(i - 1).getArea());
                    c4.setBackground(mContext.getResources().getDrawable(R.drawable.simple_border));
                    c4.setGravity(Gravity.CENTER);
                    TextView c5 = new TextView(mContext);
                    c5.setText("" + mArrayInquiry.get(i - 1).getStatus());
                    c5.setBackground(mContext.getResources().getDrawable(R.drawable.simple_border));
                    c5.setGravity(Gravity.CENTER);
                    TextView c6 = new TextView(mContext);
                    if (mArrayInquiry.get(i - 1).getAsignStatus().equals("3")) {
                        totalAmount = totalAmount + Integer.parseInt(mArrayInquiry.get(i - 1).getFinalAmmount());
                        c6.setText("\u20B9 " + mArrayInquiry.get(i - 1).getFinalAmmount());
                    } else {
                        totalAmount = totalAmount + Integer.parseInt(mArrayInquiry.get(i - 1).getPrice());
                        c6.setText("\u20B9 " + mArrayInquiry.get(i - 1).getPrice());
                    }
                    c6.setBackground(mContext.getResources().getDrawable(R.drawable.simple_border));
                    c6.setGravity(Gravity.CENTER);

                    c1.setPadding(20, 2, 20, 2);
                    c2.setPadding(20, 2, 20, 2);
                    c3.setPadding(20, 2, 20, 2);
                    c4.setPadding(20, 2, 20, 2);
                    c5.setPadding(20, 2, 20, 2);
                    c6.setPadding(20, 2, 20, 2);

                    tr.addView(c1);
                    tr.addView(c2);
                    tr.addView(c3);
                    tr.addView(c4);
                    tr.addView(c5);
                    tr.addView(c6);
                    tblInq.addView(tr);
                }
            }

        } catch (Exception e) {

        }


        tvTotal.setText("Total Services Income :  \u20B9 " + totalAmount + "/-");

    }


}
