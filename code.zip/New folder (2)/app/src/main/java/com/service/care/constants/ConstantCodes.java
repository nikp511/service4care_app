package com.service.care.constants;

/**
 * Created by smit_shah on 04-Apr-17.
 * <p>
 * Constants for the ws.wolfsoft.propertyplanetapp.application
 */

public class ConstantCodes {

    public static final int TIMEOUT_SECONDS = 60;
    public static final String BASE_URL = "https://service4care.com/api/";


    public static final String METHOD_GET_LOGIN_OTP = "getOtp";
    public static final String METHOD_VERIFY_USER_LOGIN_OTP = "check_otp";
    public static final String METHOD_VERIFY_EMP_LOGIN_OTP = "check_emp_otp";
    public static final String METHOD_VERIFY_ADMIN_LOGIN_OTP = "checkAdmin_otp";
    public static final String METHOD_CATEGORY = "GetCategory";
    public static final String METHOD_SUB_CATEGORY = "GetSubCategory";
    public static final String METHOD_PRODUCT = "GetProduct";
    public static final String METHOD_TESTIMONIAL = "testimonial";
    public static final String METHOD_USER_MY_COMPLAINTS = "myComplaints";
    public static final String METHOD_EMP_MY_COMPLAINTS = "empMyComplaints";
    public static final String METHOD_ADD_COMPLAINTS = "complaint";
    public static final String METHOD_MY_INQUIRY = "myInquiry";
    public static final String METHOD_ADD_INQUIRY = "inquiry";
    public static final String METHOD_NEWS_OFFER = "offers";
    public static final String METHOD_MY_ORDER = "myBookings";
    public static final String METHOD_BOOK_SERVICE = "bookService";
    public static final String METHOD_UPDATE_PROFILE = "update_userDetail";
    public static final String METHOD_ADD_EMPLOYEE = "addEmployee";
    public static final String METHOD_EMPLOYEE_LIST = "getEmployeeDetail";
    public static final String METHOD_ADMIN_ALL_ORDER = "allOrder";
    public static final String METHOD_ADMIN_ASSIGN_ORDER = "assignOrder";
    public static final String METHOD_ADMIN_COLLECTED_CASH = "collectCash";
    public static final String METHOD_ADMIN_PROFILE = "updateAdmin";
    public static final String METHOD_ADMIN_LEAVES = "allLeaves";
    public static final String METHOD_ADMIN_LEAVES_APPROVE = "approveLeaves";
    public static final String METHOD_EDIT_EMPLOYEE_PROFILE = "editEmployee";
    public static final String METHOD_ADMIN_EMP_INACTIVE = "activeInactiveEmp";
    public static final String METHOD_EMP_ASSIGNED_INQUIRY = "assignedInquiry";
    public static final String METHOD_EMP_ADD_LEAVE = "addLeave";
    public static final String METHOD_EMP_ADD_COMPLAIN = "empComplaint";
    public static final String METHOD_EMP_MY_LEAVES = "myLeaves";
    public static final String METHOD_EMP_COMPLETE_INQUIRY = "completetWork";
    public static final String METHOD_EMP_DASHBOARD = "empDashboard";
    public static final String METHOD_ADMIN_DASHBOARD = "adminDashboard";
    public static final String METHOD_HOME_BANNER = "homeBanner";
    public static final String METHOD_FEEDBACK = "userFeedback";
    public static final String METHOD_RATE_US = "userRating";
    public static final String METHOD_EMP_INQUIRY_APPROVAL = "empApproveInq";

    public static final String IS_LOGIN = "is_login";

    public static final String LOGIN_USERTYPE = "login_user_type";

    public static final String LOGIN_USER_ID = "is_user_login_id";
    public static final String LOGIN_USER_NAME = "login_user_name";
    public static final String LOGIN_USER_MOBILE = "is_user_login_mobile";
    public static final String LOGIN_USER_IMAGE = "is_user_login_image";
    public static final String LOGIN_USER_ADDRESS = "is_user_login_address";
    public static final String LOGIN_USER_AREA = "is_user_login_area";
    public static final String LOGIN_USER_PINCODE = "is_user_login_pincode";
    public static final String LOGIN_USER_OFFER_CODE = "is_user_login_offercode";

    public static final String LOGIN_USER_EMPLOYEE_CODE = "is_user_login_empcode";
    public static final String LOGIN_USER_EMPLOYEE_CITY = "is_user_login_empcity";
    public static final String LOGIN_USER_EMPLOYEE_AADHAR_CARD = "is_user_login_empaadharcard";

}
