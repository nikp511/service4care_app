package com.service.care.fragments.employess;

import android.content.Context;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.preference.PreferenceManager;
import android.text.TextUtils;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ProgressBar;
import android.widget.RelativeLayout;

import androidx.appcompat.widget.Toolbar;
import androidx.fragment.app.Fragment;
import androidx.recyclerview.widget.DefaultItemAnimator;
import androidx.recyclerview.widget.GridLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.service.care.R;
import com.service.care.adapter.AllComplainAdapter;
import com.service.care.adapter.AllInquiryDetailAdapter;
import com.service.care.adapter.EmpRequestInquiryAdapter;
import com.service.care.application.MyApplication;
import com.service.care.constants.ConstantCodes;
import com.service.care.pojo.PojoAllComplain;
import com.service.care.pojo.PojoCommon;
import com.service.care.pojo.PojoEmpAssignedInquiry;
import com.service.care.utils.Utils;

import java.util.ArrayList;
import java.util.List;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

/**
 * Created by Rp on 8/30/2016.
 */
public class EmployeeInquiryRequestFragment extends Fragment {

    private View mParentView;

    private Context mContext;
    RelativeLayout mRelativeMain;
    ProgressBar mProgressBar;

    MyApplication mApplication;
    private SharedPreferences mSharedPreference;


    RecyclerView rvRequest;

    List<PojoEmpAssignedInquiry.Datum> mArrayInquiry = new ArrayList<>();

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        mParentView = inflater.inflate(R.layout.fragment_emp_inq_request, container, false);
        mApplication = (MyApplication) getActivity().getApplicationContext();
        mContext = getActivity();
        setHasOptionsMenu(true);
        mSharedPreference = PreferenceManager.getDefaultSharedPreferences(getActivity());

        initialise();
        listners();

        networkCallInqRequest();

        return mParentView;

    }


    void initialise() {

        Toolbar mToolbar = (Toolbar) getActivity().findViewById(R.id.toolbar);
        mToolbar.setTitle("Inquiry Request");
        mToolbar.setVisibility(View.VISIBLE);

        mRelativeMain = mParentView.findViewById(R.id.relative_main);
        mProgressBar = mParentView.findViewById(R.id.progressbar);


        rvRequest = mParentView.findViewById(R.id.rvOrder);
        GridLayoutManager layoutManagerContact = new GridLayoutManager(mContext, 1);
        rvRequest.setLayoutManager(layoutManagerContact);
        rvRequest.setItemAnimator(new DefaultItemAnimator());


    }

    void listners() {

    }

    private void networkCallInqRequest() {
        if (mApplication.isInternetConnected()) {

            mProgressBar.setVisibility(View.VISIBLE);

            mApplication.getRetroFitInterface().EmployeeAssignedInquiry(mSharedPreference.getString(ConstantCodes.LOGIN_USER_ID, ""), "0",null, "").enqueue(mCallbackComplain);


        } else {
            Utils.showSnackBar(getActivity(), getResources().getString(R.string
                    .message_connection));
            mProgressBar.setVisibility(View.GONE);
        }
    }


    /**
     * Callback for ws.wolfsoft.propertyplanetapp.network call
     */
    private Callback<PojoEmpAssignedInquiry> mCallbackComplain = new Callback<PojoEmpAssignedInquiry>() {
        @Override
        public void onResponse(Call<PojoEmpAssignedInquiry> call, Response<PojoEmpAssignedInquiry> response) {

            try {
                if (response != null && response.isSuccessful() && response.body() != null) {

                    PojoEmpAssignedInquiry pojoParticipants = response.body();

                    mArrayInquiry.clear();

                    if (pojoParticipants.getStatus() == 1) {

                        if (pojoParticipants.getData() != null) {
                            if (pojoParticipants.getData().size() > 0) {
                                mArrayInquiry.addAll(pojoParticipants.getData());
                                EmpRequestInquiryAdapter allInquiryDetailAdapter = new EmpRequestInquiryAdapter(mContext, mArrayInquiry, customClick);
                                rvRequest.setAdapter(allInquiryDetailAdapter);
                            }
                        }

                    } else {
                        rvRequest.setAdapter(null);
                        if (!TextUtils.isEmpty(pojoParticipants.getMessage())) {
                            Utils.showSnackBar(getActivity(), pojoParticipants.getMessage());

                        } else {
                            Utils.showSnackBar(getActivity(), getString(R.string
                                    .message_something_wrong));
                        }

                    }
                } else {
                    Utils.showSnackBar(getActivity(), getString(R.string.message_something_wrong));
                    mProgressBar.setVisibility(View.GONE);
                }
                mProgressBar.setVisibility(View.GONE);
            } catch (Exception e) {

            }


        }

        @Override
        public void onFailure(Call<PojoEmpAssignedInquiry> call, Throwable t) {
            try {
                Utils.showSnackBar(getActivity(), getString(R.string
                        .message_something_wrong));
                mProgressBar.setVisibility(View.GONE);
            } catch (Exception e) {

            }
        }
    };

    EmpRequestInquiryAdapter.CustomClick customClick = new EmpRequestInquiryAdapter.CustomClick() {
        @Override
        public void submitClick(PojoEmpAssignedInquiry.Datum datum, String what) {
            networkCallAction(datum.getBookServiceId(), what);
        }
    };


    private void networkCallAction(String id, String action) {

        try {
            if (mApplication.isInternetConnected()) {

                mProgressBar.setVisibility(View.VISIBLE);

                mApplication.getRetroFitInterface().EmpInquiryRequest(mSharedPreference.getString(ConstantCodes.LOGIN_USER_ID, ""),
                        id,
                        action).enqueue(mCallbackAddEmployee);

            } else {
                Utils.showSnackBar(getActivity(), getResources().getString(R.string
                        .message_connection));
                mProgressBar.setVisibility(View.GONE);
            }
        } catch (Exception e) {

        }

    }

    /**
     * Callback for ws.wolfsoft.propertyplanetapp.network call
     */
    private Callback<PojoCommon> mCallbackAddEmployee = new Callback<PojoCommon>() {
        @Override
        public void onResponse(Call<PojoCommon> call, Response<PojoCommon> response) {

            try {
                if (response != null && response.isSuccessful() && response.body() != null) {

                    PojoCommon pojoParticipants = response.body();

                    if (pojoParticipants.getStatus() == 1) {

                        Utils.showSnackBar(getActivity(), "" + pojoParticipants.getMessage());

                        networkCallInqRequest();


                    } else {
                        if (!TextUtils.isEmpty(pojoParticipants.getMessage())) {
                            Utils.showSnackBar(getActivity(), pojoParticipants.getMessage());

                        } else {
                            Utils.showSnackBar(getActivity(), getString(R.string
                                    .message_something_wrong));
                        }
                    }
                } else {
                    Utils.showSnackBar(getActivity(), getString(R.string.message_something_wrong));
                    mProgressBar.setVisibility(View.GONE);
                }
                mProgressBar.setVisibility(View.GONE);
            } catch (Exception e) {

            }


        }

        @Override
        public void onFailure(Call<PojoCommon> call, Throwable t) {
            try {
                Utils.showSnackBar(getActivity(), getString(R.string
                        .message_something_wrong));
                mProgressBar.setVisibility(View.GONE);
            } catch (Exception e) {

            }
        }
    };


}
