package com.service.care.pojo;

import com.google.gson.annotations.Expose;
import com.google.gson.annotations.SerializedName;

import java.io.Serializable;
import java.util.List;

public class PojoProduct implements Serializable {


    @SerializedName("status")
    @Expose
    private Integer status;
    @SerializedName("message")
    @Expose
    private String message;
    @SerializedName("data")
    @Expose
    private List<Datum> data = null;

    public Integer getStatus() {
        return status;
    }

    public void setStatus(Integer status) {
        this.status = status;
    }

    public String getMessage() {
        return message;
    }

    public void setMessage(String message) {
        this.message = message;
    }

    public List<Datum> getData() {
        return data;
    }

    public void setData(List<Datum> data) {
        this.data = data;
    }

    public class Datum implements Serializable {

        @SerializedName("id")
        @Expose
        private String id;
        @SerializedName("serviceSubcategoryId")
        @Expose
        private String serviceSubcategoryId;
        @SerializedName("name")
        @Expose
        private String name;
        @SerializedName("image")
        @Expose
        private String image;
        @SerializedName("price")
        @Expose
        private String price;
        @SerializedName("details")
        @Expose
        private String details;
        @SerializedName("is_price")
        @Expose
        private String isPrice;
        @SerializedName("is_remark")
        @Expose
        private String isRemark;
        @SerializedName("dt_created")
        @Expose
        private String dtCreated;
        @SerializedName("dt_updated")
        @Expose
        private String dtUpdated;
        @SerializedName("subCategory_name")
        @Expose
        private String subCategoryName;
        @SerializedName("category_name")
        @Expose
        private String categoryName;
        @SerializedName("extraService")
        @Expose
        private List<ExtraService> extraService = null;

        private String myAndroidQtyCalulator = "1";

        public String getMyAndroidQtyCalulator() {
            return myAndroidQtyCalulator;
        }

        public void setMyAndroidQtyCalulator(String myAndroidQtyCalulator) {
            this.myAndroidQtyCalulator = myAndroidQtyCalulator;
        }

        public String getIsPrice() {
            return isPrice;
        }

        public void setIsPrice(String isPrice) {
            this.isPrice = isPrice;
        }

        public String getIsRemark() {
            return isRemark;
        }

        public void setIsRemark(String isRemark) {
            this.isRemark = isRemark;
        }

        public String getId() {
            return id;
        }

        public void setId(String id) {
            this.id = id;
        }

        public String getServiceSubcategoryId() {
            return serviceSubcategoryId;
        }

        public void setServiceSubcategoryId(String serviceSubcategoryId) {
            this.serviceSubcategoryId = serviceSubcategoryId;
        }

        public String getName() {
            return name;
        }

        public void setName(String name) {
            this.name = name;
        }

        public String getImage() {
            return image;
        }

        public void setImage(String image) {
            this.image = image;
        }

        public String getPrice() {
            return price;
        }

        public void setPrice(String price) {
            this.price = price;
        }

        public String getDetails() {
            return details;
        }

        public void setDetails(String details) {
            this.details = details;
        }

        public String getDtCreated() {
            return dtCreated;
        }

        public void setDtCreated(String dtCreated) {
            this.dtCreated = dtCreated;
        }

        public String getDtUpdated() {
            return dtUpdated;
        }

        public void setDtUpdated(String dtUpdated) {
            this.dtUpdated = dtUpdated;
        }

        public String getSubCategoryName() {
            return subCategoryName;
        }

        public void setSubCategoryName(String subCategoryName) {
            this.subCategoryName = subCategoryName;
        }

        public String getCategoryName() {
            return categoryName;
        }

        public void setCategoryName(String categoryName) {
            this.categoryName = categoryName;
        }

        public List<ExtraService> getExtraService() {
            return extraService;
        }

        public void setExtraService(List<ExtraService> extraService) {
            this.extraService = extraService;
        }

    }

    public class ExtraService implements Serializable {

        @SerializedName("id")
        @Expose
        private String id;
        @SerializedName("serviceProductId")
        @Expose
        private String serviceProductId;
        @SerializedName("name")
        @Expose
        private String name;
        @SerializedName("price")
        @Expose
        private String price;

        public String getId() {
            return id;
        }

        public void setId(String id) {
            this.id = id;
        }

        public String getServiceProductId() {
            return serviceProductId;
        }

        public void setServiceProductId(String serviceProductId) {
            this.serviceProductId = serviceProductId;
        }

        public String getName() {
            return name;
        }

        public void setName(String name) {
            this.name = name;
        }

        public String getPrice() {
            return price;
        }

        public void setPrice(String price) {
            this.price = price;
        }

    }

}
