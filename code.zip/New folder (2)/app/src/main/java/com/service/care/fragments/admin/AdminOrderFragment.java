package com.service.care.fragments.admin;

import android.app.DatePickerDialog;
import android.app.TimePickerDialog;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.preference.PreferenceManager;
import android.text.TextUtils;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.CompoundButton;
import android.widget.DatePicker;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.ProgressBar;
import android.widget.RadioButton;
import android.widget.RelativeLayout;
import android.widget.TextView;
import android.widget.TimePicker;
import android.widget.Toast;

import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.widget.Toolbar;
import androidx.fragment.app.Fragment;
import androidx.recyclerview.widget.DefaultItemAnimator;
import androidx.recyclerview.widget.GridLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.service.care.R;
import com.service.care.activity.LoginActivity;
import com.service.care.activity.MainActivity;
import com.service.care.adapter.AdminOrderAdapter;
import com.service.care.adapter.AllInquiryAdapter;
import com.service.care.application.MyApplication;
import com.service.care.constants.ConstantCodes;
import com.service.care.pojo.PojoAllInquiry;
import com.service.care.pojo.PojoAllOrder;
import com.service.care.pojo.PojoAllOrderAdmin;
import com.service.care.pojo.PojoCommon;
import com.service.care.pojo.PojoEmployeeList;
import com.service.care.utils.Utils;

import java.util.ArrayList;
import java.util.Calendar;
import java.util.List;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

/**
 * Created by Rp on 8/30/2016.
 */
public class AdminOrderFragment extends Fragment {

    private View mParentView;

    private Context mContext;
    RelativeLayout mRelativeMain;
    ProgressBar mProgressBar;

    MyApplication mApplication;
    private SharedPreferences mSharedPreference;

    TextView tvAll, tvCompleted, tvPending, tvToday;

    RecyclerView rvOrder;

    AdminOrderAdapter adminOrderAdapter;

    List<PojoAllOrderAdmin.Datum> mArrayAllOrder = new ArrayList<>();
    List<PojoEmployeeList.Datum> mArrayEmployee = new ArrayList<>();

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        mParentView = inflater.inflate(R.layout.fragment_admin_order, container, false);
        mApplication = (MyApplication) getActivity().getApplicationContext();
        mContext = getActivity();
        setHasOptionsMenu(true);
        mSharedPreference = PreferenceManager.getDefaultSharedPreferences(getActivity());

        initialise();
        listners();
        networkCallEmployee();

        tvAll.performClick();

        return mParentView;

    }


    void initialise() {

        Toolbar mToolbar = (Toolbar) getActivity().findViewById(R.id.toolbar);
        mToolbar.setTitle("All Order");
        mToolbar.setVisibility(View.VISIBLE);

        mRelativeMain = mParentView.findViewById(R.id.relative_main);
        mProgressBar = mParentView.findViewById(R.id.progressbar);

        tvAll = mParentView.findViewById(R.id.tvAll);
        tvCompleted = mParentView.findViewById(R.id.tvCompleted);
        tvPending = mParentView.findViewById(R.id.tvPending);
        tvToday = mParentView.findViewById(R.id.tvToday);

        rvOrder = mParentView.findViewById(R.id.rvOrder);
        GridLayoutManager layoutManagerContact = new GridLayoutManager(mContext, 1);
        rvOrder.setLayoutManager(layoutManagerContact);
        rvOrder.setItemAnimator(new DefaultItemAnimator());


    }

    void listners() {

        tvAll.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                tvAll.setTextColor(mContext.getResources().getColor(R.color.app_white));
                tvCompleted.setTextColor(mContext.getResources().getColor(R.color.app_black));
                tvPending.setTextColor(mContext.getResources().getColor(R.color.app_black));
                tvToday.setTextColor(mContext.getResources().getColor(R.color.app_black));

                tvAll.setBackground(mContext.getResources().getDrawable(R.drawable.app_rect));
                tvCompleted.setBackground(mContext.getResources().getDrawable(R.drawable.app_border));
                tvPending.setBackground(mContext.getResources().getDrawable(R.drawable.app_border));
                tvToday.setBackground(mContext.getResources().getDrawable(R.drawable.app_border));

                networkCallOrder(null);

            }
        });

        tvCompleted.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                tvCompleted.setTextColor(mContext.getResources().getColor(R.color.app_white));
                tvAll.setTextColor(mContext.getResources().getColor(R.color.app_black));
                tvPending.setTextColor(mContext.getResources().getColor(R.color.app_black));
                tvToday.setTextColor(mContext.getResources().getColor(R.color.app_black));

                tvCompleted.setBackground(mContext.getResources().getDrawable(R.drawable.app_rect));
                tvAll.setBackground(mContext.getResources().getDrawable(R.drawable.app_border));
                tvPending.setBackground(mContext.getResources().getDrawable(R.drawable.app_border));
                tvToday.setBackground(mContext.getResources().getDrawable(R.drawable.app_border));

                networkCallOrder("c");

            }
        });

        tvPending.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                tvPending.setTextColor(mContext.getResources().getColor(R.color.app_white));
                tvCompleted.setTextColor(mContext.getResources().getColor(R.color.app_black));
                tvAll.setTextColor(mContext.getResources().getColor(R.color.app_black));
                tvToday.setTextColor(mContext.getResources().getColor(R.color.app_black));

                tvPending.setBackground(mContext.getResources().getDrawable(R.drawable.app_rect));
                tvCompleted.setBackground(mContext.getResources().getDrawable(R.drawable.app_border));
                tvAll.setBackground(mContext.getResources().getDrawable(R.drawable.app_border));
                tvToday.setBackground(mContext.getResources().getDrawable(R.drawable.app_border));

                networkCallOrder("p");

            }
        });


        tvToday.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                tvPending.setTextColor(mContext.getResources().getColor(R.color.app_black));
                tvCompleted.setTextColor(mContext.getResources().getColor(R.color.app_black));
                tvAll.setTextColor(mContext.getResources().getColor(R.color.app_black));
                tvToday.setTextColor(mContext.getResources().getColor(R.color.app_white));

                tvPending.setBackground(mContext.getResources().getDrawable(R.drawable.app_border));
                tvCompleted.setBackground(mContext.getResources().getDrawable(R.drawable.app_border));
                tvAll.setBackground(mContext.getResources().getDrawable(R.drawable.app_border));
                tvToday.setBackground(mContext.getResources().getDrawable(R.drawable.app_rect));

                networkCallOrder("t");

            }
        });

    }


    private void networkCallOrder(String status) {
        if (mApplication.isInternetConnected()) {

            mProgressBar.setVisibility(View.VISIBLE);

            mApplication.getRetroFitInterface().AdminOrder(status).enqueue(mCallbackComplain);


        } else {
            Utils.showSnackBar(getActivity(), getResources().getString(R.string
                    .message_connection));
            mProgressBar.setVisibility(View.GONE);
        }
    }


    /**
     * Callback for ws.wolfsoft.propertyplanetapp.network call
     */
    private Callback<PojoAllOrderAdmin> mCallbackComplain = new Callback<PojoAllOrderAdmin>() {
        @Override
        public void onResponse(Call<PojoAllOrderAdmin> call, Response<PojoAllOrderAdmin> response) {
            if (response != null && response.isSuccessful() && response.body() != null) {

                PojoAllOrderAdmin pojoParticipants = response.body();

                mArrayAllOrder.clear();

                if (pojoParticipants.getStatus() == 1) {

                    if (pojoParticipants.getData() != null) {
                        if (pojoParticipants.getData().size() > 0) {

                            mArrayAllOrder.addAll(pojoParticipants.getData());

                            adminOrderAdapter = new AdminOrderAdapter(mContext, mArrayAllOrder, customClick);
                            rvOrder.setAdapter(adminOrderAdapter);

                        } else {
                            rvOrder.setAdapter(null);
                        }
                    } else {
                        rvOrder.setAdapter(null);
                    }

                } else {
                    rvOrder.setAdapter(null);
                    if (!TextUtils.isEmpty(pojoParticipants.getMessage())) {
                        Utils.showSnackBar(getActivity(), pojoParticipants.getMessage());

                    } else {
                        Utils.showSnackBar(getActivity(), getString(R.string
                                .message_something_wrong));
                    }

                }
            } else {
                Utils.showSnackBar(getActivity(), getString(R.string.message_something_wrong));
                mProgressBar.setVisibility(View.GONE);
            }
            mProgressBar.setVisibility(View.GONE);

        }

        @Override
        public void onFailure(Call<PojoAllOrderAdmin> call, Throwable t) {
            try {
                Utils.showSnackBar(getActivity(), getString(R.string
                        .message_something_wrong));
                mProgressBar.setVisibility(View.GONE);
            } catch (Exception e) {

            }
        }
    };

    AdminOrderAdapter.CustomClick customClick = new AdminOrderAdapter.CustomClick() {
        @Override
        public void assignClick(PojoAllOrderAdmin.Datum datum) {

            if (datum.getAsignStatus().equals("0") || datum.getAsignStatus().equals("8")) {
                // assign to employee api
                showEmpPopup(datum.getId() + "");
            } else if (datum.getAsignStatus().equals("1")) {
                showAssigned(datum.getAssingned().getName() + "", "This Inquiry/Order is assigned to ", "Assigned To");
            } else if (datum.getAsignStatus().equals("3")) {
                showAssigned(datum.getAssingned().getName() + "", "This Inquiry/Order is Completed", "Completed");
            }

        }
    };


    void showAssigned(String name, String msg, String title) {
        AlertDialog.Builder alertDialog2 = new AlertDialog.Builder(
                mContext, R.style.CustomDialogTheme);
        alertDialog2.setTitle(title);
        alertDialog2.setMessage(msg + name);

        alertDialog2.show();
    }


    private void networkCallAssign(String bookServiceId, String employeeId) {
        if (mApplication.isInternetConnected()) {

            mProgressBar.setVisibility(View.VISIBLE);

            mApplication.getRetroFitInterface().AdminAssignOrder(bookServiceId, employeeId).enqueue(mCallbackAssign);


        } else {
            Utils.showSnackBar(getActivity(), getResources().getString(R.string
                    .message_connection));
            mProgressBar.setVisibility(View.GONE);
        }
    }

    /**
     * Callback for ws.wolfsoft.propertyplanetapp.network call
     */
    private Callback<PojoCommon> mCallbackAssign = new Callback<PojoCommon>() {
        @Override
        public void onResponse(Call<PojoCommon> call, Response<PojoCommon> response) {
            if (response != null && response.isSuccessful() && response.body() != null) {

                PojoCommon pojoParticipants = response.body();

                alertDialog.dismiss();

                if (pojoParticipants.getStatus() == 1) {

                    Utils.showSnackBar(getActivity(), "" + pojoParticipants.getMessage());
                    networkCallOrder(null);

                } else {
                    if (!TextUtils.isEmpty(pojoParticipants.getMessage())) {
                        Utils.showSnackBar(getActivity(), pojoParticipants.getMessage());

                    } else {
                        Utils.showSnackBar(getActivity(), getString(R.string
                                .message_something_wrong));
                    }

                }
            } else {
                Utils.showSnackBar(getActivity(), getString(R.string.message_something_wrong));
                mProgressBar.setVisibility(View.GONE);
            }
            mProgressBar.setVisibility(View.GONE);

        }

        @Override
        public void onFailure(Call<PojoCommon> call, Throwable t) {
            try {
                Utils.showSnackBar(getActivity(), getString(R.string
                        .message_something_wrong));
                mProgressBar.setVisibility(View.GONE);
            } catch (Exception e) {

            }
        }
    };


    private void networkCallEmployee() {
        if (mApplication.isInternetConnected()) {


            mApplication.getRetroFitInterface().EmployeeList("").enqueue(mCallbackEMp);


        } else {
            Utils.showSnackBar(getActivity(), getResources().getString(R.string
                    .message_connection));
            mProgressBar.setVisibility(View.GONE);
        }
    }


    /**
     * Callback for ws.wolfsoft.propertyplanetapp.network call
     */
    private Callback<PojoEmployeeList> mCallbackEMp = new Callback<PojoEmployeeList>() {
        @Override
        public void onResponse(Call<PojoEmployeeList> call, Response<PojoEmployeeList> response) {
            if (response != null && response.isSuccessful() && response.body() != null) {

                PojoEmployeeList pojoParticipants = response.body();

                mArrayEmployee.clear();

                if (pojoParticipants.getStatus() == 1) {

                    if (pojoParticipants.getData() != null) {
                        if (pojoParticipants.getData().size() > 0) {
                            mArrayEmployee.addAll(pojoParticipants.getData());
                        }
                    }

                } else {
                    if (!TextUtils.isEmpty(pojoParticipants.getMessage())) {
                        Utils.showSnackBar(getActivity(), pojoParticipants.getMessage());

                    } else {
                        Utils.showSnackBar(getActivity(), getString(R.string
                                .message_something_wrong));
                    }

                }
            } else {
                Utils.showSnackBar(getActivity(), getString(R.string.message_something_wrong));
                mProgressBar.setVisibility(View.GONE);
            }
            mProgressBar.setVisibility(View.GONE);

        }

        @Override
        public void onFailure(Call<PojoEmployeeList> call, Throwable t) {
            try {
                Utils.showSnackBar(getActivity(), getString(R.string
                        .message_something_wrong));
                mProgressBar.setVisibility(View.GONE);
            } catch (Exception e) {

            }
        }
    };

    AlertDialog alertDialog;

    void showEmpPopup(final String bookServiceId) {

        alertDialog = new AlertDialog.Builder(mContext, R.style.CustomDialogTheme).create();

        alertDialog.setTitle("Select Employee to assign Service");

        LayoutInflater layoutInflater;
        layoutInflater = LayoutInflater.from(mContext);

        final List<RadioButton> rbEmpList = new ArrayList<>();
        rbEmpList.clear();

        View view = layoutInflater.inflate(R.layout.popup_emp_list, null, false);

        LinearLayout linearLayout = view.findViewById(R.id.llPopUpBook);
        linearLayout.removeAllViews();

        TextView tvBook = view.findViewById(R.id.tvBook);

        tvBook.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                String empId = "";
                for (int i = 0; i < rbEmpList.size(); i++) {
                    if (rbEmpList.get(i).isChecked()) {
                        empId = "" + rbEmpList.get(i).getTag();
                    } else {

                    }
                }

                if (!empId.equals("")) {
                    networkCallAssign(bookServiceId, empId);
                } else {
                    Toast.makeText(mContext, "Please Select Employee", Toast.LENGTH_SHORT).show();
                }

            }
        });

        if (mArrayEmployee.size() > 0) {
            for (int i = 0; i < mArrayEmployee.size(); i++) {

                RadioButton rb = new RadioButton(mContext);

                rb.setText("" + mArrayEmployee.get(i).getName() + " -> " + mArrayEmployee.get(i).getEmpNo());
                rb.setId(i);
                rb.setTag("" + mArrayEmployee.get(i).getId());

                rbEmpList.add(rb);

                linearLayout.addView(rb);

            }
        }

        alertDialog.setView(view);

        alertDialog.show();

    }

}
