package com.service.care.pojo;

import com.google.gson.annotations.Expose;
import com.google.gson.annotations.SerializedName;

import java.util.List;

public class PojoAllLeaves {

    @SerializedName("status")
    @Expose
    private Integer status;
    @SerializedName("message")
    @Expose
    private String message;
    @SerializedName("data")
    @Expose
    private List<Datum> data = null;

    public Integer getStatus() {
        return status;
    }

    public void setStatus(Integer status) {
        this.status = status;
    }

    public String getMessage() {
        return message;
    }

    public void setMessage(String message) {
        this.message = message;
    }

    public List<Datum> getData() {
        return data;
    }

    public void setData(List<Datum> data) {
        this.data = data;
    }

    public class Datum {

        @SerializedName("id")
        @Expose
        private String id;
        @SerializedName("employeeId")
        @Expose
        private String employeeId;
        @SerializedName("leaveStartDate")
        @Expose
        private String leaveStartDate;
        @SerializedName("leaveEndDate")
        @Expose
        private String leaveEndDate;
        @SerializedName("reason")
        @Expose
        private String reason;
        @SerializedName("status")
        @Expose
        private String status;
        @SerializedName("dt_created")
        @Expose
        private String dtCreated;
        @SerializedName("dt_updated")
        @Expose
        private String dtUpdated;
        @SerializedName("name")
        @Expose
        private String name;

        public String getId() {
            return id;
        }

        public void setId(String id) {
            this.id = id;
        }

        public String getEmployeeId() {
            return employeeId;
        }

        public void setEmployeeId(String employeeId) {
            this.employeeId = employeeId;
        }

        public String getLeaveStartDate() {
            return leaveStartDate;
        }

        public void setLeaveStartDate(String leaveStartDate) {
            this.leaveStartDate = leaveStartDate;
        }

        public String getLeaveEndDate() {
            return leaveEndDate;
        }

        public void setLeaveEndDate(String leaveEndDate) {
            this.leaveEndDate = leaveEndDate;
        }

        public String getReason() {
            return reason;
        }

        public void setReason(String reason) {
            this.reason = reason;
        }

        public String getStatus() {
            return status;
        }

        public void setStatus(String status) {
            this.status = status;
        }

        public String getDtCreated() {
            return dtCreated;
        }

        public void setDtCreated(String dtCreated) {
            this.dtCreated = dtCreated;
        }

        public String getDtUpdated() {
            return dtUpdated;
        }

        public void setDtUpdated(String dtUpdated) {
            this.dtUpdated = dtUpdated;
        }

        public String getName() {
            return name;
        }

        public void setName(String name) {
            this.name = name;
        }

    }


}
