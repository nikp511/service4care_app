package com.service.care.adapter;

import android.content.Context;
import android.os.Build;
import android.text.Editable;
import android.text.TextWatcher;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.EditText;
import android.widget.TextView;

import androidx.annotation.RequiresApi;
import androidx.recyclerview.widget.RecyclerView;

import com.service.care.R;
import com.service.care.pojo.PojoEmpAssignedInquiry;

import java.util.ArrayList;
import java.util.List;


/**
 * Created by Rp on 6/14/2016.
 */
public class EmpRequestInquiryAdapter extends RecyclerView.Adapter<EmpRequestInquiryAdapter.MyViewHolder> {
    Context context;

    List<PojoEmpAssignedInquiry.Datum> mArrayAllInquiry = new ArrayList<>();
    CustomClick customClick;


    public class MyViewHolder extends RecyclerView.ViewHolder {

        TextView tvName, tvRupess, tvAddress, tvMobile, tvAccept, tvReject;

        public MyViewHolder(View view) {
            super(view);


            tvRupess = view.findViewById(R.id.tvRupess);
            tvName = view.findViewById(R.id.tvName);
            tvAddress = view.findViewById(R.id.tvAddress);
            tvMobile = view.findViewById(R.id.tvMobile);
            tvAccept = view.findViewById(R.id.tvAccept);
            tvReject = view.findViewById(R.id.tvReject);


        }
    }

    public EmpRequestInquiryAdapter(Context context, List<PojoEmpAssignedInquiry.Datum> mArrayAllInquiry, CustomClick customClick) {
        this.mArrayAllInquiry = mArrayAllInquiry;
        this.context = context;
        this.customClick = customClick;

    }

    @Override
    public MyViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
        View itemView = LayoutInflater.from(parent.getContext())
                .inflate(R.layout.item_employee_inquiry_request, parent, false);


        return new MyViewHolder(itemView);

    }

    @RequiresApi(api = Build.VERSION_CODES.JELLY_BEAN)
    @Override
    public void onBindViewHolder(final MyViewHolder holder, final int position) {

        final PojoEmpAssignedInquiry.Datum item = mArrayAllInquiry.get(position);


        holder.tvName.setText("" + item.getProductName());
        holder.tvRupess.setText("" + item.getPrice());
        holder.tvAddress.setText("" + item.getAddress());
        holder.tvMobile.setText("" + item.getMobile());


        holder.tvAccept.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                customClick.submitClick(item, "1");
            }
        });

        holder.tvReject.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                customClick.submitClick(item, "0");
            }
        });


    }


    @Override
    public int getItemCount() {
        return mArrayAllInquiry.size();
    }

    public interface CustomClick {

        void submitClick(PojoEmpAssignedInquiry.Datum datum, String what);

    }

}


