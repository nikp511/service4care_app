package com.service.care.adapter;

import android.content.Context;
import android.os.Build;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.RequiresApi;
import androidx.recyclerview.widget.RecyclerView;

import com.service.care.R;
import com.service.care.pojo.PojoAllInquiry;
import com.service.care.pojo.PojoAllOrderAdmin;
import com.service.care.pojo.PojoProduct;

import java.util.ArrayList;
import java.util.List;


/**
 * Created by Rp on 6/14/2016.
 */
public class AdminOrderAdapter extends RecyclerView.Adapter<AdminOrderAdapter.MyViewHolder> {
    Context context;

    List<PojoAllOrderAdmin.Datum> mArrayAllOrder = new ArrayList<>();
    CustomClick customClick;

    public class MyViewHolder extends RecyclerView.ViewHolder {

        TextView tvName, tvAddress, tvMobile, tvText, tvDate, tvTime, tvAssigned;

        public MyViewHolder(View view) {
            super(view);

            tvName = view.findViewById(R.id.tvName);
            tvAddress = view.findViewById(R.id.tvAddress);
            tvMobile = view.findViewById(R.id.tvMobile);
            tvText = view.findViewById(R.id.tvText);
            tvDate = view.findViewById(R.id.tvDate);
            tvTime = view.findViewById(R.id.tvTime);
            tvAssigned = view.findViewById(R.id.tvAssigned);

        }
    }

    public AdminOrderAdapter(Context context, List<PojoAllOrderAdmin.Datum> mArrayAllOrder, CustomClick customClick) {
        this.mArrayAllOrder = mArrayAllOrder;
        this.context = context;
        this.customClick = customClick;

    }

    @Override
    public MyViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
        View itemView = LayoutInflater.from(parent.getContext())
                .inflate(R.layout.item_admin_order, parent, false);


        return new MyViewHolder(itemView);

    }

    @RequiresApi(api = Build.VERSION_CODES.JELLY_BEAN)
    @Override
    public void onBindViewHolder(final MyViewHolder holder, final int position) {

        final PojoAllOrderAdmin.Datum item = mArrayAllOrder.get(position);

        holder.tvName.setText("" + item.getName());
        holder.tvAddress.setText("" + item.getAddress());
        holder.tvMobile.setText("" + item.getMobile());
        holder.tvText.setText("" + item.getProductName());
        holder.tvDate.setText("" + item.getBookDate());
        holder.tvTime.setText("" + item.getBookDate().substring(item.getBookDate().indexOf(" ")));

        if (item.getAsignStatus().equals("0")) {
            holder.tvAssigned.setBackground(context.getResources().getDrawable(R.drawable.red_rect));
        } else if (item.getAsignStatus().equals("1") || item.getAsignStatus().equals("3")) {
            holder.tvAssigned.setBackground(context.getResources().getDrawable(R.drawable.green_rect));
        } else if (item.getAsignStatus().equals("8")) {
            holder.tvAssigned.setBackground(context.getResources().getDrawable(R.drawable.red_rect));
        }

        if (item.getAsignStatus().equals("1")) {
            holder.tvAssigned.setText("Assigned");
        } else if (item.getAsignStatus().equals("0")) {
            holder.tvAssigned.setText("Assign To");
        } else if (item.getAsignStatus().equals("8")) {
            holder.tvAssigned.setText("Empolyee Not Accepted");
        } else if (item.getAsignStatus().equals("3")) {
            holder.tvAssigned.setText("Completed");
        }

        holder.tvAssigned.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                customClick.assignClick(item);

            }
        });

    }

    @Override
    public int getItemCount() {
        return mArrayAllOrder.size();
    }

    public interface CustomClick {

        void assignClick(PojoAllOrderAdmin.Datum datum);

    }


}


