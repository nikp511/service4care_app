package com.service.care.adapter;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;

import com.bumptech.glide.Glide;
import com.service.care.R;
import com.service.care.pojo.PojoHomeBanner;
import com.smarteist.autoimageslider.SliderViewAdapter;

import java.util.ArrayList;
import java.util.List;

public class MySliderAdapter extends
        SliderViewAdapter<MySliderAdapter.SliderAdapterVH> {

    private Context context;
    private List<PojoHomeBanner.Datum> mSliderItems = new ArrayList<>();

    public MySliderAdapter(Context context, List<PojoHomeBanner.Datum> mSliderItems) {
        this.context = context;
        this.mSliderItems = mSliderItems;
    }


    @Override
    public SliderAdapterVH onCreateViewHolder(ViewGroup parent) {
        View inflate = LayoutInflater.from(parent.getContext()).inflate(R.layout.item_slider, null);
        return new SliderAdapterVH(inflate);
    }

    @Override
    public void onBindViewHolder(SliderAdapterVH viewHolder, final int position) {

        if (mSliderItems.get(position).getPath() != null) {
            if (!mSliderItems.get(position).getPath().equals("")) {
                Glide.with(viewHolder.itemView)
                        .load(mSliderItems.get(position).getPath())
                        .into(viewHolder.imageViewBackground);
            }

        }


    }

    @Override
    public int getCount() {
        //slider view count could be dynamic size

        return mSliderItems.size();

    }

    class SliderAdapterVH extends SliderViewAdapter.ViewHolder {

        View itemView;
        ImageView imageViewBackground;

        public SliderAdapterVH(View itemView) {
            super(itemView);
            imageViewBackground = itemView.findViewById(R.id.iv_auto_image_slider);
            this.itemView = itemView;
        }
    }


}
