package com.service.care.fragments.employess;

import android.app.TimePickerDialog;
import android.content.Context;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.preference.PreferenceManager;
import android.text.TextUtils;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ProgressBar;
import android.widget.RelativeLayout;
import android.widget.TimePicker;

import androidx.appcompat.widget.Toolbar;
import androidx.fragment.app.Fragment;
import androidx.recyclerview.widget.DefaultItemAnimator;
import androidx.recyclerview.widget.GridLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.service.care.R;
import com.service.care.adapter.AllInquiryDetailAdapter;
import com.service.care.application.MyApplication;
import com.service.care.constants.ConstantCodes;
import com.service.care.pojo.PojoAllInquiry;
import com.service.care.pojo.PojoCommon;
import com.service.care.pojo.PojoEmpAssignedInquiry;
import com.service.care.utils.Utils;

import java.util.ArrayList;
import java.util.Calendar;
import java.util.List;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

/**
 * Created by Rp on 8/30/2016.
 */

public class EmployeeAllInquiryDetailFragment extends Fragment {

    private View mParentView;

    private Context mContext;
    RelativeLayout mRelativeMain;
    ProgressBar mProgressBar;

    MyApplication mApplication;
    private SharedPreferences mSharedPreference;

    RecyclerView rvInquiry;

    AllInquiryDetailAdapter allInquiryDetailAdapter;

    List<PojoEmpAssignedInquiry.Datum> mArrayInquiry = new ArrayList<>();

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        mParentView = inflater.inflate(R.layout.fragment_employee_all_inquiry_detail, container, false);
        mApplication = (MyApplication) getActivity().getApplicationContext();
        mContext = getActivity();
        setHasOptionsMenu(true);
        mSharedPreference = PreferenceManager.getDefaultSharedPreferences(getActivity());

        initialise();
        listners();

        networkCallInquiry();

        return mParentView;

    }


    void initialise() {

        Toolbar mToolbar = (Toolbar) getActivity().findViewById(R.id.toolbar);
        mToolbar.setTitle("My Inquiry");
        mToolbar.setVisibility(View.VISIBLE);

        mRelativeMain = mParentView.findViewById(R.id.relative_main);
        mProgressBar = mParentView.findViewById(R.id.progressbar);

        rvInquiry = mParentView.findViewById(R.id.rvInquiry);
        GridLayoutManager layoutManagerContact = new GridLayoutManager(mContext, 1);
        rvInquiry.setLayoutManager(layoutManagerContact);
        rvInquiry.setItemAnimator(new DefaultItemAnimator());


    }

    void listners() {

    }


    private void networkCallInquiry() {
        if (mApplication.isInternetConnected()) {

            mProgressBar.setVisibility(View.VISIBLE);

            mApplication.getRetroFitInterface().EmployeeAssignedInquiry(mSharedPreference.getString(ConstantCodes.LOGIN_USER_ID, ""), "1","p", "").enqueue(mCallbackComplain);


        } else {
            Utils.showSnackBar(getActivity(), getResources().getString(R.string
                    .message_connection));
            mProgressBar.setVisibility(View.GONE);
        }
    }


    /**
     * Callback for ws.wolfsoft.propertyplanetapp.network call
     */
    private Callback<PojoEmpAssignedInquiry> mCallbackComplain = new Callback<PojoEmpAssignedInquiry>() {
        @Override
        public void onResponse(Call<PojoEmpAssignedInquiry> call, Response<PojoEmpAssignedInquiry> response) {

            try {
                if (response != null && response.isSuccessful() && response.body() != null) {

                    PojoEmpAssignedInquiry pojoParticipants = response.body();

                    mArrayInquiry.clear();

                    if (pojoParticipants.getStatus() == 1) {

                        if (pojoParticipants.getData() != null) {
                            if (pojoParticipants.getData().size() > 0) {
                                mArrayInquiry.addAll(pojoParticipants.getData());
                                allInquiryDetailAdapter = new AllInquiryDetailAdapter(mContext, mArrayInquiry, customClick);
                                rvInquiry.setAdapter(allInquiryDetailAdapter);
                            }
                        }

                    } else {
                        rvInquiry.setAdapter(null);
                        if (!TextUtils.isEmpty(pojoParticipants.getMessage())) {
                            Utils.showSnackBar(getActivity(), pojoParticipants.getMessage());

                        } else {
                            Utils.showSnackBar(getActivity(), getString(R.string
                                    .message_something_wrong));
                        }

                    }
                } else {
                    Utils.showSnackBar(getActivity(), getString(R.string.message_something_wrong));
                    mProgressBar.setVisibility(View.GONE);
                }
                mProgressBar.setVisibility(View.GONE);
            } catch (Exception e) {

            }


        }

        @Override
        public void onFailure(Call<PojoEmpAssignedInquiry> call, Throwable t) {
            try {
                Utils.showSnackBar(getActivity(), getString(R.string
                        .message_something_wrong));
                mProgressBar.setVisibility(View.GONE);
            } catch (Exception e) {

            }
        }
    };

    AllInquiryDetailAdapter.CustomClick customClick = new AllInquiryDetailAdapter.CustomClick() {
        @Override
        public void submitClick(final PojoEmpAssignedInquiry.Datum datum, String what, String extra) {


            try {

                if (what.equals("submit")) {
                    if (datum.getAndroidStartTime() != null) {
                        if (!datum.getAndroidStartTime().equals("")) {
                            if (datum.getAndroidEndTime() != null) {
                                if (!datum.getAndroidEndTime().equals("")) {
                                    if (datum.getAndroidfinalAmount() != null) {
                                        if (!datum.getAndroidfinalAmount().equals("")) {
                                            int finalAmt = Integer.parseInt(datum.getPrice()) + Integer.parseInt(datum.getAndroidfinalAmount());
                                            networkCallCompleteWork(datum.getAndroidStartTime(), datum.getAndroidEndTime(),
                                                    datum.getBookServiceId(), finalAmt + "");
                                        }
                                    }
                                }
                            }
                        }
                    }
                } else if (what.equals("st")) {


                    int mHour, mMinute;

                    final Calendar c = Calendar.getInstance();
                    mHour = c.get(Calendar.HOUR_OF_DAY);
                    mMinute = c.get(Calendar.MINUTE);

                    // Launch Time Picker Dialog
                    TimePickerDialog timePickerDialog = new TimePickerDialog(mContext,
                            new TimePickerDialog.OnTimeSetListener() {

                                @Override
                                public void onTimeSet(TimePicker view, int hourOfDay,
                                                      int minute) {

                                    datum.setAndroidStartTime(hourOfDay + ":" + minute + ":00");
                                    allInquiryDetailAdapter.notifyDataSetChanged();
                                }
                            }, mHour, mMinute, false);
                    timePickerDialog.show();


                } else if (what.equals("et")) {

                    int mHour, mMinute;

                    final Calendar c = Calendar.getInstance();
                    mHour = c.get(Calendar.HOUR_OF_DAY);
                    mMinute = c.get(Calendar.MINUTE);

                    // Launch Time Picker Dialog
                    TimePickerDialog timePickerDialog = new TimePickerDialog(mContext,
                            new TimePickerDialog.OnTimeSetListener() {

                                @Override
                                public void onTimeSet(TimePicker view, int hourOfDay,
                                                      int minute) {

                                    datum.setAndroidEndTime(hourOfDay + ":" + minute + ":00");
                                    allInquiryDetailAdapter.notifyDataSetChanged();
                                }
                            }, mHour, mMinute, false);
                    timePickerDialog.show();

                } else if (what.equals("amt")) {
                    datum.setAndroidfinalAmount(extra);
                    allInquiryDetailAdapter.notifyDataSetChanged();
                }


            } catch (
                    Exception e) {

            }


        }
    };


    private void networkCallCompleteWork(String startTime, String endTime, String serviceId, String finalAmount) {
        if (mApplication.isInternetConnected()) {

            mProgressBar.setVisibility(View.VISIBLE);

            mApplication.getRetroFitInterface().EmpCompleteInquiry(mSharedPreference.getString(ConstantCodes.LOGIN_USER_ID, ""),
                    startTime,
                    endTime,
                    serviceId,
                    finalAmount).enqueue(mCallbackAddComplain);


        } else {
            Utils.showSnackBar(getActivity(), getResources().getString(R.string
                    .message_connection));
            mProgressBar.setVisibility(View.GONE);
        }
    }

    /**
     * Callback for ws.wolfsoft.propertyplanetapp.network call
     */
    private Callback<PojoCommon> mCallbackAddComplain = new Callback<PojoCommon>() {
        @Override
        public void onResponse(Call<PojoCommon> call, Response<PojoCommon> response) {

            try {
                if (response != null && response.isSuccessful() && response.body() != null) {

                    PojoCommon pojoParticipants = response.body();

                    if (pojoParticipants.getStatus() == 1) {

                        Utils.showSnackBar(getActivity(), "" + pojoParticipants.getMessage());

                        networkCallInquiry();

                    } else {
                        if (!TextUtils.isEmpty(pojoParticipants.getMessage())) {
                            Utils.showSnackBar(getActivity(), pojoParticipants.getMessage());

                        } else {
                            Utils.showSnackBar(getActivity(), getString(R.string
                                    .message_something_wrong));
                        }

                    }
                } else {
                    Utils.showSnackBar(getActivity(), getString(R.string.message_something_wrong));
                    mProgressBar.setVisibility(View.GONE);
                }
                mProgressBar.setVisibility(View.GONE);
            } catch (Exception e) {

            }


        }

        @Override
        public void onFailure(Call<PojoCommon> call, Throwable t) {
            try {
                Utils.showSnackBar(getActivity(), getString(R.string
                        .message_something_wrong));
                mProgressBar.setVisibility(View.GONE);
            } catch (Exception e) {

            }
        }
    };


}
