package com.service.care.fragments;

import android.content.Context;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.preference.PreferenceManager;
import android.text.TextUtils;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.EditText;
import android.widget.ProgressBar;
import android.widget.RatingBar;
import android.widget.RelativeLayout;
import android.widget.TextView;

import androidx.appcompat.widget.Toolbar;
import androidx.fragment.app.Fragment;

import com.service.care.R;
import com.service.care.application.MyApplication;
import com.service.care.constants.ConstantCodes;
import com.service.care.pojo.PojoCommon;
import com.service.care.utils.Utils;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

/**
 * Created by Rp on 8/30/2016.
 */
public class RatingFragment extends Fragment {

    private View mParentView;

    private Context mContext;
    RelativeLayout mRelativeMain;
    ProgressBar mProgressBar;

    MyApplication mApplication;
    private SharedPreferences mSharedPreference;

    EditText etName, etMobile;
    RatingBar ratingBar;
    TextView tvSubmit;


    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        mParentView = inflater.inflate(R.layout.fragment_rating, container, false);
        mApplication = (MyApplication) getActivity().getApplicationContext();
        mContext = getActivity();
        setHasOptionsMenu(true);
        mSharedPreference = PreferenceManager.getDefaultSharedPreferences(getActivity());

        initialise();

        return mParentView;

    }


    void initialise() {

        Toolbar mToolbar = (Toolbar) getActivity().findViewById(R.id.toolbar);
        mToolbar.setTitle("Rating");
        mToolbar.setVisibility(View.VISIBLE);

        mRelativeMain = mParentView.findViewById(R.id.relative_main);
        mProgressBar = mParentView.findViewById(R.id.progressbar);

        ratingBar = mParentView.findViewById(R.id.rating);
        etName = mParentView.findViewById(R.id.etName);
        etMobile = mParentView.findViewById(R.id.etMobile);

        etName.setText("" + mSharedPreference.getString(ConstantCodes.LOGIN_USER_NAME, ""));
        etMobile.setText("" + mSharedPreference.getString(ConstantCodes.LOGIN_USER_MOBILE, ""));

        tvSubmit = mParentView.findViewById(R.id.tvSubmit);

        tvSubmit.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (!etName.getText().toString().equals("")) {
                    if (!etMobile.getText().toString().equals("")) {
                        if (ratingBar.getRating() > 0) {
                            networkCallFeedback();
                        } else {
                            Utils.showSnackBar(getActivity(), "Please select rating to submit");
                        }
                    } else {
                        Utils.showSnackBar(getActivity(), "Please enter mobile number");
                    }
                } else {
                    Utils.showSnackBar(getActivity(), "Please enter name");
                }

            }
        });
    }

    private void networkCallFeedback() {
        if (mApplication.isInternetConnected()) {

            mProgressBar.setVisibility(View.VISIBLE);

            mApplication.getRetroFitInterface().UserRateUs(etName.getText().toString(), etMobile.getText().toString(), ratingBar.getRating() + "").enqueue(mCallbackAddComplain);


        } else {
            Utils.showSnackBar(getActivity(), getResources().getString(R.string
                    .message_connection));
            mProgressBar.setVisibility(View.GONE);
        }
    }

    /**
     * Callback for ws.wolfsoft.propertyplanetapp.network call
     */
    private Callback<PojoCommon> mCallbackAddComplain = new Callback<PojoCommon>() {
        @Override
        public void onResponse(Call<PojoCommon> call, Response<PojoCommon> response) {

            try {
                if (response != null && response.isSuccessful() && response.body() != null) {

                    PojoCommon pojoParticipants = response.body();

                    if (pojoParticipants.getStatus() == 1) {

                        Utils.showSnackBar(getActivity(), "" + pojoParticipants.getMessage());
                        etName.setText("" + mSharedPreference.getString(ConstantCodes.LOGIN_USER_NAME, ""));
                        etMobile.setText("" + mSharedPreference.getString(ConstantCodes.LOGIN_USER_MOBILE, ""));
                        ratingBar.setRating(0);
                    } else {
                        if (!TextUtils.isEmpty(pojoParticipants.getMessage())) {
                            Utils.showSnackBar(getActivity(), pojoParticipants.getMessage());

                        } else {
                            Utils.showSnackBar(getActivity(), getString(R.string
                                    .message_something_wrong));
                        }

                    }
                } else {
                    Utils.showSnackBar(getActivity(), getString(R.string.message_something_wrong));
                    mProgressBar.setVisibility(View.GONE);
                }
                mProgressBar.setVisibility(View.GONE);
            } catch (Exception e) {

            }


        }

        @Override
        public void onFailure(Call<PojoCommon> call, Throwable t) {
            try {
                Utils.showSnackBar(getActivity(), getString(R.string
                        .message_something_wrong));
                mProgressBar.setVisibility(View.GONE);
            } catch (Exception e) {

            }
        }
    };

}
