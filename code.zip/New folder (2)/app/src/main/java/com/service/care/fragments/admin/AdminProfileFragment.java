package com.service.care.fragments.admin;

import android.content.Context;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.preference.PreferenceManager;
import android.text.TextUtils;
import android.view.LayoutInflater;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.View;
import android.view.ViewGroup;
import android.widget.EditText;
import android.widget.ProgressBar;
import android.widget.RelativeLayout;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.appcompat.widget.Toolbar;
import androidx.fragment.app.Fragment;

import com.google.android.material.navigation.NavigationView;
import com.service.care.R;
import com.service.care.application.MyApplication;
import com.service.care.constants.ConstantCodes;
import com.service.care.pojo.PojoCommon;
import com.service.care.pojo.PojoProfile;
import com.service.care.utils.Utils;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

/**
 * Created by Rp on 8/30/2016.
 */
public class AdminProfileFragment extends Fragment {

    private View mParentView;

    private Context mContext;
    RelativeLayout mRelativeMain;
    ProgressBar mProgressBar;

    MyApplication mApplication;
    private SharedPreferences mSharedPreference;

    TextView tvName;

    EditText etName, etMobile;

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        mParentView = inflater.inflate(R.layout.fragment_admin_profile, container, false);
        mApplication = (MyApplication) getActivity().getApplicationContext();
        mContext = getActivity();
        setHasOptionsMenu(true);
        mSharedPreference = PreferenceManager.getDefaultSharedPreferences(getActivity());

        initialise();

        return mParentView;

    }


    void initialise() {

        Toolbar mToolbar = (Toolbar) getActivity().findViewById(R.id.toolbar);
        mToolbar.setTitle("My Profile");
        mToolbar.setVisibility(View.VISIBLE);

        mRelativeMain = mParentView.findViewById(R.id.relative_main);
        mProgressBar = mParentView.findViewById(R.id.progressbar);

        tvName = mParentView.findViewById(R.id.tvName);
        tvName.setText("" + mSharedPreference.getString(ConstantCodes.LOGIN_USER_NAME, ""));

        etName = mParentView.findViewById(R.id.etName);
        etMobile = mParentView.findViewById(R.id.etMobile);

        etName.setText("" + mSharedPreference.getString(ConstantCodes.LOGIN_USER_NAME, ""));
        etMobile.setText("" + mSharedPreference.getString(ConstantCodes.LOGIN_USER_MOBILE, ""));

    }


    private void networkCallUpdateProfile() {
        if (mApplication.isInternetConnected()) {

            mProgressBar.setVisibility(View.VISIBLE);

            mApplication.getRetroFitInterface().AdminProfile(etName.getText().toString() + "",
                    etMobile.getText().toString() + "",
                    mSharedPreference.getString(ConstantCodes.LOGIN_USER_ID, "")).enqueue(mCallbackAssign);


        } else {
            Utils.showSnackBar(getActivity(), getResources().getString(R.string
                    .message_connection));
            mProgressBar.setVisibility(View.GONE);
        }
    }

    /**
     * Callback for ws.wolfsoft.propertyplanetapp.network call
     */
    private Callback<PojoProfile> mCallbackAssign = new Callback<PojoProfile>() {
        @Override
        public void onResponse(Call<PojoProfile> call, Response<PojoProfile> response) {
            if (response != null && response.isSuccessful() && response.body() != null) {

                PojoProfile pojoParticipants = response.body();

                if (pojoParticipants.getStatus() == 1) {

                    Utils.showSnackBar(getActivity(), "" + pojoParticipants.getMessage());
                    mSharedPreference.edit().putString(ConstantCodes.LOGIN_USER_NAME, pojoParticipants.getData().getUserName()).apply();
                    mSharedPreference.edit().putString(ConstantCodes.LOGIN_USER_MOBILE, pojoParticipants.getData().getMobile()).apply();

                    // code for updating left panel name
                    NavigationView navigationView;
                    navigationView = getActivity().findViewById(R.id.nav_view);
                    View headerView = navigationView.getHeaderView(0);
                    TextView tvLeftHeaderName = (TextView) headerView.findViewById(R.id.tvName);
                    if (mSharedPreference.getString(ConstantCodes.LOGIN_USER_NAME, "").equals("")) {
                        tvLeftHeaderName.setText("Hello, Guest");
                    } else {
                        tvLeftHeaderName.setText("Hello, " + mSharedPreference.getString(ConstantCodes.LOGIN_USER_NAME, ""));

                    }

                } else {
                    if (!TextUtils.isEmpty(pojoParticipants.getMessage())) {
                        Utils.showSnackBar(getActivity(), pojoParticipants.getMessage());

                    } else {
                        Utils.showSnackBar(getActivity(), getString(R.string
                                .message_something_wrong));
                    }

                }
            } else {
                Utils.showSnackBar(getActivity(), getString(R.string.message_something_wrong));
                mProgressBar.setVisibility(View.GONE);
            }
            mProgressBar.setVisibility(View.GONE);

        }

        @Override
        public void onFailure(Call<PojoProfile> call, Throwable t) {

            try {
                Utils.showSnackBar(getActivity(), getString(R.string
                        .message_something_wrong));
                mProgressBar.setVisibility(View.GONE);
            } catch (Exception e) {

            }

        }
    };


    @Override
    public void onCreateOptionsMenu(@NonNull Menu menu, @NonNull MenuInflater inflater) {
        super.onCreateOptionsMenu(menu, inflater);

        inflater.inflate(R.menu.option_menu_profile_save, menu);

    }

    @Override
    public boolean onOptionsItemSelected(@NonNull MenuItem item) {

        try {
            if (item.getItemId() == R.id.save) {
                if (!etName.getText().toString().equals("")) {
                    if (!etMobile.getText().toString().equals("")) {
                        networkCallUpdateProfile();
                    } else {
                        Utils.showSnackBar(getActivity(), "Enter Mobile");
                    }
                } else {
                    Utils.showSnackBar(getActivity(), "Enter Username");
                }
            }
        } catch (Exception e) {

        }


        return super.onOptionsItemSelected(item);
    }
}
