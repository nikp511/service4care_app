package com.service.care.fragments.admin;

import android.content.Context;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.preference.PreferenceManager;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ProgressBar;
import android.widget.RelativeLayout;
import android.widget.TextView;

import androidx.appcompat.widget.Toolbar;
import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentTransaction;

import com.service.care.R;
import com.service.care.application.MyApplication;
import com.service.care.constants.ConstantCodes;
import com.service.care.pojo.PojoDashboardCounters;
import com.service.care.utils.Utils;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;


/**
 * Created by Rp on 8/30/2016.
 */
public class AdminDashboardFragment extends Fragment {

    private View mParentView;

    private Context mContext;
    RelativeLayout mRelativeMain;
    ProgressBar mProgressBar;

    MyApplication mApplication;
    private SharedPreferences mSharedPreference;

    TextView tvTotalEnq, tvTotalEmp, tvTodayEnq, tvTotalIncome;


    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        mParentView = inflater.inflate(R.layout.fragment_dashboard_admin, container, false);
        mApplication = (MyApplication) getActivity().getApplicationContext();
        mContext = getActivity();
        setHasOptionsMenu(true);
        mSharedPreference = PreferenceManager.getDefaultSharedPreferences(getActivity());


        initialise();
        listners();
        networkCallCounters();

        return mParentView;

    }


    void initialise() {

        Toolbar mToolbar = (Toolbar) getActivity().findViewById(R.id.toolbar);
        mToolbar.setTitle("Dashboard");
        mToolbar.setVisibility(View.VISIBLE);


        mRelativeMain = mParentView.findViewById(R.id.relative_main);
        mProgressBar = mParentView.findViewById(R.id.progressbar);


        tvTotalEnq = mParentView.findViewById(R.id.tvTotalEnq);
        tvTodayEnq = mParentView.findViewById(R.id.tvTodayEnq);
        tvTotalIncome = mParentView.findViewById(R.id.tvTotalIncome);
        tvTotalEmp = mParentView.findViewById(R.id.tvTotalEmp);


    }


    void listners() {

        tvTodayEnq.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Fragment fragment1 = new AdminOrderFragment();
                FragmentTransaction ft1 = getFragmentManager().beginTransaction();
                ft1.replace(R.id.frame_container, fragment1).addToBackStack("").commit();
            }
        });

        tvTotalEmp.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Fragment fragment1 = new AdminEmployeeListFragment();
                FragmentTransaction ft1 = getFragmentManager().beginTransaction();
                ft1.replace(R.id.frame_container, fragment1).addToBackStack("").commit();
            }
        });

        tvTotalEnq.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Fragment fragment1 = new AdminOrderFragment();
                FragmentTransaction ft1 = getFragmentManager().beginTransaction();
                ft1.replace(R.id.frame_container, fragment1).addToBackStack("").commit();
            }
        });

        tvTotalIncome.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Fragment fragment1 = new AdminCashCollectedFragment();
                FragmentTransaction ft1 = getFragmentManager().beginTransaction();
                ft1.replace(R.id.frame_container, fragment1).addToBackStack("").commit();
            }
        });

    }


    private void networkCallCounters() {
        if (mApplication.isInternetConnected()) {

            mProgressBar.setVisibility(View.VISIBLE);


            mApplication.getRetroFitInterface().GetAdminDashboardCounter().enqueue(mCallbackCounter);


        } else {
            Utils.showSnackBar(getActivity(), getResources().getString(R.string
                    .message_connection));
            mProgressBar.setVisibility(View.GONE);
        }
    }


    /**
     * Callback for ws.wolfsoft.propertyplanetapp.com.agricon.network call
     */
    private Callback<PojoDashboardCounters> mCallbackCounter = new Callback<PojoDashboardCounters>() {
        @Override
        public void onResponse(Call<PojoDashboardCounters> call, Response<PojoDashboardCounters> response) {
            if (response != null && response.isSuccessful() && response.body() != null) {
                if (isAdded()) {

                    PojoDashboardCounters pojoParticipants = response.body();
                    if (pojoParticipants.getStatus() == 1) {

                        if (pojoParticipants.getData() != null) {
                            tvTodayEnq.setText("" + pojoParticipants.getData().getTodaysInquiry() + "\n\nToday's Enquiries");
                            tvTotalEmp.setText("" + pojoParticipants.getData().getTotalEmployees() + "\n\nTotal Employees");
                            tvTotalEnq.setText("" + pojoParticipants.getData().getTotalInquiry() + "\n\nTotal Enquiries");
                            tvTotalIncome.setText("" + pojoParticipants.getData().getTotalIncome() + "\n\nTotal Income");
                        }

                    }
                    mProgressBar.setVisibility(View.GONE);

                }
            }
        }

        @Override
        public void onFailure(Call<PojoDashboardCounters> call, Throwable t) {
            Utils.showSnackBar(getActivity(), getString(R.string
                    .message_something_wrong));
            mProgressBar.setVisibility(View.GONE);
        }
    };


}
